<?php

				$copia = "CREATE TRIGGER emp_taxes BEFORE INSERT OR UPDATE ON public.employees FOR EACH ROW WHEN";
				$restoFunction = "";
				$encuentra = ' ON ';
				$pos = strpos($copia, $encuentra);
                $corto = substr($copia, $pos);
				echo substr($copia, $pos);
				$palabra = explode(' ',$corto);
				echo '<br>';
				echo $palabra[2];
				/*
				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					$restoFunction = substr ( $copia , $posicionFunction + 8  );
				}
				*/
				
				
?>