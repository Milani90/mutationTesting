<?php
session_start(); //Iniciamos o Continuamos la sesion
if (isset($_SESSION['login'])) //Si llego un Nickname via el formulario lo grabamos en la Sesion
{
 
}
else{
	 header('location: login.php');
}


  //Activamos todas las notificaciones de error posibles
  error_reporting (E_ALL);

  //Definimos el tratamiento de errores no controlados
  set_error_handler(function () 
  {
    throw new Exception("Error");
  });
  
  function LogDeErrores($numeroDeError, $descripcion, $fichero, $linea, $contexto){
	  echo '<br>';
   error_log("Error: [".$numeroDeError."] ".$descripcion." ".$fichero." ".$linea." ".json_encode($contexto)." \n\r", 3, "log_errores.txt");
   $error = explode ("ERROR:", $descripcion);
  $_SESSION['descripcionErrorTrigger'] = isset($error[1]) ? $error[1] : null ;	
   throw new Exception("Error");
  }
  set_error_handler("LogDeErrores");


//INICIO


	$host = $_SESSION['host'];
	$port = $_SESSION['port'];
	$dbname = "dbname=" . $_SESSION['databaseNameTrigger'];
	$user = $_SESSION['user'];
	$password = $_SESSION['passConf'];
	$confConexion = $host ." ". $port ." ". $dbname ." " .$user ." ". $password;

	$con = pg_connect($confConexion);

//FIN


	$usuario= $_SESSION['login'];
	
$triggerHeader = $_POST['triggerHeader']; 
$_SESSION["triggerHeader"] = $triggerHeader;

$triggerHeaderEsc = pg_escape_string($triggerHeader);




$triggerFunction = $_POST['triggerFunction']; 
$_SESSION["triggerFunction"] = $triggerFunction; //VARIABLE SESION
$triggerFunctionEsc = pg_escape_string($triggerFunction);


$funcion = explode(" ", $triggerFunctionEsc);

$nombreFuncion = $funcion[2];



$deleteFuncion ="DROP FUNCTION IF EXISTS $nombreFuncion CASCADE";


pg_query($con,$deleteFuncion);






$triggerName = $_POST['triggerName']; 
$_SESSION["triggerName"] = $triggerName;
$description = $_POST['description']; 
$_SESSION["descriptionTrigger"] = $description;
$databaseName = $_POST['databaseName'];
$_SESSION["databaseNameTrigger"] = $databaseName; 




$triggerFunctionValido = false;
echo '<br>';echo '<br>';

echo '<br>';echo '<br>';


$triggerFunctionEsc = str_replace('"','\'', $triggerFunctionEsc);






  try 
  {

$triggerFunctionIns = pg_query($triggerFunctionEsc);

 
if($triggerFunctionIns){
	
	$triggerFunctionValido = true;
	echo " Correct inserting function";
}
else
{
	echo " Error inserting function";
}

  
echo '<br>';
echo '<br>';
echo '<br>';

$triggerHeaderValido = false;

$triggerHeaderEsc = str_replace('"','\'',$triggerHeaderEsc);

echo '<br>';
echo '<br>';
echo '<br>';



$triggerHeaderIns = pg_query($triggerHeaderEsc);
if($triggerHeaderIns){
	
	
	$triggerHeaderValido = true;
	echo " Correct inserting trigger";
}
else
{
	echo " Error inserting trigger";
}



if($triggerFunctionValido == true && $triggerHeaderValido == true){

	$conexion =  pg_connect($_SESSION['conexion']);

	$sql = "update triggers set name = '$triggerName',headertrigger = '$triggerHeader',bodytrigger = '$triggerFunction' ,login = '$usuario',databasename = '$databaseName',description = '{$description}' where idtrigger = '".$_SESSION['idTrigger']."'";

 
//Ejecutamos la consulta
$res = pg_query($conexion,$sql);
  
  if($res)
  {
	echo "Trigger insertado correctamente";
  }
  else{
	echo "Error critico";
	header('location: error_add_edit_trigger.php'); 
	
  }
  
 
//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
pg_free_result($res);

pg_close($conexion);



//BORRAMOS EL TRIGGER INSERTADO
$triggerFunction = $_POST['triggerFunction']; 
$_SESSION["triggerFunction"] = $triggerFunction; //VARIABLE SESION
$triggerFunctionEsc = pg_escape_string($triggerFunction);

$funcion = explode(" ", $triggerFunctionEsc);

$nombreFuncion = $funcion[2];


$deleteFuncion ="DROP FUNCTION IF EXISTS $nombreFuncion CASCADE";


pg_query($con,$deleteFuncion);

//FIN BORRADO TRIGGER INSERTADO




header('location: triggers.php');


 
} 



  }//fin del try
   catch(Exception $e) //capturamos un posible error
  {
    //mostramos el texto del error al usuario	  
    echo "Error al insertar el trigger." . PHP_EOL;
	echo "Revise el código." . PHP_EOL;
	
	
	header('location: error_add_edit_trigger.php'); 
  }
  


  //Restablecemos el tratamiento de errores
  restore_error_handler();
?>