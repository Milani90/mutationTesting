PHP
<?php
  //Activamos todas las notificaciones de error posibles
  error_reporting (E_ALL);

  //Definimos el tratamiento de errores no controlados
  set_error_handler(function () 
  {
    throw new Exception("Error");
  });
  
  try 
  {
    $resultado = 4 / 0; //Operación para generar el error
  } 
  catch(Exception $e) //capturamos un posible error
  {
    //mostramos el texto del error al usuario	  
    echo "Error en división por cero." . PHP_EOL;
	die('La consulta fallo: ' . $php_errormsg);
    $resultado = 0;
	
	//header('Location: error.php');
  }
  /*
  finally
  {
    echo "Esto se ejecutará siempre, tanto si hay error como si no.";
  }
  */
  
  echo "Seguirá la ejecución del programa.";
  
  //Restablecemos el tratamiento de errores
  restore_error_handler();

?>  
