<?php

$host = "host=127.0.0.1 ";
$port = "port=5432 ";
$dbname = "dbname=tfm ";
$user = " user=postgres ";
$password = "password=root";
$confConexion = $host . $port . $dbname .$user . $password;
echo 'CONEXION: ', $confConexion;

$con = pg_connect($confConexion);


$descripcion = $_POST['description']; 
echo 'DESCRIPCION: ', $descripcion;
$databaseName = $_POST['databaseName']; 
echo 'BASE DE DATOS: ', $databaseName;

//$_SESSION['newTest'] = $_POST['databaseName'];
//$tests = pg_escape_string($_POST['newTest']); 
//$tests = str_replace('"','\'', $tests);
//$test = explode(";", $tests);


 
$tests=$_POST['test'];
for ($i=0;$i<count($tests);$i++)    
{     
echo "<br> TEST " . $i . ": " . $tests[$i];    
//$provincias = $tests[$i] ;
}



?>