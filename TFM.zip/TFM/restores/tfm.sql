INSERT INTO mutations VALUES ('2005','nombreTriggerRow','nombreFuncionRow_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_1();','CREATE FUNCTION nombreFuncionRow_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2009','nombreTriggerRow','nombreFuncionRow_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_2();','CREATE FUNCTION nombreFuncionRow_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2013','nombreTriggerRow','nombreFuncionRow_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_3();','CREATE FUNCTION nombreFuncionRow_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2017','nombreTriggerRow','nombreFuncionRow_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_1();','CREATE FUNCTION nombreFuncionRow_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2021','nombreTriggerRow','nombreFuncionRow_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_2();','CREATE FUNCTION nombreFuncionRow_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2025','nombreTriggerRow','nombreFuncionCristian_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_3();','CREATE FUNCTION nombreFuncionCristian_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2028','nombreTriggerRow','nombreFuncionCristian_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_3();','CREATE FUNCTION nombreFuncionCristian_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2032','trigg_insert_milani','stock_milani_1()','CREATE TRIGGER trigg_insert_milani BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_milani_1();','CREATE FUNCTION stock_milani_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2019_t"  || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','milani1991@hotmail.com','59','1','f');
INSERT INTO mutations VALUES ('2036','nombreTriggerRow','nombreFuncionCristian_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_2();','CREATE FUNCTION nombreFuncionCristian_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2042','nombreTriggerRow','nombreFuncionCristian_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_3();','CREATE FUNCTION nombreFuncionCristian_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2046','nombreTriggerRow','nombreFuncionCristian_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_1();','CREATE FUNCTION nombreFuncionCristian_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2049','nombreTriggerRow','nombreFuncionCristian_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_1();','CREATE FUNCTION nombreFuncionCristian_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2052','nombreTriggerRow','nombreFuncionCristian_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_1();','CREATE FUNCTION nombreFuncionCristian_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2055','price_trigger
','public.price_audit()_1()','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();
','CREATE FUNCTION public.price_audit()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','92','1','f');
INSERT INTO mutations VALUES ('2058','price_trigger
','public.price_audit()_1()','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();
','CREATE FUNCTION public.price_audit()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','92','1','f');
INSERT INTO mutations VALUES ('2060','price_trigger
','public.price_audit()_1()','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();
','CREATE FUNCTION public.price_audit()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','92','1','f');
INSERT INTO mutations VALUES ('2006','nombreTriggerRow','nombreFuncionRow_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_2();','CREATE FUNCTION nombreFuncionRow_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2010','nombreTriggerRow','nombreFuncionRow_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_3();','CREATE FUNCTION nombreFuncionRow_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2014','nombreTriggerRow','nombreFuncionRow_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_1();','CREATE FUNCTION nombreFuncionRow_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2018','nombreTriggerRow','nombreFuncionRow_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_2();','CREATE FUNCTION nombreFuncionRow_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2022','nombreTriggerRow','nombreFuncionRow_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_3();','CREATE FUNCTION nombreFuncionRow_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2029','nombreTriggerRow','nombreFuncionCristian_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_1();','CREATE FUNCTION nombreFuncionCristian_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2033','trigg_insert_milani','stock_milani_2()','CREATE TRIGGER trigg_insert_milani BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_milani_2();','CREATE FUNCTION stock_milani_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2019_t"  || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','milani1991@hotmail.com','59','1','f');
INSERT INTO mutations VALUES ('2037','nombreTriggerRow','nombreFuncionCristian_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_3();','CREATE FUNCTION nombreFuncionCristian_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2043','nombreTriggerRow','nombreFuncionCristian_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_1();','CREATE FUNCTION nombreFuncionCristian_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2047','nombreTriggerRow','nombreFuncionCristian_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_2();','CREATE FUNCTION nombreFuncionCristian_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2050','nombreTriggerRow','nombreFuncionCristian_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_2();','CREATE FUNCTION nombreFuncionCristian_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2053','nombreTriggerRow','nombreFuncionCristian_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_2();','CREATE FUNCTION nombreFuncionCristian_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2056','price_trigger
','public.price_audit()_1()','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();
','CREATE FUNCTION public.price_audit()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','92','1','f');
INSERT INTO mutations VALUES ('2059','price_trigger
','public.price_audit()_1()','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();
','CREATE FUNCTION public.price_audit()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','92','1','f');
INSERT INTO mutations VALUES ('2061','price_trigger
','public.price_audit()_1()','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();
','CREATE FUNCTION public.price_audit()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','92','1','f');
INSERT INTO mutations VALUES ('2062','log_last3','log_last3()_1()','CREATE TRIGGER log_last3 BEFORE UPDATE
    ON employees FOR EACH ROW
    EXECUTE PROCEDURE log_last3();','CREATE FUNCTION log_last3()_1()  RETURNS trigger AS
$BODY$
BEGIN
 IF OLD.last_name <> OLD.last_name THEN                        
 INSERT INTO employee_audits(employee_id,last_name,changed_on)
 VALUES(OLD.id,OLD.last_name,now());    
 END IF;
 
 RETURN NEW;
END;
$BODY$
LANGUAGE "plpgsql";','cristian@hotmail.com','177','1','f');
INSERT INTO mutations VALUES ('2007','nombreTriggerRow','nombreFuncionRow_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_3();','CREATE FUNCTION nombreFuncionRow_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2011','nombreTriggerRow','nombreFuncionRow_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_1();','CREATE FUNCTION nombreFuncionRow_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2015','nombreTriggerRow','nombreFuncionRow_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_2();','CREATE FUNCTION nombreFuncionRow_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2019','nombreTriggerRow','nombreFuncionRow_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_3();','CREATE FUNCTION nombreFuncionRow_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2023','nombreTriggerRow','nombreFuncionCristian_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_1();','CREATE FUNCTION nombreFuncionCristian_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2026','nombreTriggerRow','nombreFuncionCristian_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_1();','CREATE FUNCTION nombreFuncionCristian_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2030','nombreTriggerRow','nombreFuncionCristian_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_2();','CREATE FUNCTION nombreFuncionCristian_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2034','trigg_insert_milani','stock_milani_5()','CREATE TRIGGER trigg_insert_milani BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_milani_5();','CREATE FUNCTION stock_milani_5() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT OR DELETE INTO stock_2019_t"  || " VALUES ($1.*)" USING ','milani1991@hotmail.com','59','4','f');
INSERT INTO mutations VALUES ('2038','price_trigger
','public.price_audit()_1()','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();
','CREATE FUNCTION public.price_audit()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','92','1','f');
INSERT INTO mutations VALUES ('2039','price_trigger
','public.price_audit()_1()','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','95','1','f');
INSERT INTO mutations VALUES ('2040','nombreTriggerRow','nombreFuncionCristian_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_1();','CREATE FUNCTION nombreFuncionCristian_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2044','nombreTriggerRow','nombreFuncionCristian_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_2();','CREATE FUNCTION nombreFuncionCristian_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2048','nombreTriggerRow','nombreFuncionCristian_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_3();','CREATE FUNCTION nombreFuncionCristian_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2051','nombreTriggerRow','nombreFuncionCristian_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_3();','CREATE FUNCTION nombreFuncionCristian_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2054','nombreTriggerRow','nombreFuncionCristian_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_3();','CREATE FUNCTION nombreFuncionCristian_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2057','price_trigger
','public.price_audit()_1()','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();
','CREATE FUNCTION public.price_audit()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','92','1','f');
INSERT INTO mutations VALUES ('2008','nombreTriggerRow','nombreFuncionRow_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_1();','CREATE FUNCTION nombreFuncionRow_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2012','nombreTriggerRow','nombreFuncionRow_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_2();','CREATE FUNCTION nombreFuncionRow_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2016','nombreTriggerRow','nombreFuncionRow_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_3();','CREATE FUNCTION nombreFuncionRow_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2020','nombreTriggerRow','nombreFuncionRow_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_1();','CREATE FUNCTION nombreFuncionRow_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('1999','nombreTriggerRow','nombreFuncionRow_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_1();','CREATE FUNCTION nombreFuncionRow_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2000','nombreTriggerRow','nombreFuncionRow_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_2();','CREATE FUNCTION nombreFuncionRow_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2001','nombreTriggerRow','nombreFuncionRow_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_3();','CREATE FUNCTION nombreFuncionRow_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2002','nombreTriggerRow','nombreFuncionRow_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_1();','CREATE FUNCTION nombreFuncionRow_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2003','nombreTriggerRow','nombreFuncionRow_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_2();','CREATE FUNCTION nombreFuncionRow_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2004','nombreTriggerRow','nombreFuncionRow_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_3();','CREATE FUNCTION nombreFuncionRow_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','57','1','f');
INSERT INTO mutations VALUES ('2024','nombreTriggerRow','nombreFuncionCristian_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_2();','CREATE FUNCTION nombreFuncionCristian_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2027','nombreTriggerRow','nombreFuncionCristian_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_2();','CREATE FUNCTION nombreFuncionCristian_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2031','nombreTriggerRow','nombreFuncionCristian_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_3();','CREATE FUNCTION nombreFuncionCristian_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2035','nombreTriggerRow','nombreFuncionCristian_1()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_1();','CREATE FUNCTION nombreFuncionCristian_1() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2041','nombreTriggerRow','nombreFuncionCristian_2()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_2();','CREATE FUNCTION nombreFuncionCristian_2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING OLD;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2045','nombreTriggerRow','nombreFuncionCristian_3()','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_3();','CREATE FUNCTION nombreFuncionCristian_3() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','58','1','f');
INSERT INTO mutations VALUES ('2063','log_last3','log_last3()_2()','CREATE TRIGGER log_last3 BEFORE UPDATE
    ON employees FOR EACH ROW
    EXECUTE PROCEDURE log_last3();','CREATE FUNCTION log_last3()_2()  RETURNS trigger AS
$BODY$
BEGIN
 IF NEW.last_name <> OLD.last_name THEN                        
 INSERT INTO employee_audits(employee_id,last_name,changed_on)
 VALUES(OLD.id,OLD.last_name,now());    
 END IF;
 
 RETURN OLD;
END;
$BODY$
LANGUAGE "plpgsql";','cristian@hotmail.com','177','1','f');
INSERT INTO mutations VALUES ('2064','log_last3','log_last3()_3()','CREATE TRIGGER log_last3 BEFORE UPDATE
    ON employees FOR EACH ROW
    EXECUTE PROCEDURE log_last3();','CREATE FUNCTION log_last3()_3()  RETURNS trigger AS
$BODY$
BEGIN
 IF NEW.last_name <> NEW.last_name THEN                        
 INSERT INTO employee_audits(employee_id,last_name,changed_on)
 VALUES(OLD.id,OLD.last_name,now());    
 END IF;
 
 RETURN NEW;
END;
$BODY$
LANGUAGE "plpgsql";','cristian@hotmail.com','177','1','f');
INSERT INTO mutations VALUES ('2065','log_last3()
','log_last3()_3()','CREATE TRIGGER log_last3 BEFORE UPDATE
    ON employees FOR EACH ROW
    EXECUTE PROCEDURE log_last3();','CREATE FUNCTION log_last3()_3()  RETURNS trigger AS
$BODY$
BEGIN
 IF NEW.last_name <> OLD.last_name THEN                        
 INSERT INTO employee_audits(employee_id,last_name,changed_on)
 VALUES(NEW.id,OLD.last_name,now());    
 END IF;
 
 RETURN NEW;
END;
$BODY$
LANGUAGE "plpgsql";','cristian@hotmail.com','177','1','f');
INSERT INTO mutations VALUES ('2066','log_last3()
','log_last3()_3()','CREATE TRIGGER log_last3 BEFORE UPDATE
    ON employees FOR EACH ROW
    EXECUTE PROCEDURE log_last3();','CREATE FUNCTION log_last3()_3()  RETURNS trigger AS
$BODY$
BEGIN
 IF NEW.last_name <> OLD.last_name THEN                        
 INSERT INTO employee_audits(employee_id,last_name,changed_on)
 VALUES(OLD.id,NEW.last_name,now());    
 END IF;
 
 RETURN NEW;
END;
$BODY$
LANGUAGE "plpgsql";','cristian@hotmail.com','177','1','f');
INSERT INTO mutations VALUES ('2067','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2068','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2069','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2070','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2071','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2072','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2073','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2074','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT OR DELETE INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','4','f');
INSERT INTO mutations VALUES ('2075','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH STATEMENT
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','11','f');
INSERT INTO mutations VALUES ('2076','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2077','price_trigger2
','public.price_audit2()_2()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_2()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT OR UPDATE INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','3','f');
INSERT INTO mutations VALUES ('2078','price_trigger
','public.price_audit()_1()','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','223','1','f');
INSERT INTO mutations VALUES ('2079','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2080','price_trigger2
','public.price_audit2()_2()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_2()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT OR UPDATE INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','3','f');
INSERT INTO mutations VALUES ('2081','price_trigger2
','public.price_audit2()_3()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_3()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT OR DELETE INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','4','f');
INSERT INTO mutations VALUES ('2082','price_trigger2
','public.price_audit2()_4()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH STATEMENT
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_4()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','11','f');
INSERT INTO mutations VALUES ('2083','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2084','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2085','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2086','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2087','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2088','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2089','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2090','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2091','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2092','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2093','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2094','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT OR UPDATE INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','3','f');
INSERT INTO mutations VALUES ('2095','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT OR UPDATE INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','3','f');
INSERT INTO mutations VALUES ('2096','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT OR DELETE INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','4','f');
INSERT INTO mutations VALUES ('2097','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2098','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2099','price_trigger2
','public.price_audit2()_2()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_2()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT OR UPDATE INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','3','f');
INSERT INTO mutations VALUES ('2100','price_trigger2
','public.price_audit2()_3()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_3()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT OR DELETE INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','4','f');
INSERT INTO mutations VALUES ('2101','price_trigger2
','public.price_audit2()_4()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH STATEMENT
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_4()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','11','f');
INSERT INTO mutations VALUES ('2102','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT OR UPDATE INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','3','f');
INSERT INTO mutations VALUES ('2103','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2104','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2105','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2106','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2107','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2108','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2109','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2110','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2111','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2112','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2113','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2114','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2115','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2116','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2117','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2118','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2119','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2120','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2121','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2122','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2123','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2124','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2125','price_trigger2
','public.price_audit2()_2()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_2()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT OR UPDATE INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','3','f');
INSERT INTO mutations VALUES ('2126','price_trigger2
','public.price_audit2()_3()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_3()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT OR DELETE INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','4','f');
INSERT INTO mutations VALUES ('2127','price_trigger2
','public.price_audit2()_4()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH STATEMENT
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_4()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','11','f');
INSERT INTO mutations VALUES ('2128','price_trigger2
','public.price_audit2()_1()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_1()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN OLD;
   END;
$BODY$;','cristian@hotmail.com','172','1','f');
INSERT INTO mutations VALUES ('2129','price_trigger2
','public.price_audit2()_2()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_2()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT OR UPDATE INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','3','f');
INSERT INTO mutations VALUES ('2130','price_trigger2
','public.price_audit2()_3()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_3()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT OR DELETE INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','4','f');
INSERT INTO mutations VALUES ('2131','price_trigger2
','public.price_audit2()_4()','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH STATEMENT
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()_4()    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','172','11','f');
INSERT INTO operators VALUES ('6','CHU','Replace update statement','function CHU(){}','cristian');
INSERT INTO operators VALUES ('7','CHD','Replace delete statement','function CHD(){}','cristian');
INSERT INTO operators VALUES ('8','CAO','Replace arithmetic operator (+,-,*,/)','function CAO(){}','cristian');
INSERT INTO operators VALUES ('9','CLO','Replace logical operator (OR - AND)','function CLO(){}','cristian');
INSERT INTO operators VALUES ('10','CBT','Replace boolean operator (True - False)','function CBT(){}','cristian');
INSERT INTO operators VALUES ('11','CRO','Replace row operator','function CRO(){}','cristian');
INSERT INTO operators VALUES ('1','CNO','Replace NEW to OLD','function CNO(){}','cristian');
INSERT INTO operators VALUES ('2','ADI','Add insert statement','function(){}','cristian');
INSERT INTO operators VALUES ('3','ADU','Add update statement','function ADU(){}','cristian');
INSERT INTO operators VALUES ('4','ADD','Add delete statement','function ADD(){}','cristian');
INSERT INTO operators VALUES ('5','CHI','Replace insert statement','function CHI(){}','cristian');
INSERT INTO suites VALUES ('226','pruebas domingo','hemilani@hotmail.com','pruebas');
INSERT INTO suites VALUES ('227','pruebas de 0','hemilani@hotmail.com','pruebas');
INSERT INTO suites VALUES ('301','pruebas test','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('216','prueba1 suite','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('217','prueba 2 suites con test existentes','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('302','adfasdfads','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('303','pruebas comillas','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('304','asdfasdf','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('305','werwerwr','cristian@hotmail.com','tfm_v2');
INSERT INTO suites VALUES ('225','pruebas suites','cristian@hotmail.com','tfm');
INSERT INTO suites VALUES ('233','prueba 18062020_v3','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('235','prueba 18062020_v4','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('237','prueba 18062020_pruebas','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('242','prueba 18062020','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('243','prueba 18062020','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('244','pruebas de 18/06/2020','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('245','pruebas de carga de los tests existentes','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('247','nueva suite','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('248','nueva suite_v2','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('249','nueva suite_v3','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('250','nueva suite_v4','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('252','nueva suite_v5','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('253','nueva suite_v6','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('254','nueva suite_v7','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('259','nueva suite_v72','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('263','SSSSSSSS','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('267','pruebas suitesas','milani1991@hotmail.com','pruebas');
INSERT INTO suites VALUES ('268','dsfasdfasdfa','milani1991@hotmail.com','pruebas');
INSERT INTO suites VALUES ('269','<xczc<zx<c','milani1991@hotmail.com','pruebas');
INSERT INTO suites VALUES ('306','mi�o','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('219','1234567','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('270','pruebas de suites domingo','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('271','pruebas de domingo v2','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('272','asas','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('273','Laurel','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('274','pruebas de nueva suites','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('275','asdfasdf','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('276','prebas de suites','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('277','lunes','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('278','asfasdf','cristian@hotmail.com','tfm2');
INSERT INTO suites VALUES ('279','prueba','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('280','asfdasfd','cristian@hotmail.com','tfm2');
INSERT INTO suites VALUES ('281','asfdafd','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('282','ADSFASDF','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('283','castellon','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('284','castellon_v2','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('285','castellon_v3','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('286','castellon pruebas','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('287','castellon pruebas _v2','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('288','pruebas jueves','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('289','rool','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('307','asdfasdfad','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('308','employees','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('291','pruebas vacios castellon','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('292','nuevos tests','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('293','sevilla','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('295','re','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('296','qq','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('297','rr','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('298','mi�o','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('299','dd','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('300','pruebas mi�o23','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('309','pruebas','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('310','pruebas de test','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('311','asfdasdfasf','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('312','PRUEBAS VIERNES','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('313','asdfasdf','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('314','asdfasdf','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('315','asdfasd','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('316','asdfasdf','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('317','reina','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('318','reina_v2','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('319','sssss','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('320','varios','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('321','ffff','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('322','adsfafds','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('323','sew','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('325','dsass','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('326','asdfasdfasd','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('327','asdfasdf','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('328','ddddddddd','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('329','vvvvvv','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('330','xxxxx','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('331','nnnnn','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('332','tt','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('333','jjjjjjjj','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('334','bbbbb','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('335','adsadfsfa','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('336','yy','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('337','uuu','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('338','nbnb','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('339','nnnnnnn','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('340','bnnnb','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('341','popo','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('342','probamos','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('343','ty','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('344','gh','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('345','vb','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('346','tr','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('347','sdl','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('348','UDL','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('349','ser','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('350','evv','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('351','as','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('352','asd','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('353','ssss','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('354','DERPO','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('355','CRIS','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('356','PUEBRAS','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('357','ADFASDFASFD','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('358','sssss','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('359','sssdfd','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('360','una solo','cristian@hotmail.com','pruebas');
INSERT INTO suites VALUES ('361','suites de dvd','cristian@hotmail.com','dvd');
INSERT INTO suites VALUES ('362','adfasdfasfd','cristian@hotmail.com','dvd');
INSERT INTO suites VALUES ('363','pruebas mercedes','cristian@hotmail.com','dvd');
INSERT INTO suites VALUES ('364','suite de la base de datos de mercedes','cristian@hotmail.com','dbd_rental_mercedes');
INSERT INTO test_suites VALUES ('259','381');
INSERT INTO test_suites VALUES ('259','382');
INSERT INTO test_suites VALUES ('259','383');
INSERT INTO test_suites VALUES ('259','384');
INSERT INTO test_suites VALUES ('259','385');
INSERT INTO test_suites VALUES ('259','386');
INSERT INTO test_suites VALUES ('259','387');
INSERT INTO test_suites VALUES ('259','388');
INSERT INTO test_suites VALUES ('259','389');
INSERT INTO test_suites VALUES ('259','390');
INSERT INTO test_suites VALUES ('259','391');
INSERT INTO test_suites VALUES ('259','392');
INSERT INTO test_suites VALUES ('259','393');
INSERT INTO test_suites VALUES ('259','394');
INSERT INTO test_suites VALUES ('259','395');
INSERT INTO test_suites VALUES ('259','396');
INSERT INTO test_suites VALUES ('259','397');
INSERT INTO test_suites VALUES ('259','398');
INSERT INTO test_suites VALUES ('259','399');
INSERT INTO test_suites VALUES ('217','315');
INSERT INTO test_suites VALUES ('217','316');
INSERT INTO test_suites VALUES ('227','325');
INSERT INTO test_suites VALUES ('227','326');
INSERT INTO test_suites VALUES ('263','419');
INSERT INTO test_suites VALUES ('263','420');
INSERT INTO test_suites VALUES ('263','421');
INSERT INTO test_suites VALUES ('233','334');
INSERT INTO test_suites VALUES ('233','335');
INSERT INTO test_suites VALUES ('263','422');
INSERT INTO test_suites VALUES ('235','337');
INSERT INTO test_suites VALUES ('235','338');
INSERT INTO test_suites VALUES ('263','423');
INSERT INTO test_suites VALUES ('263','424');
INSERT INTO test_suites VALUES ('263','425');
INSERT INTO test_suites VALUES ('263','426');
INSERT INTO test_suites VALUES ('263','427');
INSERT INTO test_suites VALUES ('263','428');
INSERT INTO test_suites VALUES ('263','429');
INSERT INTO test_suites VALUES ('242','346');
INSERT INTO test_suites VALUES ('242','347');
INSERT INTO test_suites VALUES ('243','348');
INSERT INTO test_suites VALUES ('244','349');
INSERT INTO test_suites VALUES ('244','350');
INSERT INTO test_suites VALUES ('244','351');
INSERT INTO test_suites VALUES ('245','349');
INSERT INTO test_suites VALUES ('245','350');
INSERT INTO test_suites VALUES ('263','430');
INSERT INTO test_suites VALUES ('263','431');
INSERT INTO test_suites VALUES ('247','355');
INSERT INTO test_suites VALUES ('247','356');
INSERT INTO test_suites VALUES ('247','357');
INSERT INTO test_suites VALUES ('248','358');
INSERT INTO test_suites VALUES ('248','359');
INSERT INTO test_suites VALUES ('248','360');
INSERT INTO test_suites VALUES ('249','361');
INSERT INTO test_suites VALUES ('249','362');
INSERT INTO test_suites VALUES ('249','363');
INSERT INTO test_suites VALUES ('250','364');
INSERT INTO test_suites VALUES ('250','365');
INSERT INTO test_suites VALUES ('250','366');
INSERT INTO test_suites VALUES ('263','432');
INSERT INTO test_suites VALUES ('263','433');
INSERT INTO test_suites VALUES ('263','434');
INSERT INTO test_suites VALUES ('252','370');
INSERT INTO test_suites VALUES ('252','371');
INSERT INTO test_suites VALUES ('252','372');
INSERT INTO test_suites VALUES ('253','373');
INSERT INTO test_suites VALUES ('253','374');
INSERT INTO test_suites VALUES ('253','375');
INSERT INTO test_suites VALUES ('254','376');
INSERT INTO test_suites VALUES ('254','377');
INSERT INTO test_suites VALUES ('254','378');
INSERT INTO test_suites VALUES ('263','435');
INSERT INTO test_suites VALUES ('263','436');
INSERT INTO test_suites VALUES ('263','437');
INSERT INTO test_suites VALUES ('263','438');
INSERT INTO test_suites VALUES ('263','439');
INSERT INTO test_suites VALUES ('263','440');
INSERT INTO test_suites VALUES ('263','441');
INSERT INTO test_suites VALUES ('263','442');
INSERT INTO test_suites VALUES ('267','443');
INSERT INTO test_suites VALUES ('267','444');
INSERT INTO test_suites VALUES ('268','346');
INSERT INTO test_suites VALUES ('268','347');
INSERT INTO test_suites VALUES ('270','349');
INSERT INTO test_suites VALUES ('270','350');
INSERT INTO test_suites VALUES ('271','447');
INSERT INTO test_suites VALUES ('271','448');
INSERT INTO test_suites VALUES ('271','449');
INSERT INTO test_suites VALUES ('271','450');
INSERT INTO test_suites VALUES ('272','451');
INSERT INTO test_suites VALUES ('272','452');
INSERT INTO test_suites VALUES ('272','453');
INSERT INTO test_suites VALUES ('272','454');
INSERT INTO test_suites VALUES ('273','455');
INSERT INTO test_suites VALUES ('273','456');
INSERT INTO test_suites VALUES ('273','457');
INSERT INTO test_suites VALUES ('273','458');
INSERT INTO test_suites VALUES ('273','459');
INSERT INTO test_suites VALUES ('273','460');
INSERT INTO test_suites VALUES ('274','461');
INSERT INTO test_suites VALUES ('274','462');
INSERT INTO test_suites VALUES ('274','463');
INSERT INTO test_suites VALUES ('274','464');
INSERT INTO test_suites VALUES ('274','465');
INSERT INTO test_suites VALUES ('274','466');
INSERT INTO test_suites VALUES ('276','374');
INSERT INTO test_suites VALUES ('276','375');
INSERT INTO test_suites VALUES ('277','468');
INSERT INTO test_suites VALUES ('280','469');
INSERT INTO test_suites VALUES ('281','470');
INSERT INTO test_suites VALUES ('283','471');
INSERT INTO test_suites VALUES ('283','472');
INSERT INTO test_suites VALUES ('283','473');
INSERT INTO test_suites VALUES ('284','474');
INSERT INTO test_suites VALUES ('285','471');
INSERT INTO test_suites VALUES ('285','472');
INSERT INTO test_suites VALUES ('286','476');
INSERT INTO test_suites VALUES ('286','477');
INSERT INTO test_suites VALUES ('287','478');
INSERT INTO test_suites VALUES ('287','479');
INSERT INTO test_suites VALUES ('288','480');
INSERT INTO test_suites VALUES ('289','481');
INSERT INTO test_suites VALUES ('291','355');
INSERT INTO test_suites VALUES ('291','356');
INSERT INTO test_suites VALUES ('291','357');
INSERT INTO test_suites VALUES ('292','486');
INSERT INTO test_suites VALUES ('292','487');
INSERT INTO test_suites VALUES ('293','488');
INSERT INTO test_suites VALUES ('297','490');
INSERT INTO test_suites VALUES ('298','491');
INSERT INTO test_suites VALUES ('298','492');
INSERT INTO test_suites VALUES ('299','493');
INSERT INTO test_suites VALUES ('299','494');
INSERT INTO test_suites VALUES ('300','495');
INSERT INTO test_suites VALUES ('300','496');
INSERT INTO test_suites VALUES ('301','497');
INSERT INTO test_suites VALUES ('301','498');
INSERT INTO test_suites VALUES ('302','499');
INSERT INTO test_suites VALUES ('302','500');
INSERT INTO test_suites VALUES ('303','501');
INSERT INTO test_suites VALUES ('303','502');
INSERT INTO test_suites VALUES ('307','503');
INSERT INTO test_suites VALUES ('307','504');
INSERT INTO test_suites VALUES ('308','505');
INSERT INTO test_suites VALUES ('308','506');
INSERT INTO test_suites VALUES ('309','507');
INSERT INTO test_suites VALUES ('310','508');
INSERT INTO test_suites VALUES ('311','509');
INSERT INTO test_suites VALUES ('316','510');
INSERT INTO test_suites VALUES ('318','511');
INSERT INTO test_suites VALUES ('319','512');
INSERT INTO test_suites VALUES ('320','513');
INSERT INTO test_suites VALUES ('320','514');
INSERT INTO test_suites VALUES ('320','515');
INSERT INTO test_suites VALUES ('320','516');
INSERT INTO test_suites VALUES ('321','517');
INSERT INTO test_suites VALUES ('323','518');
INSERT INTO test_suites VALUES ('325','519');
INSERT INTO test_suites VALUES ('327','520');
INSERT INTO test_suites VALUES ('335','521');
INSERT INTO test_suites VALUES ('335','522');
INSERT INTO test_suites VALUES ('335','523');
INSERT INTO test_suites VALUES ('337','524');
INSERT INTO test_suites VALUES ('339','525');
INSERT INTO test_suites VALUES ('341','526');
INSERT INTO test_suites VALUES ('342','527');
INSERT INTO test_suites VALUES ('346','528');
INSERT INTO test_suites VALUES ('348','529');
INSERT INTO test_suites VALUES ('353','530');
INSERT INTO test_suites VALUES ('353','531');
INSERT INTO test_suites VALUES ('354','532');
INSERT INTO test_suites VALUES ('354','533');
INSERT INTO test_suites VALUES ('354','534');
INSERT INTO test_suites VALUES ('356','535');
INSERT INTO test_suites VALUES ('358','536');
INSERT INTO test_suites VALUES ('359','537');
INSERT INTO test_suites VALUES ('359','538');
INSERT INTO test_suites VALUES ('359','539');
INSERT INTO test_suites VALUES ('359','540');
INSERT INTO test_suites VALUES ('359','541');
INSERT INTO test_suites VALUES ('360','542');
INSERT INTO test_suites VALUES ('361','543');
INSERT INTO test_suites VALUES ('361','544');
INSERT INTO test_suites VALUES ('361','545');
INSERT INTO test_suites VALUES ('361','546');
INSERT INTO test_suites VALUES ('361','547');
INSERT INTO test_suites VALUES ('362','548');
INSERT INTO test_suites VALUES ('362','549');
INSERT INTO test_suites VALUES ('362','550');
INSERT INTO test_suites VALUES ('363','551');
INSERT INTO test_suites VALUES ('363','552');
INSERT INTO test_suites VALUES ('363','553');
INSERT INTO test_suites VALUES ('363','554');
INSERT INTO test_suites VALUES ('363','555');
INSERT INTO test_suites VALUES ('364','556');
INSERT INTO test_suites VALUES ('364','557');
INSERT INTO test_suites VALUES ('364','558');
INSERT INTO test_suites VALUES ('364','559');
INSERT INTO test_suites VALUES ('364','560');
INSERT INTO tests VALUES ('400','insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('355','insert into employees(name) values ("valencia_")','pruebas');
INSERT INTO tests VALUES ('358','insert into employees(name) values ("valencia_987")','pruebas');
INSERT INTO tests VALUES ('360','  
insert into employees(name) values ("valencia2_987")','pruebas');
INSERT INTO tests VALUES ('361','insert into employees(name) values ("valencia_987")','pruebas');
INSERT INTO tests VALUES ('362','   
insert into employees(name768687) values ("valencia1_987")','pruebas');
INSERT INTO tests VALUES ('363','   
insert into employees(name) values ("valencia2_987")','pruebas');
INSERT INTO tests VALUES ('364','insert into employees(name) values ("valencia444")','pruebas');
INSERT INTO tests VALUES ('365','    
insert into employees(name768687) values ("valencia555")','pruebas');
INSERT INTO tests VALUES ('366','    
insert into employees(name) values ("valencia666")','pruebas');
INSERT INTO tests VALUES ('367','insert into employees(name) values ("log1")','pruebas');
INSERT INTO tests VALUES ('368','     
insert into employees(name) values ("log2")','pruebas');
INSERT INTO tests VALUES ('369','     
insert into employees(name) values ("log3")','pruebas');
INSERT INTO tests VALUES ('370','insert into employees(name) values ("log1")','pruebas');
INSERT INTO tests VALUES ('371','      
insert into employees(name) values ("log2")','pruebas');
INSERT INTO tests VALUES ('372','      
insert into employees(name) values ("log3")','pruebas');
INSERT INTO tests VALUES ('373','insert into employees(name) values ("log15")','pruebas');
INSERT INTO tests VALUES ('374','       
insert into employees(name) values ("log25")','pruebas');
INSERT INTO tests VALUES ('375','       
insert into employees(name) values ("log35")','pruebas');
INSERT INTO tests VALUES ('376','insert into employees(name) values ("po1")','pruebas');
INSERT INTO tests VALUES ('377','        
insert into employees(name) values ("po2")','pruebas');
INSERT INTO tests VALUES ('378','        
insert into employees(name) values ("po3")','pruebas');
INSERT INTO tests VALUES ('380','insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('381','insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('382',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('383',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('384',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('385',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('386',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('387',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('388',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('389',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('390',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('391',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('392',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('393',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('394',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('395',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('396',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('397',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('398',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('399',' 
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('401','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('402','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('403','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('404','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('405','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('406','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('407','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('408','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('409','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('410','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('411','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('412','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('413','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('414','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('415','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('416','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('417','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('418','  
insert into employees(name) values ("PEPITO")','pruebas');
INSERT INTO tests VALUES ('419','insert into employees(name) values ("valencia_987")','pruebas');
INSERT INTO tests VALUES ('420','    
insert into employees(name768687) values ("valencia1_987")','pruebas');
INSERT INTO tests VALUES ('421','    
insert into employees(name) values ("valencia2_987")','pruebas');
INSERT INTO tests VALUES ('422',' 
insert into employees(name) values ("valencia_987")','pruebas');
INSERT INTO tests VALUES ('423','    
insert into employees(name768687) values ("valencia1_987")','pruebas');
INSERT INTO tests VALUES ('424','    
insert into employees(name) values ("valencia2_987")','pruebas');
INSERT INTO tests VALUES ('425',' 
insert into employees(name) values ("valencia_987")','pruebas');
INSERT INTO tests VALUES ('426','    
insert into employees(name768687) values ("valencia1_987")','pruebas');
INSERT INTO tests VALUES ('427','    
insert into employees(name) values ("valencia2_987")','pruebas');
INSERT INTO tests VALUES ('428',' 
insert into employees(name) values ("valencia_987")','pruebas');
INSERT INTO tests VALUES ('429','    
insert into employees(name768687) values ("valencia1_987")','pruebas');
INSERT INTO tests VALUES ('430','    
insert into employees(name) values ("valencia2_987")','pruebas');
INSERT INTO tests VALUES ('431',' 
insert into employees(name) values ("valencia_987")','pruebas');
INSERT INTO tests VALUES ('432','    
insert into employees(name768687) values ("valencia1_987")','pruebas');
INSERT INTO tests VALUES ('433','    
insert into employees(name) values ("valencia2_987")','pruebas');
INSERT INTO tests VALUES ('434',' 
insert into employees(name) values ("valencia_987")','pruebas');
INSERT INTO tests VALUES ('435','    
insert into employees(name768687) values ("valencia1_987")','pruebas');
INSERT INTO tests VALUES ('436','    
insert into employees(name) values ("valencia2_987")','pruebas');
INSERT INTO tests VALUES ('437',' 
insert into employees(name) values ("valencia_987")','pruebas');
INSERT INTO tests VALUES ('438','    
insert into employees(name768687) values ("valencia1_987")','pruebas');
INSERT INTO tests VALUES ('439','    
insert into employees(name) values ("valencia2_987")','pruebas');
INSERT INTO tests VALUES ('440',' 
insert into employees(name) values ("valencia_987")','pruebas');
INSERT INTO tests VALUES ('441','    
insert into employees(name768687) values ("valencia1_987")','pruebas');
INSERT INTO tests VALUES ('442','    
insert into employees(name) values ("valencia2_987")','pruebas');
INSERT INTO tests VALUES ('443','insert into employees(name) values ("messi")','pruebas');
INSERT INTO tests VALUES ('444','insert into employees(name) values ("cristiano")','pruebas');
INSERT INTO tests VALUES ('447','insert into employees(name) values ("UDL")','pruebas');
INSERT INTO tests VALUES ('448','
INSERT INTO employees(name) values ("Castellon")','pruebas');
INSERT INTO tests VALUES ('449','
insert into employees(name) values ("BALEARES")','pruebas');
INSERT INTO tests VALUES ('450','
insert into employees(name) values ("Cartagena")','pruebas');
INSERT INTO tests VALUES ('451','insert into employees(name) values ("Leganes")','pruebas');
INSERT INTO tests VALUES ('452','
insert into employees(name) values ("Mallorca")','pruebas');
INSERT INTO tests VALUES ('453','
insert into employees(name) values ("Espanyol")','pruebas');
INSERT INTO tests VALUES ('454','
insert into employees(name) values ("Getafe")','pruebas');
INSERT INTO tests VALUES ('455','insert into employees(name) values ("Antonio")','pruebas');
INSERT INTO tests VALUES ('456','
insert into employees(name) values ("Zelu")','pruebas');
INSERT INTO tests VALUES ('457','
insert into employees(name) values ("Andy")','pruebas');
INSERT INTO tests VALUES ('458','
insert into employees(name) values ("Ander")','pruebas');
INSERT INTO tests VALUES ('459','
insert into employees(name) values ("Santos")','pruebas');
INSERT INTO tests VALUES ('460','
insert into employees(name) values ("Caneda")','pruebas');
INSERT INTO tests VALUES ('461','insert into employees(name) values ("lio10")','pruebas');
INSERT INTO tests VALUES ('462','
insert into employees(name) values ("Luis9")','pruebas');
INSERT INTO tests VALUES ('463','
insert into employees(name) values ("Arthur8")','pruebas');
INSERT INTO tests VALUES ('464','
insert into employees(name) values ("Jordi18")','pruebas');
INSERT INTO tests VALUES ('465','
insert into employees(name) values ("Antoine7")','pruebas');
INSERT INTO tests VALUES ('466','
insert into employees(name) values ("Ousmane11")','pruebas');
INSERT INTO tests VALUES ('469','fdsadsfasdf','tfm2');
INSERT INTO tests VALUES ('470','asdfasdfad','pruebas');
INSERT INTO tests VALUES ('471','insert into employees(name) values ("carles")','pruebas');
INSERT INTO tests VALUES ('472',' insert into employees(name) values ("salvador")','pruebas');
INSERT INTO tests VALUES ('473',' insert into employees(name) values ("pe�a")','pruebas');
INSERT INTO tests VALUES ('474','insert into employees(name22) values ("carles")','pruebas');
INSERT INTO tests VALUES ('476','insert into employees(name) values ("perico")','pruebas');
INSERT INTO tests VALUES ('477',' insert into employees(name) values ("lionel")','pruebas');
INSERT INTO tests VALUES ('478','insert into employees(name) values ("perico33")','pruebas');
INSERT INTO tests VALUES ('479',' insert into employees(name) values ("perico22")','pruebas');
INSERT INTO tests VALUES ('480','insert into employees (name) valuesss ("cristian milani")','pruebas');
INSERT INTO tests VALUES ('481','insert into employees values ("cano")','pruebas');
INSERT INTO tests VALUES ('482','insert into employees values ("pl")','pruebas');
INSERT INTO tests VALUES ('483','
insert into employees values ("pl2")','pruebas');
INSERT INTO tests VALUES ('484','
insert into employees values ("pl3")','pruebas');
INSERT INTO tests VALUES ('486','insert into employees("pep guardiola")','pruebas');
INSERT INTO tests VALUES ('487','insert into employees("pep guardiola23432")','pruebas');
INSERT INTO tests VALUES ('488','asfasdfdfadsafads','pruebas');
INSERT INTO tests VALUES ('489','fasfasdfasdfasdfad','pruebas');
INSERT INTO tests VALUES ('490','insert into employees(name) values ("jorge")','pruebas');
INSERT INTO tests VALUES ('491','insert into employees values ("MI�O")','pruebas');
INSERT INTO tests VALUES ('492','insert into employees values ("fid")','pruebas');
INSERT INTO tests VALUES ('493','insert into employees values ("MI�O22")','pruebas');
INSERT INTO tests VALUES ('494','insert into employees values ("MI�O33")','pruebas');
INSERT INTO tests VALUES ('497','insert into employees values ("MI�O55")','pruebas');
INSERT INTO tests VALUES ('498','insert into employees values ("MI�O553")','pruebas');
INSERT INTO tests VALUES ('499','insert into employees values ("MI�O123")','pruebas');
INSERT INTO tests VALUES ('500','insert into employees values ("MI�O3311")','pruebas');
INSERT INTO tests VALUES ('501','insert asdfasdfa asAF','pruebas');
INSERT INTO tests VALUES ('502',' asdfiasdfadsf','pruebas');
INSERT INTO tests VALUES ('503','inasdfafsdasdf ','pruebas');
INSERT INTO tests VALUES ('504',' asdfasdfasf','pruebas');
INSERT INTO tests VALUES ('505','insert into employees (name) valuesasaf ("mi�o")','pruebas');
INSERT INTO tests VALUES ('506',' insert into employees (name) valuesasaf ("mi�o22")','pruebas');
INSERT INTO tests VALUES ('507','insert into employees values ("pepito blanco")','pruebas');
INSERT INTO tests VALUES ('508','insert into employees (name) values ("vierne22s")','pruebas');
INSERT INTO tests VALUES ('509','insert into employees(name) values ("pio2")','pruebas');
INSERT INTO tests VALUES ('510','asdfasdfasf','pruebas');
INSERT INTO tests VALUES ('511','insert into pruebas(name) valuessss ("reinav2")','pruebas');
INSERT INTO tests VALUES ('512','afdasfds','pruebas');
INSERT INTO tests VALUES ('513','adfasdfasdfa','pruebas');
INSERT INTO tests VALUES ('514','asdfasdfasdf','pruebas');
INSERT INTO tests VALUES ('515','asfasdfasdfa','pruebas');
INSERT INTO tests VALUES ('516','as','pruebas');
INSERT INTO tests VALUES ('517','asddddddddddddd','pruebas');
INSERT INTO tests VALUES ('518','asdfasdfasdfadsfadfsfdasdfasd','pruebas');
INSERT INTO tests VALUES ('519','insert into employees(name) values ("error")','pruebas');
INSERT INTO tests VALUES ('520','asdfasdfasdf','pruebas');
INSERT INTO tests VALUES ('521','insert into employees(name) values ("hector")','pruebas');
INSERT INTO tests VALUES ('522','insert into employees(name) values ("cristian")','pruebas');
INSERT INTO tests VALUES ('523','insert into employees(name) values ("carlos")','pruebas');
INSERT INTO tests VALUES ('524','ujh','pruebas');
INSERT INTO tests VALUES ('525','insert into employees(name) values ("aver")','pruebas');
INSERT INTO tests VALUES ('495','insert into employees values ("MI�O22")','pruebas');
INSERT INTO tests VALUES ('526','insert into employees(name) values("erroruniro")','pruebas');
INSERT INTO tests VALUES ('527','    insert into employees(name) values("espacio")','pruebas');
INSERT INTO tests VALUES ('528','insert into employees(name) values ("pio")','pruebas');
INSERT INTO tests VALUES ('530','insert into employees(name) values ("tyu")','pruebas');
INSERT INTO tests VALUES ('531','  insert into employees(name) values ("tyu2")','pruebas');
INSERT INTO tests VALUES ('532','INSERT INTO EMPLOYEES(NAME) VALUES ("YO")','pruebas');
INSERT INTO tests VALUES ('533','INSERT INTO EMPLOYEES(NAME) VALUES ("TU")','pruebas');
INSERT INTO tests VALUES ('534','INSERT INTO EMPLOYEES(NAME) VALUES ("EL")','pruebas');
INSERT INTO tests VALUES ('535','INSERT INTO EMPLOYEES(NAME) VALUES("LGRO�ES")','pruebas');
INSERT INTO tests VALUES ('536','INSERT INTO EMPLOYEES(NAME) VALUES("LGRO�ES2222")','pruebas');
INSERT INTO tests VALUES ('315','insert into employees(name) values ("Jesus")','pruebas');
INSERT INTO tests VALUES ('316','insert into employees(name) values ("Mercedes")','pruebas');
INSERT INTO tests VALUES ('317','insert into employees (name) values ("Javier")','pruebas');
INSERT INTO tests VALUES ('318','insert into employees (name) values ("Carmen")','pruebas');
INSERT INTO tests VALUES ('325','insert into PRUEBAS22(prueba) values ("Messi")','pruebas');
INSERT INTO tests VALUES ('326','insert into PRUEBAS22(PRUEBAS") values ("cr")','pruebas');
INSERT INTO tests VALUES ('334','insert into employees(name) values ("cr")','pruebas');
INSERT INTO tests VALUES ('335','insert into employees(name) values ("messi")','pruebas');
INSERT INTO tests VALUES ('337','insert into employees(name) values ("UDL")','pruebas');
INSERT INTO tests VALUES ('338','insert into employees(name) values ("Calahorra")','pruebas');
INSERT INTO tests VALUES ('346','insert into employees(name) values ("valencia2")','pruebas');
INSERT INTO tests VALUES ('347',' insert into employees(name) values ("barcelona2")','pruebas');
INSERT INTO tests VALUES ('348','insert into employees(name) values ("valencia_")','pruebas');
INSERT INTO tests VALUES ('349','insert into employees(name) values ("Lama")','pruebas');
INSERT INTO tests VALUES ('350','insert into employees(name) values ("Paco")','pruebas');
INSERT INTO tests VALUES ('351','insert into employees(name) values ("Albelda")','pruebas');
INSERT INTO tests VALUES ('356','insert into employees(name) values ("valencia1_")','pruebas');
INSERT INTO tests VALUES ('357','insert into employees(name) values ("valencia2_")','pruebas');
INSERT INTO tests VALUES ('359','  
insert into employees(name) values ("valencia1_987")','pruebas');
INSERT INTO tests VALUES ('468','insert into employees (name) values ("pepe")','pruebas');
INSERT INTO tests VALUES ('537','insert into employees(name) values ("Marta")','pruebas');
INSERT INTO tests VALUES ('538','
insert into employees(name) values ("Juan")','pruebas');
INSERT INTO tests VALUES ('539','
insert into employees(name) values ("Rosa")','pruebas');
INSERT INTO tests VALUES ('540','
insert into employees(name) values ("Angel")','pruebas');
INSERT INTO tests VALUES ('541','
update employees set name="Garcia" where idemp=2 or idemp=4','pruebas');
INSERT INTO tests VALUES ('542','insert into employees(name) values ("unicooo")','pruebas');
INSERT INTO tests VALUES ('543','insert into employees values (1, "Marta", "Lopez")','dvd');
INSERT INTO tests VALUES ('544','
insert into employees values (2, "Juan", "Lopez")','dvd');
INSERT INTO tests VALUES ('545','
insert into employees values (3, "Rosa", "Lopez")','dvd');
INSERT INTO tests VALUES ('546','
insert into employees values (4, "Angel", "Lopez")','dvd');
INSERT INTO tests VALUES ('547','
update employees set last_name="Garcia" where id=2 or id=4','dvd');
INSERT INTO tests VALUES ('548','insert into employees values (1, "Marta", "Lopez")','dvd');
INSERT INTO tests VALUES ('549','
insert into employees values (2, "Juan", "Lopez")','dvd');
INSERT INTO tests VALUES ('550','
update employees set last_name="Garcia" where id=2 or id=4','dvd');
INSERT INTO tests VALUES ('551','insert into employees values (1, "Marta", "Lopez")','dvd');
INSERT INTO tests VALUES ('552','
insert into employees values (2, "Juan", "Lopez")','dvd');
INSERT INTO tests VALUES ('553','
insert into employees values (3, "Rosa", "Lopez")','dvd');
INSERT INTO tests VALUES ('554','
insert into employees values (4, "Angel", "Lopez")','dvd');
INSERT INTO tests VALUES ('555','
update employees set last_name="Garcia" where id=2 or id=4','dvd');
INSERT INTO tests VALUES ('556','insert into employees values (1, "Marta", "Lopez")','dbd_rental_mercedes');
INSERT INTO tests VALUES ('557','
insert into employees values (2, "Juan", "Lopez")','dbd_rental_mercedes');
INSERT INTO tests VALUES ('558','
insert into employees values (3, "Rosa", "Lopez")','dbd_rental_mercedes');
INSERT INTO tests VALUES ('559','
insert into employees values (4, "Angel", "Lopez")','dbd_rental_mercedes');
INSERT INTO tests VALUES ('560','
update employees set last_name="Garcia" where id=2 or id=4','dbd_rental_mercedes');
INSERT INTO tests VALUES ('496','insert into employees values ("MI�O22")','pruebas');
INSERT INTO tests VALUES ('529','insert into employees(name) values ("sergioRod")','pruebas');
INSERT INTO triggers VALUES ('172','casterllon','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','castellon desc');
INSERT INTO triggers VALUES ('19','nombre de prueba','trigger header','trigger function','cristian','tfm','descripcion');
INSERT INTO triggers VALUES ('29','prueba 99','asdfa','afasda','cristian','tfm','asdfa');
INSERT INTO triggers VALUES ('38','nombre trigger grabar','CREATE TRIGGER grabar_operaciones AFTER INSERT OR UPDATE OR DELETE
    ON numeros FOR EACH STATEMENT 
    EXECUTE PROCEDURE grabar_operaciones();','CREATE OR REPLACE FUNCTION grabar_operaciones() RETURNS TRIGGER AS $grabar_operaciones$
  DECLARE
  BEGIN
    
    INSERT INTO cambios (
                nombre_disparador,
                tipo_disparador,
                nivel_disparador,
                comando) 
        VALUES (               
                TG_NAME,
                TG_WHEN,
                TG_LEVEL,
                TG_OP
               );

    RETURN NULL;
  END;
$grabar_operaciones$ LANGUAGE plpgsql;','prueba','tfm','ejemplo de trigger ');
INSERT INTO triggers VALUES ('39','MILANI','CREATE TRIGGER trigg_stock_insert000 BEFORE INSERT ON users FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger000();','CREATE FUNCTION stock_insert_trigger000() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || "VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian','tfm','DESC milani');
INSERT INTO triggers VALUES ('40','trigger cristian','CREATE TRIGGER trigg_stock_insert0 BEFORE INSERT ON users FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger0();','CREATE FUNCTION stock_insert_trigger0() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian','tfm','esto es una prueba de trigger');
INSERT INTO triggers VALUES ('41','prueba90','CREATE TRIGGER trigg_stock_insert90 BEFORE INSERT ON users FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger90();','CREATE FUNCTION stock_insert_trigger90() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || "VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql','cristian','tfm','prueba90');
INSERT INTO triggers VALUES ('43','pruebas','CREATE TRIGGER trigg_stock_insert BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger();','CREATE FUNCTION stock_insert_trigger() RETURNS TRIGGER AS $$ BEGIN IF extract(year FROM NEW.day) = 2018 THEN EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || "VALUES ($1.*)" USING NEW; END IF; RETURN NULL; END; $$ LANGUAGE plpgsql;','cristian','pruebasInsert','Descripcion de insert');
INSERT INTO triggers VALUES ('45','pruebas2','CREATE TRIGGER trigg_stock_insert BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger();','CREATE FUNCTION stock_insert_trigger() RETURNS TRIGGER AS $$ BEGIN IF extract(year FROM NEW.day) = 2018 THEN EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || "VALUES ($1.*)" USING NEW; END IF; RETURN NULL; END; $$ LANGUAGE plpgsql;','cristian','pruebasInsert','Descripcion de insert');
INSERT INTO triggers VALUES ('46','pruebas domingo2','CREATE FUNCTION stock_insert_trigger() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || "VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','CREATE TRIGGER trigg_stock_insert BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger();','cristian','pruebas','desc domingo3');
INSERT INTO triggers VALUES ('47','name pruebas','CREATE TRIGGER trigg_stock_insert BEFORE INSERT ON t FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger();','CREATE FUNCTION stock_insert_trigger() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || "VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql','cristian','tfm','desc name pruebas');
INSERT INTO triggers VALUES ('48','pruebas de trigger','CREATE TRIGGER trigg_stock_insert999 BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger999();','CREATE FUNCTION stock_insert_trigger999() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || "VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql','hemilani@hotmail.com','pruebas','descripcion de trigger');
INSERT INTO triggers VALUES ('49','generico','CREATE TRIGGER nombreTrigger BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncion();','CREATE FUNCTION nombreFuncion() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian','pruebas','Es el trigger generico para pruebas');
INSERT INTO triggers VALUES ('51','generico_v2','CREATE TRIGGER genericoV2 BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE insert_triggerGenerico();','CREATE FUNCTION insert_triggerGenerico() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian','pruebas','desc generico_v2');
INSERT INTO triggers VALUES ('52','trigger insert','CREATE TRIGGER generico_ins BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE pruebasIns();','CREATE FUNCTION pruebasIns() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "DELETE employees SET name = Logrones" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian','pruebas','desc insert');
INSERT INTO triggers VALUES ('53','triggerSuma','CREATE TRIGGER nombreTriggerSuma BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionSuma();','CREATE FUNCTION nombreFuncionSuma() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day ++1) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian','pruebas','descripcion trigger con suma');
INSERT INTO triggers VALUES ('54','trigger resta','CREATE TRIGGER nombreTriggerResta BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionResta();','CREATE FUNCTION nombreFuncionResta() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" ||2/1/0|| date_part("quarter", NEW.day) ||" VALUES ($1)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian','pruebas','descripcion trigger con resta');
INSERT INTO triggers VALUES ('55','trigger and','CREATE TRIGGER nombreTriggerAnd BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionAnd();','CREATE FUNCTION nombreFuncionAnd() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || OR || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian','pruebas','descripcion de trigger con AND');
INSERT INTO triggers VALUES ('56','trigger TRUE','CREATE TRIGGER nombreTriggerTrue BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionTrue();','CREATE FUNCTION nombreFuncionTrue() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || FALSE || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian','pruebas','descripcion del trigger con TRUE');
INSERT INTO triggers VALUES ('57','trigger row','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow();','CREATE FUNCTION nombreFuncionRow() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian','pruebas','descripcion trigger row');
INSERT INTO triggers VALUES ('59','pruebas sabado','CREATE TRIGGER trigg_insert_milani BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_milani();','CREATE FUNCTION stock_milani() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2019_t"  || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','milani1991@hotmail.com','pruebas','pruebas sabado');
INSERT INTO triggers VALUES ('177','pruebas vi10','CREATE TRIGGER log_last3 BEFORE UPDATE
    ON employees FOR EACH ROW
    EXECUTE PROCEDURE log_last3();','CREATE FUNCTION log_last3()
  RETURNS trigger AS
$BODY$
BEGIN
 IF NEW.last_name <> OLD.last_name THEN                        
 INSERT INTO employee_audits(employee_id,last_name,changed_on)
 VALUES(OLD.id,OLD.last_name,now());    
 END IF;
 
 RETURN NEW;
END;
$BODY$
LANGUAGE "plpgsql";','cristian@hotmail.com','pruebas','pruebas vi_112');
INSERT INTO triggers VALUES ('95','pruebas del martes 07072020','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','desc pruebas martes 070707');
INSERT INTO triggers VALUES ('100','pruebas miercoles','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();
','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','desc pruebas miercoes');
INSERT INTO triggers VALUES ('104','adfasdf','CREATE TRIGGER price_trigger1234
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit1234();','CREATE FUNCTION public.price_audit1234()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','asdfas');
INSERT INTO triggers VALUES ('105','asfasfd','   CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','asdfasdf');
INSERT INTO triggers VALUES ('106','pruebas martes','  CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','desc martes');
INSERT INTO triggers VALUES ('107','asfasdf','CREATE TRIGGER price_trigger77777
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit77777();','CREATE FUNCTION public.price_audit77777()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','asfasfd');
INSERT INTO triggers VALUES ('108','asd','CREATE TRIGGER price_triggerCris
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_auditCris();','CREATE FUNCTION public.price_auditCris()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','asd');
INSERT INTO triggers VALUES ('109','tttt','   CREATE TRIGGER price_triggerCris
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_auditCris();','CREATE FUNCTION public.price_auditCris()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','tttt');
INSERT INTO triggers VALUES ('101','asdfasdfads_v222222222','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','asfdasdfasd_v2222222222');
INSERT INTO triggers VALUES ('58','papapap_usado','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian();','CREATE FUNCTION nombreFuncionCristian() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','pruebas','popopo_usado');
INSERT INTO triggers VALUES ('92','miercoles definitiva','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();
','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','miercoles definitiva');
INSERT INTO triggers VALUES ('110','sss','   CREATE TRIGGER price_triggerHector2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_auditHector();','    CREATE FUNCTION public.price_auditHector2()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','ssss');
INSERT INTO triggers VALUES ('178','pru viernes','CREATE TRIGGER log_last_mercedes BEFORE UPDATE
    ON employees FOR EACH ROW
    EXECUTE PROCEDURE log_last_mercedes();','CREATE OR REPLACE FUNCTION log_last_mercedes()
  RETURNS trigger AS
$BODY$
BEGIN
 IF NEW.last_name <> OLD.last_name THEN                        
 INSERT INTO employee_audits(employee_id,last_name,changed_on)
 VALUES(OLD.id,OLD.last_name,now());    
 END IF;
 
 RETURN NEW;
END;
$BODY$
LANGUAGE "plpgsql";','cristian@hotmail.com','pruebas','prue viernes 2');
INSERT INTO triggers VALUES ('114','GF','CREATE TRIGGER price_triggerpop
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_auditpop();','CREATE FUNCTION public.price_auditpop()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','GF');
INSERT INTO triggers VALUES ('115','lkl','  CREATE TRIGGER price_triggerlo
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_auditlo();','CREATE FUNCTION public.price_auditlo()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','lklk');
INSERT INTO triggers VALUES ('117','meesi_v2','CREATE TRIGGER price_triggerMessi2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_auditMessi2();','CREATE FUNCTION public.price_auditMessi2()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;
','cristian@hotmail.com','pruebas','messi_v2');
INSERT INTO triggers VALUES ('103','asdfasdfasdf_v22','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','adsfasdfadsfasd_v22');
INSERT INTO triggers VALUES ('118','sin vacios_9000','CREATE TRIGGER price_trigger435
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit435();','CREATE FUNCTION public.price_audit435()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','desc sin vacios_9000');
INSERT INTO triggers VALUES ('119','sin vacios_5577','CREATE TRIGGER price_trigger2233
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2233();','CREATE FUNCTION public.price_audit2233()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','desc sin vacios_5577');
INSERT INTO triggers VALUES ('120','sin vacios_0909','CREATE TRIGGER price_trigger223111
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit223111();','CREATE FUNCTION public.price_audit223111()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','desc sin vacios_0909');
INSERT INTO triggers VALUES ('121','aa_v2','CREATE TRIGGER price_trigger2
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit2();','CREATE FUNCTION public.price_audit2()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','aa_v2');
INSERT INTO triggers VALUES ('113','5555555','CREATE TRIGGER price_triggerre
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_auditre();','CREATE FUNCTION public.price_auditre()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','5555555');
INSERT INTO triggers VALUES ('175','pruebas vi','CREATE TRIGGER log_last BEFORE UPDATE
    ON employees FOR EACH ROW
    EXECUTE PROCEDURE log_last();','CREATE OR REPLACE FUNCTION log_last()
  RETURNS trigger AS
$BODY$
BEGIN
 IF NEW.last_name <> OLD.last_name THEN                        
 INSERT INTO employee_audits(employee_id,last_name,changed_on)
 VALUES(OLD.id,OLD.last_name,now());    
 END IF;
 
 RETURN NEW;
END;
$BODY$
LANGUAGE "plpgsql";','cristian@hotmail.com','pruebas','pruebas vi');
INSERT INTO triggers VALUES ('179','pru viernes33','CREATE TRIGGER log_last_mercedes33 BEFORE UPDATE
    ON employees FOR EACH ROW
    EXECUTE PROCEDURE log_last_mercedes33();','CREATE FUNCTION log_last_mercedes33()
  RETURNS trigger AS
$BODY$
BEGIN
 IF NEW.last_name <> OLD.last_name THEN                        
 INSERT INTO employee_audits(employee_id,last_name,changed_on)
 VALUES(OLD.id,OLD.last_name,now());    
 END IF;
 
 RETURN NEW;
END;
$BODY$
LANGUAGE "plpgsql"; ','cristian@hotmail.com','pruebas','prue viernes 23');
INSERT INTO triggers VALUES ('129','aa90','CREATE TRIGGER price_trigger90
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit90();','CREATE FUNCTION public.price_audit90()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','aa90');
INSERT INTO triggers VALUES ('131','asdfasdfa','CREATE TRIGGER price_triggerzza
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_auditzz();','   CREATE FUNCTION public.price_auditzza()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','   sadfasdfaa');
INSERT INTO triggers VALUES ('132','pruebas ','CREATE TRIGGER price_triggerdd
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_auditdd();','CREATE FUNCTION public.price_auditdd()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','pruebas zz');
INSERT INTO triggers VALUES ('135','pruebas000','CREATE TRIGGER price_trigger123123
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit123123();','CREATE FUNCTION public.price_audit123123()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','desc pruebas000');
INSERT INTO triggers VALUES ('136','aa909012322','CREATE TRIGGER price_trigger9090
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit9090();','CREATE FUNCTION public.price_audit9090()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','aa909012322');
INSERT INTO triggers VALUES ('126','aa_v22330001','CREATE TRIGGER price_trigger22330001
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit22330001();','CREATE FUNCTION public.price_audit22330001()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','aa_v22330001');
INSERT INTO triggers VALUES ('139','papapap_v2','CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian();','CREATE FUNCTION nombreFuncionCristian() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql;','cristian@hotmail.com','pruebas','popopo_v2');
INSERT INTO triggers VALUES ('140','SI','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','SI');
INSERT INTO triggers VALUES ('141','NO','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','NO');
INSERT INTO triggers VALUES ('152','si90902','CREATE TRIGGER price_trigger23222
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit23222();','CREATE FUNCTION public.price_audit23222()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','si90902');
INSERT INTO triggers VALUES ('166','aa_semilani1644','CREATE TRIGGER price_secristian164
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_secristian164();','CREATE FUNCTION public.price_secristian164()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','aa_semilani1644');
INSERT INTO triggers VALUES ('180','cris','CREATE TRIGGER pruebas BEFORE UPDATE
    ON employees FOR EACH ROW
    EXECUTE PROCEDURE pruebas();','CREATE OR REPLACE FUNCTION pruebas()
  RETURNS trigger AS
$BODY$
BEGIN
 IF NEW.last_name <> OLD.last_name THEN                        
 INSERT INTO employee_audits(employee_id,last_name,changed_on)
 VALUES(OLD.id,OLD.last_name,now());    
 END IF;
 
 RETURN NEW;
END;
$BODY$
LANGUAGE "plpgsql";','cristian@hotmail.com','pruebas','cris');
INSERT INTO triggers VALUES ('170','aa_semilani1644311','CREATE TRIGGER price_secristian16411
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_secristian16411();','CREATE FUNCTION public.price_secristian16411()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','aa_semilani1644311');
INSERT INTO triggers VALUES ('196','pruebas 2407','CREATE TRIGGER log_last_name_changesT BEFORE UPDATE
    ON employees FOR EACH ROW
    EXECUTE PROCEDURE log_last_name_changes();','CREATE FUNCTION log_last_name_changes()
  RETURNS trigger AS
$BODY$
BEGIN
 IF NEW.last_name <> OLD.last_name THEN                        
 INSERT INTO employee_audits(employee_id,last_name,changed_on)
 VALUES(OLD.id,OLD.last_name,now());    
 END IF;
 
 RETURN NEW;
END;
$BODY$
LANGUAGE "plpgsql";','cristian@hotmail.com','pruebas','pruebas 2407');
INSERT INTO triggers VALUES ('199','pruebas 24075','CREATE TRIGGER log_last_name_changesT BEFORE UPDATE
    ON employees FOR EACH ROW
    EXECUTE PROCEDURE log_last_name_changes();','CREATE FUNCTION log_last_name_changes()
  RETURNS trigger AS
$BODY$
BEGIN
 IF NEW.last_name <> OLD.last_name THEN                        
 INSERT INTO employee_audits(employee_id,last_name,changed_on)
 VALUES(OLD.id,OLD.last_name,now());    
 END IF;
 
 RETURN NEW;
END;
$BODY$
LANGUAGE "plpgsql";','cristian@hotmail.com','pruebas','pruebas 24073');
INSERT INTO triggers VALUES ('208','asdffasd','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas',NULL);
INSERT INTO triggers VALUES ('209','AFASDFFADSFDA','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','      ');
INSERT INTO triggers VALUES ('210','asdfadsfad','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas',NULL);
INSERT INTO triggers VALUES ('204','barsa22342','CREATE TRIGGER log_last_name_changesT BEFORE UPDATE
    ON employees FOR EACH ROW
    EXECUTE PROCEDURE log_last_name_changes();','CREATE FUNCTION log_last_name_changes()
  RETURNS trigger AS
$BODY$
BEGIN
 IF NEW.last_name <> OLD.last_name THEN                        
 INSERT INTO employee_audits(employee_id,last_name,changed_on)
 VALUES(OLD.id,OLD.last_name,now());    
 END IF;
 
 RETURN NEW;
END;
$BODY$
LANGUAGE "plpgsql";','cristian@hotmail.com','pruebas','barsa22342');
INSERT INTO triggers VALUES ('205','ser','CREATE TRIGGER sergio
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE sergio();','CREATE FUNCTION sergio()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','ser');
INSERT INTO triggers VALUES ('206','ser2','CREATE TRIGGER sergio2
    AFTER INSERT OR UPDATE
    ON employees
    FOR EACH ROW
    EXECUTE PROCEDURE sergio2();','CREATE FUNCTION sergio2()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','ser2');
INSERT INTO triggers VALUES ('207',NULL,'CREATE TRIGGER martes
    AFTER INSERT OR UPDATE
    ON employees
    FOR EACH ROW
    EXECUTE PROCEDURE martes();','CREATE FUNCTION martes()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','    ');
INSERT INTO triggers VALUES ('211','asdfasdfafd','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas',NULL);
INSERT INTO triggers VALUES ('220','asdfasdfda','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','asdfdasdf');
INSERT INTO triggers VALUES ('221','dafadffda','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','     ');
INSERT INTO triggers VALUES ('222','asdfasfd','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','asdfasfd');
INSERT INTO triggers VALUES ('223','afassdf222','CREATE TRIGGER price_trigger
    AFTER INSERT OR UPDATE
    ON public.employees
    FOR EACH ROW
    EXECUTE PROCEDURE public.price_audit();','CREATE FUNCTION public.price_audit()
    RETURNS trigger
    LANGUAGE "plpgsql"
AS $BODY$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$BODY$;','cristian@hotmail.com','pruebas','asdfasfd');
INSERT INTO users VALUES ('cristian','cristian','f');
INSERT INTO users VALUES ('prueba@hotmail.com','prueba',NULL);
INSERT INTO users VALUES ('milani1990@hotmail.es','milani',NULL);
INSERT INTO users VALUES ('prueba','prueba',NULL);
INSERT INTO users VALUES ('messi@hotmail.com','messi','t');
INSERT INTO users VALUES ('cr@hotmail.com','cr','f');
INSERT INTO users VALUES ('hector@hotmail.com','hector','f');
INSERT INTO users VALUES ('CARLOS@hotmail.com','carlos','f');
INSERT INTO users VALUES ('mama@hotmail.com','mama','f');
INSERT INTO users VALUES ('papa@hotmail.com','papa','f');
INSERT INTO users VALUES ('papa@hotmailasdfasdf','asdfasdf','f');
INSERT INTO users VALUES ('papa@hotmailasdfasdf222','asdfasfda','f');
INSERT INTO users VALUES ('ASDFASDFASF@SADFASDF','AAAA','f');
INSERT INTO users VALUES ('asdfasdfadsafd@asdfaf.com','asd','f');
INSERT INTO users VALUES ('asdfasdfadsafd@asdfa2f.com','aaaa','f');
INSERT INTO users VALUES ('audi@hotmail.com','audi','f');
INSERT INTO users VALUES ('aaaaa@hotmail.com','aaa','f');
INSERT INTO users VALUES ('messi2@hotmail.com','messi2','f');
INSERT INTO users VALUES ('sergio@hotmail.com','sergio','t');
INSERT INTO users VALUES ('pepito@hotmail.com','pepito','f');
INSERT INTO users VALUES ('hemilani@hotmail.com','hemilani','f');
INSERT INTO users VALUES ('jesus@hotmail.com','jesus','f');
INSERT INTO users VALUES ('milani1991@hotmail.com','milani','f');
INSERT INTO users VALUES ('cristian@hotmail.com','cristian','f');
INSERT INTO users VALUES ('pepe@hotmail.com','pepe','t');
INSERT INTO users VALUES ('pepe2@hotmail.com','pepe2','f');
