<?php
session_start();
	
	$conexion = pg_connect($_SESSION['conexion']);
	
								
								
	//Recuperamos el id modificado al hacer click 
	$idsuite =$_POST['idsuite'];
	
    
	$eliminado = "delete from suites where idsuite = '$idsuite'";
							

	pg_query ($conexion, $eliminado);

	//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
	pg_free_result($eliminado);
	
	
								 
	//Cerramos la conexión
	pg_close($conexion);
								
	header('Location: suites.php');
								
								
?>