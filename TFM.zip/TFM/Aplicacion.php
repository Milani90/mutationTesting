<?php
// start a session
session_start();
 
// manipulate session variables


?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Mutation Triggers</title>
  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  
  <link href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:500,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,800,800i" rel="stylesheet">
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">

<!-- LISTBOX -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/prettify/r298/prettify.min.css">
  <link rel="stylesheet" type="text/css" href="src/bootstrap-duallistbox.css">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script src="https://cdn.rawgit.com/google/code-prettify/master/loader/run_prettify.js"></script>
  <script src="src/jquery.bootstrap-duallistbox.js"></script>
  


<!-- FIN LISTBOX-->


  <!-- Custom styles for this template -->
  <link href="css/resume.min.css" rel="stylesheet">
<script>
  var demo1 = $('select[name="duallistbox_demo2"]').bootstrapDualListbox();
  $("#demoform").submit(function() {
    alert($('[name="duallistbox_demo2[]"]').val());
    return false;
  });

      var demo2 = $('.demo2').bootstrapDualListbox({
        nonSelectedListLabel: 'Non-selected',
        selectedListLabel: 'Selected',
        preserveSelectionOnMove: 'moved',
        moveOnSelect: false,
        //nonSelectedFilter: 'ion ([7-9]|[1][0-2])'
      });
    </script>
</head>

<body class="container">
<!--
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
    <a class="navbar-brand js-scroll-trigger" href="#page-top">
      <span class="d-block d-lg-none">Mutation Triggers</span>
      <span class="d-none d-lg-block">
        <img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="img/PL_PgSQL.png" alt="">
      </span>
	  
    </a>
	<br>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav">


        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="triggers.php">Triggers</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="suites.php">Suites</a>
        </li>

        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="operadores.php">Mutation operators</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="#awards">Profile</a>
        </li>
      </ul>
    </div>
  </nav>
-->

<br><br><br>
  <div class="row" style="padding-right: 10px;  padding-left: 100px;">
  <form id="demoform" action="#" method="post">
  <!--<div class="col-md-7">-->
    <select multiple="multiple" size="10" name="duallistbox_demo2[]" class="demo2" title="duallistbox_demo2[]">
      <option value="option1">Option 1</option>
      <option value="option2">Option 2</option>
      <option value="option3" >Option 3</option>
      <option value="option4">Option 4</option>
      <option value="option5">Option 5</option>
      <option value="option6" >Option 6</option>
      <option value="option7">Option 7</option>
      <option value="option8">Option 8</option>
      <option value="option9">Option 9</option>
      <option value="option0">Option 10</option>
      <option value="option0">Option 11</option>
      <option value="option0">Option 12</option>
      <option value="option0">Option 13</option>
      <option value="option0">Option 14</option>
      <option value="option0">Option 15</option>
      <option value="option0">Option 16</option>
      <option value="option0">Option 17</option>
      <option value="option0">Option 18</option>
      <option value="option0">Option 19</option>
      <option value="option0">Option 20</option>
    </select>
	
	 <button type="submit" class="btn btn-default btn-block">Submit data</button>
</form>
   </div>

  

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for this template -->
  <script src="js/resume.min.js"></script>

</body>

</html>
