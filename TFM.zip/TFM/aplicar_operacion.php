<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>FlashTemplateDesign Free Css Template</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styles.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>

<div id="bg">

<div id="main">
<div id="maintop"></div>
<!-- header begins -->
<div id="header">
	<div id="buttons">
		<ul>
			<li class="first"><a href="index2.html"  title="">Home</a></li>
			<li><a href="login4.php" title="">Aplicacion</a></li>
			<li><a href="operadores.php" title="">Operadores</a></li>
			<li><a href="test.php" title="">Test</a></li>
			<li><a href="#" title="">Contacto</a></li>
		</ul>
	</div>
    <div id="logo"><h1><a href="#">Mutantes Generados</a></h1></div>
</div>
<!-- header ends -->
<!-- content begins -->
<div id="content" >
	<!--
	<div id="right">
        <div id="right_top">
		-->
	
 
 <!--FIN CABECERA-->


<?php

echo '<div style="margin-left: 30px;">';
$conexion = pg_connect($_SESSION['conexion']);

pg_set_client_encoding($conexion, "UNICODE");

//PARA COMPROBAR LA CONEXION CON LA BASE DE DATOS
/*
if(!$conexion){
echo "Error : No ha sido posible realizar la conexion con la base de datos\n";
} else {
echo "Conexion establecida correctamente\n";
}
*/

$contenidoarchivo = file_get_contents('trigger.txt');
$copia = $contenidoarchivo;


$valor = $_POST['operador'];  


foreach($_POST['operador'] as $oper){
  //echo $oper."<br/>";
  //or what ever



if($oper == 1  )
{
	echo "<br>";
	echo "Has marcado la opción 1.";
	echo "<br>";
	if (strpos($contenidoarchivo, 'NEW') !== false) {
		echo "<br>";
	echo "Si es posible realizar la operación";
	}
	else{
		echo "<br>";
	echo "NO es posible realizar la operación";
	}
	echo "<br>";
	$reemplazos = substr_count($contenidoarchivo, 'NEW');
	echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, 'NEW'); 
	echo "<br>";echo "<br>";echo "<br>";
	//echo "<hr align='left' noshade='noshade' size='2' width='100%' />";
	echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
	echo '<br>';
	
	echo $contenidoarchivo;	
	//$original = $contenidoarchivo;	
	$original=$contenidoarchivo;	
	echo "<br><br>";
	echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
	echo '<br>';
	
	//INICIO ALGORITMO
	
	
$mutantes = substr_count($contenidoarchivo, 'NEW');
//echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, 'NEW'); 


for ($contador = 1; $contador <= $mutantes; $contador++){  
  if($contador === 1){
      echo '<br>';
     
      
      $encuentralo = 'NEW';
      $posicion = strpos($contenidoarchivo, $encuentralo);
     
     

      
      $trozo = substr ( $contenidoarchivo , 0 , $posicion + 3  );
      $resto = substr ( $contenidoarchivo , $posicion + 3  );
      
      
     

  echo '<br>';
  $cambiado = str_replace("NEW", "OLD", $trozo);
  

  $actualizado = $cambiado .= $resto; 
	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  echo $actualizado, '<br><br><br><br>';
	  echo '</span>';
	  //INICIO INSERT MUTANTE
	  
	  // Create connection

$conexion = pg_connect($_SESSION['conexion']);
// Check connection
/*
if ($conexion->pg_connect("dbname=Pruebas") or die("Could not connect")) {
    die("Connection failed: " . $conexion->pg_connect("dbname=Pruebas") or die("Could not connect") );
} */

//Trigger
			$encuentra = 'CREATE TRIGGER';
            $pos = strpos($actualizado, $encuentra);
            echo '<br>';
            

            $restoo = substr ( $actualizado , $pos+14  );
            
           
            $auxiliar = explode(" ", $restoo);  
            
            
            $final = str_replace('$', '' ,$auxiliar[1]);
			
			$final = $final . '_' . $contador;
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentra2 = 'FUNCTION';
            $pos2 = strpos($contenidoarchivo, $encuentra2);

            $restoo2 = substr ( $contenidoarchivo , $pos2 + 8  );
            //echo $resto2;
            
            $auxiliar2 = explode(" ", $restoo2);  
            $final2 = str_replace('$', '' ,$auxiliar2[1]);
			
			
           
             
            //fin funcion

//FIN FUNCION

//CUERPOS 
$partes = explode("|", $actualizado);  
			$cuerpofuncion = $partes[0]; //CUERPO FUNCION
			$cuerpotrigger = $partes[1]; //CUERPO TRIGGER
			
			
			

//FIN CUERPOS




	   //$mutante    =   "INSERT INTO mutantes VALUES ('$actualizado');";
	   $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final2','$final', '$cuerpofuncion', '$cuerpotrigger','$oper','');";
//pg_query($conexion,$mutante);

$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}


/*
if (pg_query($conexion,$mutante) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $mutante . "<br>" . pg_last_error($conexion);
}
*/
pg_close($conexion);
	
	  
	  
	  //FIN INSERT MUTANTE
	  
	  
	  
	  

  }
  else{
      
      
      $encuentralo = 'NEW';
      $posicion = strpos($actualizado, $encuentralo, $posicion);
            $contenidoarchivo = substr ( $copia , 0 , $posicion);
      //$prefijo = substr ( $actualizado,0, 8);
      
      
      $resto = substr ( $actualizado , $posicion );    
      $new = 'NEW';
      $old = 'OLD';
      $cambio1 = preg_replace('/NEW/', $old, $resto, 1);
      
      echo '<br>';
      $actualizado = $contenidoarchivo.$cambio1; 
      
	  //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  echo $actualizado, '<br><br><br><br>';
	  echo '</span>';
	  
	  

					
					
					
					
		// Create connection

$conexion = pg_connect($_SESSION['conexion']);
// Check connection
/*
if ($pg_connect()) {
    die("Connection failed: " . $conexion->connect_error);
} */

//Trigger
			$encuentralo3 = 'CREATE TRIGGER';
            $posicion3 = strpos($actualizado, $encuentralo3);
            echo '<br>';
            

            $resto3 = substr ( $actualizado , $posicion3+14  );
            
           
            $aux3 = explode(" ", $resto3);  
            
            
            $final3 = str_replace('$', '' ,$aux3[1]);
			$final3 = $final3 . '_' . $contador;
			
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentralo4 = 'FUNCTION';
            $posicion4 = strpos($contenidoarchivo, $encuentralo4);

            $resto4 = substr ( $contenidoarchivo , $posicion4 + 8  );
            //echo $resto2;
            
            $aux4 = explode(" ", $resto4);  
            $final4 = str_replace('$', '' ,$aux4[1]);
            
			
             
            //fin funcion

//FIN FUNCION


//CUERPOS 
$partes2 = explode("|", $actualizado);  
			$cuerpofuncion2 = $partes2[0]; //CUERPO FUNCION
			$cuerpotrigger2 = $partes2[1]; //CUERPO TRIGGER
			
			
//FIN CUERPOS





	   $mutante    =   "INSERT INTO mutantes VALUES ('$actualizado');";
	    $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final4','$final3', '$cuerpofuncion2', '$cuerpotrigger2','$oper','');";
$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}


/*
if (pg_query($conexion,$mutante) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $mutante . "<br>" . $pg_last_error;
}
*/
pg_close($conexion);
	
      
     
    }
 


}

	
	
	
	
	//FIN ALGORITMO
	
	
	
	
	
	
	
	
	
	
	
	
}
if($oper ==2 )
{
	echo "<br>";
	echo "Has marcado la opción 2.";
	echo "<br>";
	if (strpos($contenidoarchivo, 'OLD') !== false) {
		echo "<br>";
	echo "Si es posible realizar la operación";
	}
	else{
		echo "<br>";
	echo "NO es posible realizar la operación";
	}
	echo "<br>";
	$reemplazos = substr_count($contenidoarchivo, 'OLD');
	echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, 'OLD'); 

	echo "<br><br>";
	echo "<hr align='left' noshade='noshade' size='2' width='100%' />";


	echo '<br>';

	echo $contenidoarchivo;	
	//$original = $contenidoarchivo;	
	$original=$contenidoarchivo;	

	echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
	echo '<br>';
	
	//INICIO ALGORITMO
	

	echo '<br>';
$mutantes = substr_count($contenidoarchivo, 'OLD');
echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, 'OLD'); 


for ($contador = 1; $contador <= $mutantes; $contador++){  
  if($contador === 1){
      echo '<br>';
     
      
      $encuentralo = 'OLD';
      $posicion = strpos($contenidoarchivo, $encuentralo);
     
     

      
      $trozo = substr ( $contenidoarchivo , 0 , $posicion + 3  );
      $resto = substr ( $contenidoarchivo , $posicion + 3  );
      
      
     

  echo '<br>';
  $cambiado = str_replace("OLD", "NEW", $trozo);
  

  $actualizado = $cambiado .= $resto; 
	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  echo $actualizado, '<br><br><br><br>';
	  echo '</span>';
	  //INICIO INSERT MUTANTE

      
      
      		// Create connection

$conexion = pg_connect($_SESSION['conexion']);
// Check connection
/*

if ($pg_connect()) {
    die("Connection failed: " . $conexion->connect_error);
} */

//Trigger
			$encuentra = 'CREATE TRIGGER';
            $pos = strpos($actualizado, $encuentra);
            echo '<br>';
            

            $restoo = substr ( $actualizado , $pos+14  );
            
           
            $auxiliar = explode(" ", $restoo);  
            
            
            $final = str_replace('$', '' ,$auxiliar[1]);
			
			$final = $final . '_' . $contador;
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentra2 = 'FUNCTION';
            $pos2 = strpos($contenidoarchivo, $encuentra2);

            $restoo2 = substr ( $contenidoarchivo , $pos2 + 8  );
            //echo $resto2;
            
            $auxiliar2 = explode(" ", $restoo2);  
            $final2 = str_replace('$', '' ,$auxiliar2[1]);
			
			
           
             
            //fin funcion

//FIN FUNCION

//CUERPOS 
$partes = explode("|", $actualizado);  
			$cuerpofuncion = $partes[0]; //CUERPO FUNCION
			$cuerpotrigger = $partes[1]; //CUERPO TRIGGER
			
			
			

//FIN CUERPOS




   //$mutante    =   "INSERT INTO mutantes VALUES ('$actualizado');";
	   $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final2','$final', '$cuerpofuncion', '$cuerpotrigger','$oper','');";
//pg_query($conexion,$mutante);


$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}


/*
if (pg_query($conexion,$mutante) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $mutante . "<br>" . pg_last_error($conexion);
}
*/
pg_close($conexion);
	
	  
	  
	  //FIN INSERT MUTANTE

 }
  else{
      
      
      $encuentralo = 'OLD';
      $posicion = strpos($actualizado, $encuentralo, $posicion);
            $contenidoarchivo = substr ( $copia , 0 , $posicion);
      //$prefijo = substr ( $actualizado,0, 8);
      
      
      $resto = substr ( $actualizado , $posicion );    
      $new = 'NEW';
      $old = 'OLD';
      $cambio1 = preg_replace('/OLD/', $new, $resto, 1);
      
      echo '<br>';
      $actualizado = $contenidoarchivo.$cambio1; 
      
	  //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  echo $actualizado, '<br><br><br><br>';
	  echo '</span>';

	  
	  





	  
	  
	  
	  
	  
        		// Create connection

$conexion = pg_connect($_SESSION['conexion']);
// Check connection
/*
if ($pg_connect()) {
    die("Connection failed: " . $conexion->connect_error);
} */

//Trigger
			$encuentralo3 = 'CREATE TRIGGER';
            $posicion3 = strpos($actualizado, $encuentralo3);
            echo '<br>';
            

            $resto3 = substr ( $actualizado , $posicion3+14  );
            
           
            $aux3 = explode(" ", $resto3);  
            
            
            $final3 = str_replace('$', '' ,$aux3[1]);
			$final3 = $final3 . '_' . $contador;
			
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentralo4 = 'FUNCTION';
            $posicion4 = strpos($contenidoarchivo, $encuentralo4);

            $resto4 = substr ( $contenidoarchivo , $posicion4 + 8  );
            //echo $resto2;
            
            $aux4 = explode(" ", $resto4);  
            $final4 = str_replace('$', '' ,$aux4[1]);
            
			
             
            //fin funcion

//FIN FUNCION


//CUERPOS 
$partes2 = explode("|", $actualizado);  
			$cuerpofuncion2 = $partes2[0]; //CUERPO FUNCION
			$cuerpotrigger2 = $partes2[1]; //CUERPO TRIGGER
			
			
//FIN CUERPOS





	 //  $mutante    =   "INSERT INTO mutantes VALUES ('$actualizado');";
	   $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final4','$final3', '$cuerpofuncion2', '$cuerpotrigger2','$oper','');";
	   
$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}


/*
if (pg_query($conexion,$mutante) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $mutante . "<br>" . $pg_last_error;
}
*/
pg_close($conexion);
//fin conexion
      

      

    }
}
	//FIN ALGORITMO
}


if($oper == 3  )
{
	echo "<br>";
	echo "Has marcado la opción 3.";
	echo "<br>";
  /*
	if (strpos($contenidoarchivo, 'OLD') !== false) {
		echo "<br>";
	echo "Si es posible realizar la operación";
    echo 'true';
	}
	else{
		echo "<br>";
		echo "NO es posible realizar la operación";
		
	}
               */
  
  //$foo = 'Hola mundo';
  if (strlen(stristr($contenidoarchivo,'INSERT'))>0) {
    echo "Ya se encuentra el operador INSERT en el trigger";
             /*
    //if()
    
    //$encuentralo = 'UPDATE';
    //$posicion = strpos($contenidoarchivo, $encuentralo);
    
        //INICIO INSERT
    
      //$trozo = substr ( $contenidoarchivo , 0 , $posicion + 3  );
      //$resto = substr ( $contenidoarchivo , $posicion + 3  );
      
      //echo '<br>';
      $actualizado = str_replace("INSERT", "INSERT OR UPDATE", $contenidoarchivo);
  

     // $actualizado = $cambiado .= $resto; 
      echo 'MUTANTE: ','<br>', $actualizado, '<br><br><br><br>';

    
    //FIN ADD
    else if (strlen(stristr($contenidoarchivo,'DELETE'))>0) {
    
    $encuentralo2 = 'DELETE';
    $posicion2 = strpos($contenidoarchivo, $encuentralo2);
    }
            */
  }
  else
  {
    echo "No se encuentra el operador ADD en el trigger";
  }
      //$encuentralo = 'ADD';
      //$posicion = strpos($contenidoarchivo, $encuentralo);
  
  $conexion = pg_connect($_SESSION['conexion']);
       //INICIO INSERT
    
      
      if (strlen(stristr($contenidoarchivo,'UPDATE'))>0) {
      $actualizado = str_replace("UPDATE", "INSERT OR UPDATE", $contenidoarchivo);
  

     // $actualizado = $cambiado .= $resto; 
      echo 'MUTANTE: ','<br>', $actualizado, '<br><br><br><br>';
	  
	  //CODIGO PARA CUERPO Y NOMBRES DE FUNCIONES 
	  
	  //Trigger
			$encuentra13 = 'CREATE TRIGGER';
            $pos13 = strpos($actualizado, $encuentra13);
            echo '<br>';
            

            $restoo13 = substr ( $actualizado , $pos13 + 14);
            
           
            $auxiliar13 = explode(" ", $restoo13);  
            
            
            $final13 = str_replace('$', '' ,$auxiliar13[1]);
			
			$final13 = $final13 . '_' . $contador;
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentra23 = 'FUNCTION';
            $pos23 = strpos($contenidoarchivo, $encuentra23);

            $restoo23 = substr ( $contenidoarchivo , $pos23 + 8  );
            //echo $resto2;
            
            $auxiliar23 = explode(" ", $restoo23);  
            $final23 = str_replace('$', '' ,$auxiliar23[1]);
			
			
           
             
            //fin funcion

//FIN FUNCION

//CUERPOS 
			$partes3 = explode("|", $actualizado);  
			$cuerpofuncion3 = $partes3[0]; //CUERPO FUNCION
			$cuerpotrigger3 = $partes3[1]; //CUERPO TRIGGER
			
			
			

//FIN CUERPOS




   //$mutante    =   "INSERT INTO mutantes VALUES ('$actualizado');";
	   $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final23','$final13', '$cuerpofuncion3', '$cuerpotrigger3','$oper','');";
	  
	  //FIN CODIGO PARA CUERPO Y NOMBRE DE FUNCIONES
	  
	  
	  
	  

                    }
    //FIN INSERT
  
  
  //INICIO DELETE
  if (strlen(stristr($contenidoarchivo,'DELETE'))>0) { 
    $actualizado = str_replace("DELETE", "DELETE OR INSERT", $contenidoarchivo);
  

     // $actualizado = $cambiado .= $resto; 
      echo 'MUTANTE: ','<br>', $actualizado, '<br><br><br><br>';
	  
	  
	  
	  
	  //CODIGO PARA CUERPO Y NOMBRES DE FUNCIONES 
	  
	  //Trigger
			$encuentra13 = 'CREATE TRIGGER';
            $pos13 = strpos($actualizado, $encuentra13);
            echo '<br>';
            

            $restoo13 = substr ( $actualizado , $pos13 + 14);
            
           
            $auxiliar13 = explode(" ", $restoo13);  
            
            
            $final13 = str_replace('$', '' ,$auxiliar13[1]);
			
			$final13 = $final13 . '_' . $contador;
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentra23 = 'FUNCTION';
            $pos23 = strpos($contenidoarchivo, $encuentra23);

            $restoo23 = substr ( $contenidoarchivo , $pos23 + 8  );
            //echo $resto2;
            
            $auxiliar23 = explode(" ", $restoo23);  
            $final23 = str_replace('$', '' ,$auxiliar23[1]);
			
			
           
             
            //fin funcion

//FIN FUNCION

//CUERPOS 
			$partes3 = explode("|", $actualizado);  
			$cuerpofuncion3 = $partes3[0]; //CUERPO FUNCION
			$cuerpotrigger3 = $partes3[1]; //CUERPO TRIGGER
			
			
			

//FIN CUERPOS




   //$mutante    =   "INSERT INTO mutantes VALUES ('$actualizado');";
	   $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final23','$final13', '$cuerpofuncion2', '$cuerpotrigger2','$oper','');";
	  
	  //FIN CODIGO PARA CUERPO Y NOMBRE DE FUNCIONES
	  
	  

        
  
  
  
                    }
   //FIN DELETE
  
  
         		// Create connection

$conexion = pg_connect($_SESSION['conexion']);
// Check connection
/*
if ($pg_connect()) {
    die("Connection failed: " . $conexion->connect_error);
} */
	   //$mutante    =   "INSERT INTO mutantes  VALUES ('$actualizado');";
$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}

//fin conexion
      
  
  
  
  
  
}

if($oper ==4  )
{
	echo "<br>";
	echo "Has marcado la opción 4.";
	echo "<br>";
	  if (strlen(stristr($contenidoarchivo,'UPDATE'))>0) {
    echo "Sí se encuentra el operador UPDATE en el trigger";
    /*
        $encuentralo = 'ADD';
    $posicion = strpos($contenidoarchivo, $encuentralo);
    
    //INICIO ADD
    
      //$trozo = substr ( $contenidoarchivo , 0 , $posicion + 3  );
      //$resto = substr ( $contenidoarchivo , $posicion + 3  );
      
      //echo '<br>';
      $contenidoarchivo = str_replace("ADD", "ADD OR UPDATE", $contenidoarchivo);
  

     // $actualizado = $cambiado .= $resto; 
      echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';

    
    //FIN ADD
    
    
    
    
    
    
    
    
    
    
  
    $encuentralo2 = 'DELETE';
    $posicion2 = strpos($contenidoarchivo, $encuentralo2);
    
    */
  }
  else
  {
	  echo '<br>';
    echo "No se encuentra el operador UPDATE en el trigger";
	echo '<br>';
    
         //INICIO INSERT
    
      
      if (strlen(stristr($contenidoarchivo,'INSERT'))>0) {
      $actualizado = str_replace("INSERT", "INSERT OR UPDATE", $contenidoarchivo);
  

     // $actualizado = $cambiado .= $resto; 
      echo 'MUTANTE: ','<br>', $actualizado, '<br><br><br><br>';
	  
	  	  //CODIGO PARA CUERPO Y NOMBRES DE FUNCIONES 
	  
	  //Trigger
			$encuentra14 = 'CREATE TRIGGER';
            $pos14 = strpos($actualizado, $encuentra14);
            echo '<br>';
            

            $restoo14 = substr ( $actualizado , $pos14 + 14);
            
           
            $auxiliar14 = explode(" ", $restoo14);  
            
            
            $final14 = str_replace('$', '' ,$auxiliar14[1]);
			
			$final14 = $final14 . '_' . $contador;
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentra24 = 'FUNCTION';
            $pos24 = strpos($contenidoarchivo, $encuentra23);

            $restoo24 = substr ( $contenidoarchivo , $pos24 + 8  );
            //echo $resto2;
            
            $auxiliar24 = explode(" ", $restoo24);  
            $final24 = str_replace('$', '' ,$auxiliar24[1]);
			
			
           
             
            //fin funcion

//FIN FUNCION

//CUERPOS 
			$partes4 = explode("|", $actualizado);  
			$cuerpofuncion4 = $partes4[0]; //CUERPO FUNCION
			$cuerpotrigger4 = $partes4[1]; //CUERPO TRIGGER
			
			
			

//FIN CUERPOS




   //$mutante    =   "INSERT INTO mutantes VALUES ('$actualizado');";
	   $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final24','$final14', '$cuerpofuncion4', '$cuerpotrigger4','$oper','');";
	  
	  //FIN CODIGO PARA CUERPO Y NOMBRE DE FUNCIONES
	  
	  
	  
	  
	  
	  
	  

                    }
    //FIN INSERT
    else if (strlen(stristr($contenidoarchivo,'DELETE'))>0) {
    
     $actualizado = str_replace("DELETE", "DELETE OR UPDATE", $contenidoarchivo);
  

     // $actualizado = $cambiado .= $resto; 
      echo 'MUTANTE: ','<br>', $actualizado, '<br><br><br><br>';

    
    
    }
    
      		// Create connection

//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=Pruebas user=postgres password=root");
$conexion = pg_connect($_SESSION['conexion']);

// Check connection
/*
if ($pg_connect()) {
    die("Connection failed: " . $conexion->connect_error);
} */
	   $mutante    =   "INSERT INTO mutantes  "
                    . " VALUES ('$actualizado');";
$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}

//fin conexion
      
    
    
    
    
  }
}

if($oper ==5  )
{
	echo "<br>";
	echo "Has marcado la opción 5.";
	echo "<br>";
	  if (strlen(stristr($contenidoarchivo,'DELETE'))>0) {
    echo '<br>';
	echo '<br>';
	echo "Ya se encuentra el operador DELETE en el trigger";
	
  }
  else
  {
	  echo '<br>';
    
	echo "No se encuentra el operador DELETE en el trigger";
	
    
    if (strlen(stristr($contenidoarchivo,'INSERT'))>0) {
       $actualizado = str_replace("INSERT", "INSERT OR DELETE", $contenidoarchivo);

      echo 'MUTANTE: ','<br>', $actualizado, '<br><br><br><br>';
   }
   else if  (strlen(stristr($contenidoarchivo,'UPDATE'))>0) {
       $actualizado = str_replace("UPDATE", "UPDATE OR DELETE", $contenidoarchivo);

      echo 'MUTANTE: ','<br>', $actualizado, '<br><br><br><br>';
   
   
  }
}

  		// Create connection

//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=Pruebas user=postgres password=root");
$conexion = pg_connect($_SESSION['conexion']);

// Check connection
/*
if ($pg_connect()) {
    die("Connection failed: " . $conexion->connect_error);
} */
	   $mutante    =   "INSERT INTO mutantes  "
                    . " VALUES ('$actualizado');";
$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}

//fin conexion
      






}

if($oper ==6  )
{
	echo "<br>";
	echo "Has marcado la opción 6.";  //DELETE INSERT 
	echo "<br>";
  if (strlen(stristr($contenidoarchivo,'INSERT'))>0) {
      echo "Sí está el operador DELETE en el trigger";
  }
  else 
  {
      echo "No se encuentra el operador INSERT en el trigger"; 
  }
  




}

if($oper == 7  )
{
	echo "<br>";
	echo "Has marcado la opción 7.";
	echo "<br>";
  
   if (strlen(stristr($contenidoarchivo,'UPDATE'))>0) {
      echo "Sí está el operador UPDATE en el trigger";
      
       if (strlen(stristr($contenidoarchivo,'INSERT'))>0 || strlen(stristr($contenidoarchivo,'DELETE'))>0) {
    
    }
    else 
    {
      echo "No se puede eliminar el operador DELETE al ser la unica operación en el trigger"    ;
	  echo '<br>';
    }   
        
      
      
      
  }
  else 
  {
      echo "No se encuentra el operador UPDATE en el trigger"; 
	  echo '<br>';
  }
  





}






if($oper ==8  )
{
	echo "<br>";
	echo "Has marcado la opción 8.";
	echo "<br>";
  
   if (strlen(stristr($contenidoarchivo,'DELETE'))>0) {
      echo "Sí está el operador DELETE en el trigger";
   
    if (strlen(stristr($contenidoarchivo,'UPDATE'))>0 || strlen(stristr($contenidoarchivo,'INSERT'))>0) {
    
    }
    else 
    {
      echo "No se puede eliminar el operador DELETE al ser la unica operación en el trigger" ;
	  echo '<br>';
    }   
        
      
    }
    else 
    {
      echo "No se encuentra el operador DELETE en el trigger"; 
	  echo '<br>';
  }
  

}



if($oper ==9  )     //change operador logico 
{
	echo "<br>";
	echo "Has marcado la opción 9.";
	echo "<br>";
  
	
  
}


if($oper ==10  )
{
	echo "<br>";
	echo "Has marcado la opción 10.";
	echo "<br>";


}

if($oper ==11  )
{
	echo "<br>";
	echo "Has marcado la opción 11.";
	echo "<br>";


}

if($oper ==12  )
{
	
	echo "<br>";
	echo "Has marcado la opción 12.";
	echo "<br>";
	
	//+,-,*,/
	//SUMA
	if (strpos($contenidoarchivo, '+') !== false) {
		
			//echo "Si es posible realizar la operación";
			
		}
	else{
			
			//echo "NO es posible realizar la operación";
			
	}
	
	$reemplazosSuma = substr_count($contenidoarchivo, '+');
	//echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, '+'); 
	//FIN SUMA
	
	//RESTA
	if (strpos($contenidoarchivo, '-') !== false) {
		
			//echo "Si es posible realizar la operación";
			
		}
	else{
			
			//echo "NO es posible realizar la operación";
			
	}
	echo "<br>";
	$reemplazosResta = substr_count($contenidoarchivo, '-');
	//echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, '-'); 
	
	//FIN RESTA
	//MULTIPLICACION
	if (strpos($contenidoarchivo, '*') !== false) {
		
			//echo "Si es posible realizar la operación";
			
		}
	else{
			
			//echo "NO es posible realizar la operación";
			
	}
	
	$reemplazosMultiplicacion = substr_count($contenidoarchivo, '*');
	//echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, '*'); 
	
	//FIN MULTIPLICACION
	//DIVISION
	if (strpos($contenidoarchivo, '+') !== false) {
		
			//echo "Si es posible realizar la operación";
			
		}
	else{
			
			//echo "NO es posible realizar la operación";
			
	}
	
	$reemplazosDivision = substr_count($contenidoarchivo, '/');
	//echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, '/'); 
	
	//FIN DIVISION
	
	$reemplazosTotales = $reemplazosSuma + $reemplazosResta + $reemplazosMultiplicacion + $reemplazosDivision;
	if ($reemplazosTotales > 0){
		echo "Si es posible realizar la operación 12 ";
		echo '<br>';
		echo "Nº mutantes posibles: ", $reemplazosTotales; 
		echo '<br><br><br>';
		
	}
	else{
		echo "No es posible realizar la operación 12 ";
	}
	
	
	//echo "<hr align='left' noshade='noshade' size='2' width='100%' />";
	echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
	echo '<br>';
	
	echo $contenidoarchivo;	
	//$original = $contenidoarchivo;	
	$original=$contenidoarchivo;	
	echo "<br><br>";
	echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
	echo '<br>';	//inicio codigo
	
	for ($contador = 1; $contador <= $reemplazosTotales; $contador++){  
  if($contador === 1){
      echo '<br>';
     
      
      $encuentralo = '+';
      $posicion = strpos($contenidoarchivo, $encuentralo);
     
     

      
      $trozo = substr ( $contenidoarchivo , 0 , $posicion + 1  );
      $resto = substr ( $contenidoarchivo , $posicion + 1  );
      
      
     

  echo '<br>';
  $cambiado = str_replace("+", "-", $trozo);
  

  $actualizado = $cambiado .= $resto; 
	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  echo $actualizado, '<br><br><br><br>';
	  echo '</span>';
	  //INICIO INSERT MUTANTE
	  
	  // Create connection

$conexion = pg_connect($_SESSION['conexion']);


//Trigger
			$encuentra = 'CREATE TRIGGER';
            $pos = strpos($actualizado, $encuentra);
            echo '<br>';
            

            $restoo = substr ( $actualizado , $pos+14  );
            
           
            $auxiliar = explode(" ", $restoo);  
            
            
            $final = str_replace('$', '' ,$auxiliar[1]);
			
			$final = $final . '_' . $contador;
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentra2 = 'FUNCTION';
            $pos2 = strpos($contenidoarchivo, $encuentra2);

            $restoo2 = substr ( $contenidoarchivo , $pos2 + 8  );
            //echo $resto2;
            
            $auxiliar2 = explode(" ", $restoo2);  
            $final2 = str_replace('$', '' ,$auxiliar2[1]);
			
			
           
             
            //fin funcion

//FIN FUNCION

//CUERPOS 
$partes = explode("|", $actualizado);  
			$cuerpofuncion = $partes[0]; //CUERPO FUNCION
			$cuerpotrigger = $partes[1]; //CUERPO TRIGGER
			
			
			

//FIN CUERPOS




	   //$mutante    =   "INSERT INTO mutantes VALUES ('$actualizado');";
	   $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final2','$final', '$cuerpofuncion', '$cuerpotrigger','$oper','');";
//pg_query($conexion,$mutante);

$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}



pg_close($conexion);
	
	  
	  
	  //FIN INSERT MUTANTE
  }
  else{
      
      $encuentralo = '+';
      $posicion = strpos($actualizado, $encuentralo, $posicion);
            $contenidoarchivo = substr ( $copia , 0 , $posicion);
      //$prefijo = substr ( $actualizado,0, 8);
      
      
      $resto = substr ( $actualizado , $posicion );    
      $new = '-';
      $old = '+';
      $cambio1 = preg_replace('/-/', $old, $resto, 1);
	 
      
      echo '<br>';
      $actualizado = $contenidoarchivo.$cambio1; 
      
	  //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  echo $actualizado, '<br><br><br><br>';
	  echo '</span>';
	  
			
		// Create connection

$conexion = pg_connect($_SESSION['conexion']);


//Trigger
			$encuentralo3 = 'CREATE TRIGGER';
            $posicion3 = strpos($actualizado, $encuentralo3);
            echo '<br>';
            

            $resto3 = substr ( $actualizado , $posicion3+14  );
            
           
            $aux3 = explode(" ", $resto3);  
            
            
            $final3 = str_replace('$', '' ,$aux3[1]);
			$final3 = $final3 . '_' . $contador;
			
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentralo4 = 'FUNCTION';
            $posicion4 = strpos($contenidoarchivo, $encuentralo4);

            $resto4 = substr ( $contenidoarchivo , $posicion4 + 8  );
            //echo $resto2;
            
            $aux4 = explode(" ", $resto4);  
            $final4 = str_replace('$', '' ,$aux4[1]);
            
			
             
            //fin funcion

//FIN FUNCION


//CUERPOS 
$partes2 = explode("|", $actualizado);  
			$cuerpofuncion2 = $partes2[0]; //CUERPO FUNCION
			$cuerpotrigger2 = $partes2[1]; //CUERPO TRIGGER
			
			
//FIN CUERPOS






	    $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final4','$final3', '$cuerpofuncion2', '$cuerpotrigger2','$oper','');";
$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}



pg_close($conexion);
//fin conexion	
      
     
    }
}
	



	
	
	//fin codigo
	
	
	
	
	
  
}
if($oper == 13  )

	{
	echo "<br>";
	echo "Has marcado la opción 13.";
	echo "<br>";
	
	if (strpos($contenidoarchivo, 'AND') !== false) {
		echo "<br>";
	echo "Si es posible realizar la operación";
	}
	else{
		echo "<br>";
	echo "NO es posible realizar la operación";
	}
	echo "<br>";
	$reemplazos = substr_count($contenidoarchivo, 'AND');
	echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, 'AND'); 
	echo "<br>";echo "<br>";echo "<br>";
	//echo "<hr align='left' noshade='noshade' size='2' width='100%' />";
	echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
	echo '<br>';
	
	echo $contenidoarchivo;	
	//$original = $contenidoarchivo;	
	$original=$contenidoarchivo;	
	echo "<br><br>";
	echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
	echo '<br>';
	
	//INICIO ALGORITMO
	
	
$mutantes = substr_count($contenidoarchivo, 'AND');
//echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, 'AND'); 


for ($contador = 1; $contador <= $mutantes; $contador++){  
  if($contador === 1){
      echo '<br>';
     
      
      $encuentralo = 'AND';
      $posicion = strpos($contenidoarchivo, $encuentralo);
     
     

      
      $trozo = substr ( $contenidoarchivo , 0 , $posicion + 3  );
      $resto = substr ( $contenidoarchivo , $posicion + 3  );
      
      
     

  echo '<br>';
  $cambiado = str_replace("AND", "OR", $trozo);
  

  $actualizado = $cambiado .= $resto; 
	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  echo $actualizado, '<br><br><br><br>';
	  echo '</span>';
	  //INICIO INSERT MUTANTE
	  
	  // Create connection

$conexion = pg_connect($_SESSION['conexion']);
// Check connection


//Trigger
			$encuentra = 'CREATE TRIGGER';
            $pos = strpos($actualizado, $encuentra);
            echo '<br>';
            

            $restoo = substr ( $actualizado , $pos+14  );
            
           
            $auxiliar = explode(" ", $restoo);  
            
            
            $final = str_replace('$', '' ,$auxiliar[1]);
			
			$final = $final . '_' . $contador;
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentra2 = 'FUNCTION';
            $pos2 = strpos($contenidoarchivo, $encuentra2);

            $restoo2 = substr ( $contenidoarchivo , $pos2 + 8  );
            //echo $resto2;
            
            $auxiliar2 = explode(" ", $restoo2);  
            $final2 = str_replace('$', '' ,$auxiliar2[1]);
			
			
           
             
            //fin funcion

//FIN FUNCION

//CUERPOS 
$partes = explode("|", $actualizado);  
			$cuerpofuncion = $partes[0]; //CUERPO FUNCION
			$cuerpotrigger = $partes[1]; //CUERPO TRIGGER
			
			
			

//FIN CUERPOS




	   //$mutante    =   "INSERT INTO mutantes VALUES ('$actualizado');";
	   $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final2','$final', '$cuerpofuncion', '$cuerpotrigger','$oper','');";
//pg_query($conexion,$mutante);

$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}


/*
if (pg_query($conexion,$mutante) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $mutante . "<br>" . pg_last_error($conexion);
}
*/
pg_close($conexion);
	
	  
	  
	  //FIN INSERT MUTANTE
	  
	  
	  
	  

  }
  else{
      
      
      $encuentralo = 'AND';
      $posicion = strpos($actualizado, $encuentralo, $posicion);
            $contenidoarchivo = substr ( $copia , 0 , $posicion);

      
      
      $resto = substr ( $actualizado , $posicion );    
      $new = 'AND';
      $old = 'OR';
      $cambio1 = preg_replace('/AND/', $old, $resto, 1);
      
      echo '<br>';
      $actualizado = $contenidoarchivo.$cambio1; 
      
	  //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  echo $actualizado, '<br><br><br><br>';
	  echo '</span>';
	  
	  

					
					
					
					
		// Create connection

$conexion = pg_connect($_SESSION['conexion']);
// Check connection


//Trigger
			$encuentralo3 = 'CREATE TRIGGER';
            $posicion3 = strpos($actualizado, $encuentralo3);
            echo '<br>';
            

            $resto3 = substr ( $actualizado , $posicion3+14  );
            
           
            $aux3 = explode(" ", $resto3);  
            
            
            $final3 = str_replace('$', '' ,$aux3[1]);
			$final3 = $final3 . '_' . $contador;
			
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentralo4 = 'FUNCTION';
            $posicion4 = strpos($contenidoarchivo, $encuentralo4);

            $resto4 = substr ( $contenidoarchivo , $posicion4 + 8  );
            //echo $resto2;
            
            $aux4 = explode(" ", $resto4);  
            $final4 = str_replace('$', '' ,$aux4[1]);
            
			
             
            //fin funcion

//FIN FUNCION


//CUERPOS 
$partes2 = explode("|", $actualizado);  
			$cuerpofuncion2 = $partes2[0]; //CUERPO FUNCION
			$cuerpotrigger2 = $partes2[1]; //CUERPO TRIGGER
			
			
//FIN CUERPOS





	  // $mutante    =   "INSERT INTO mutantes VALUES ('$actualizado');";
	    $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final4','$final3', '$cuerpofuncion2', '$cuerpotrigger2','$oper','');";
$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}


/*
if (pg_query($conexion,$mutante) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $mutante . "<br>" . $pg_last_error;
}
*/
pg_close($conexion);
	
      
     
    }
 


}

	
	//FIN ALGORITMO

}


if($oper == 14)
{

	{
	echo "<br>";
	echo "Has marcado la opción 13.";
	echo "<br>";
	if (strpos($contenidoarchivo, 'OR') !== false) {
		echo "<br>";
	echo "Si es posible realizar la operación";
	}
	else{
		echo "<br>";
	echo "NO es posible realizar la operación";
	}
	echo "<br>";
	$reemplazos = substr_count($contenidoarchivo, 'OR');
	echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, 'OR'); 
	echo "<br>";echo "<br>";echo "<br>";
	//echo "<hr align='left' noshade='noshade' size='2' width='100%' />";
	echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
	echo '<br>';
	
	echo $contenidoarchivo;	
	//$original = $contenidoarchivo;	
	$original=$contenidoarchivo;	
	echo "<br><br>";
	echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
	echo '<br>';
	
	//INICIO ALGORITMO
	
	
$mutantes = substr_count($contenidoarchivo, 'OR');
//echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, 'OR'); 


for ($contador = 1; $contador <= $mutantes; $contador++){  
  if($contador === 1){
      echo '<br>';
     
      
      $encuentralo = 'AND';
      $posicion = strpos($contenidoarchivo, $encuentralo);
     
     

      
      $trozo = substr ( $contenidoarchivo , 0 , $posicion + 3  );
      $resto = substr ( $contenidoarchivo , $posicion + 3  );
      
      
     

  echo '<br>';
  $cambiado = str_replace("OR", "AND", $trozo);
  

  $actualizado = $cambiado .= $resto; 
	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  echo $actualizado, '<br><br><br><br>';
	  echo '</span>';
	  //INICIO INSERT MUTANTE
	  
	  // Create connection

$conexion = pg_connect($_SESSION['conexion']);
// Check connection


//Trigger
			$encuentra = 'CREATE TRIGGER';
            $pos = strpos($actualizado, $encuentra);
            echo '<br>';
            

            $restoo = substr ( $actualizado , $pos+14  );
            
           
            $auxiliar = explode(" ", $restoo);  
            
            
            $final = str_replace('$', '' ,$auxiliar[1]);
			
			$final = $final . '_' . $contador;
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentra2 = 'FUNCTION';
            $pos2 = strpos($contenidoarchivo, $encuentra2);

            $restoo2 = substr ( $contenidoarchivo , $pos2 + 8  );
            //echo $resto2;
            
            $auxiliar2 = explode(" ", $restoo2);  
            $final2 = str_replace('$', '' ,$auxiliar2[1]);
			
			
           
             
            //fin funcion

//FIN FUNCION

//CUERPOS 
$partes = explode("|", $actualizado);  
			$cuerpofuncion = $partes[0]; //CUERPO FUNCION
			$cuerpotrigger = $partes[1]; //CUERPO TRIGGER
			
			
			

//FIN CUERPOS




	   //$mutante    =   "INSERT INTO mutantes VALUES ('$actualizado');";
	   $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final2','$final', '$cuerpofuncion', '$cuerpotrigger','$oper','');";
//pg_query($conexion,$mutante);

$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}


/*
if (pg_query($conexion,$mutante) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $mutante . "<br>" . pg_last_error($conexion);
}
*/
pg_close($conexion);
	
	  
	  
	  //FIN INSERT MUTANTE
	  
	  
	  
	  

  }
  else{
      
      
      $encuentralo = 'OR';
      $posicion = strpos($actualizado, $encuentralo, $posicion);
            $contenidoarchivo = substr ( $copia , 0 , $posicion);

      
      
      $resto = substr ( $actualizado , $posicion );    
      $new = 'OR';
      $old = 'AND';
      $cambio1 = preg_replace('/AND/', $old, $resto, 1);
      
      echo '<br>';
      $actualizado = $contenidoarchivo.$cambio1; 
      
	  //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  echo $actualizado, '<br><br><br><br>';
	  echo '</span>';
	  
	  

					
					
					
					
		// Create connection

$conexion = pg_connect($_SESSION['conexion']);
// Check connection


//Trigger
			$encuentralo3 = 'CREATE TRIGGER';
            $posicion3 = strpos($actualizado, $encuentralo3);
            echo '<br>';
            

            $resto3 = substr ( $actualizado , $posicion3+14  );
            
           
            $aux3 = explode(" ", $resto3);  
            
            
            $final3 = str_replace('$', '' ,$aux3[1]);
			$final3 = $final3 . '_' . $contador;
			
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentralo4 = 'FUNCTION';
            $posicion4 = strpos($contenidoarchivo, $encuentralo4);

            $resto4 = substr ( $contenidoarchivo , $posicion4 + 8  );
            //echo $resto2;
            
            $aux4 = explode(" ", $resto4);  
            $final4 = str_replace('$', '' ,$aux4[1]);
            
			
             
            //fin funcion

//FIN FUNCION


//CUERPOS 
$partes2 = explode("|", $actualizado);  
			$cuerpofuncion2 = $partes2[0]; //CUERPO FUNCION
			$cuerpotrigger2 = $partes2[1]; //CUERPO TRIGGER
			
			
//FIN CUERPOS





	  // $mutante    =   "INSERT INTO mutantes VALUES ('$actualizado');";
	    $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final4','$final3', '$cuerpofuncion2', '$cuerpotrigger2','$oper','');";
$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}


/*
if (pg_query($conexion,$mutante) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $mutante . "<br>" . $pg_last_error;
}
*/
pg_close($conexion);
	
      
     
    }
 


}

	
	
	
	
	//FIN ALGORITMO
	
	
	
	
	
	
	
	
	
	
	
	
}






}

if($oper == 15)

	{
	{
	echo "<br>";
	echo "Has marcado la opción 15.";
	echo "<br>";
	if (strpos($contenidoarchivo, 'FALSE') !== false) {
		echo "<br>";
	echo "Si es posible realizar la operación";
	}
	else{
		echo "<br>";
	echo "NO es posible realizar la operación";
	}
	echo "<br>";
	$reemplazos = substr_count($contenidoarchivo, 'FALSE');
	echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, 'FALSE'); 
	echo "<br>";echo "<br>";echo "<br>";
	//echo "<hr align='left' noshade='noshade' size='2' width='100%' />";
	echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
	echo '<br>';
	
	echo $contenidoarchivo;	
	//$original = $contenidoarchivo;	
	$original=$contenidoarchivo;	
	echo "<br><br>";
	echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
	echo '<br>';
	
	//INICIO ALGORITMO
	
	
$mutantes = substr_count($contenidoarchivo, 'FALSE');
//echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, 'FALSE'); 


for ($contador = 1; $contador <= $mutantes; $contador++){  
  if($contador === 1){
      echo '<br>';
     
      
      $encuentralo = 'TRUE';
      $posicion = strpos($contenidoarchivo, $encuentralo);
     
     

      
      $trozo = substr ( $contenidoarchivo , 0 , $posicion + 3  );
      $resto = substr ( $contenidoarchivo , $posicion + 3  );
      
      
     

  echo '<br>';
  $cambiado = str_replace("OR", "AND", $trozo);
  

  $actualizado = $cambiado .= $resto; 
	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  echo $actualizado, '<br><br><br><br>';
	  echo '</span>';
	  //INICIO INSERT MUTANTE
	  
	  // Create connection

$conexion = pg_connect($_SESSION['conexion']);
// Check connection


//Trigger
			$encuentra = 'CREATE TRIGGER';
            $pos = strpos($actualizado, $encuentra);
            echo '<br>';
            

            $restoo = substr ( $actualizado , $pos+14  );
            
           
            $auxiliar = explode(" ", $restoo);  
            
            
            $final = str_replace('$', '' ,$auxiliar[1]);
			
			$final = $final . '_' . $contador;
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentra2 = 'FUNCTION';
            $pos2 = strpos($contenidoarchivo, $encuentra2);

            $restoo2 = substr ( $contenidoarchivo , $pos2 + 8  );
            //echo $resto2;
            
            $auxiliar2 = explode(" ", $restoo2);  
            $final2 = str_replace('$', '' ,$auxiliar2[1]);
			
			
           
             
            //fin funcion

//FIN FUNCION

//CUERPOS 
$partes = explode("|", $actualizado);  
			$cuerpofuncion = $partes[0]; //CUERPO FUNCION
			$cuerpotrigger = $partes[1]; //CUERPO TRIGGER
			
			
			

//FIN CUERPOS




	   //$mutante    =   "INSERT INTO mutantes VALUES ('$actualizado');";
	   $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final2','$final', '$cuerpofuncion', '$cuerpotrigger','$oper','');";
//pg_query($conexion,$mutante);

$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}


/*
if (pg_query($conexion,$mutante) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $mutante . "<br>" . pg_last_error($conexion);
}
*/
pg_close($conexion);
	
	  
	  
	  //FIN INSERT MUTANTE
	  
	  
	  
	  

  }
  else{
      
      
      $encuentralo = 'FALSE';
      $posicion = strpos($actualizado, $encuentralo, $posicion);
            $contenidoarchivo = substr ( $copia , 0 , $posicion);

      
      
      $resto = substr ( $actualizado , $posicion );    
      $new = 'FALSE';
      $old = 'TRUE';
      $cambio1 = preg_replace('/FALSE/', $old, $resto, 1);
      
      echo '<br>';
      $actualizado = $contenidoarchivo.$cambio1; 
      
	  //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  echo $actualizado, '<br><br><br><br>';
	  echo '</span>';
	  
	  

					
					
					
					
		// Create connection

$conexion = pg_connect($_SESSION['conexion']);
// Check connection


//Trigger
			$encuentralo3 = 'CREATE TRIGGER';
            $posicion3 = strpos($actualizado, $encuentralo3);
            echo '<br>';
            

            $resto3 = substr ( $actualizado , $posicion3+14  );
            
           
            $aux3 = explode(" ", $resto3);  
            
            
            $final3 = str_replace('$', '' ,$aux3[1]);
			$final3 = $final3 . '_' . $contador;
			
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentralo4 = 'FUNCTION';
            $posicion4 = strpos($contenidoarchivo, $encuentralo4);

            $resto4 = substr ( $contenidoarchivo , $posicion4 + 8  );
            //echo $resto2;
            
            $aux4 = explode(" ", $resto4);  
            $final4 = str_replace('$', '' ,$aux4[1]);
            
			
             
            //fin funcion

//FIN FUNCION


//CUERPOS 
$partes2 = explode("|", $actualizado);  
			$cuerpofuncion2 = $partes2[0]; //CUERPO FUNCION
			$cuerpotrigger2 = $partes2[1]; //CUERPO TRIGGER
			
			
//FIN CUERPOS





	  // $mutante    =   "INSERT INTO mutantes VALUES ('$actualizado');";
	    $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final4','$final3', '$cuerpofuncion2', '$cuerpotrigger2','$oper','');";
$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}


/*
if (pg_query($conexion,$mutante) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $mutante . "<br>" . $pg_last_error;
}
*/
pg_close($conexion);
	
      
     
    }
 


}

	
	
	
	
	//FIN ALGORITMO
	
	
	
	
	
	
	
	
	
	
	
	
}







if($oper == 16)

	{
	echo "<br>";
	echo "Has marcado la opción 16.";
	echo "<br>";
	if (strpos($contenidoarchivo, 'TRUE') !== false) {
		echo "<br>";
	echo "Si es posible realizar la operación";
	}
	else{
		echo "<br>";
	echo "NO es posible realizar la operación";
	}
	echo "<br>";
	$reemplazos = substr_count($contenidoarchivo, 'TRUE');
	echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, 'TRUE'); 
	echo "<br>";echo "<br>";echo "<br>";
	//echo "<hr align='left' noshade='noshade' size='2' width='100%' />";
	echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
	echo '<br>';
	
	echo $contenidoarchivo;	
	//$original = $contenidoarchivo;	
	$original=$contenidoarchivo;	
	echo "<br><br>";
	echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
	echo '<br>';
	
	//INICIO ALGORITMO
	
	
$mutantes = substr_count($contenidoarchivo, 'TRUE');
//echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, 'TRUE'); 


for ($contador = 1; $contador <= $mutantes; $contador++){  
  if($contador === 1){
      echo '<br>';
     
      
      $encuentralo = 'FALSE';
      $posicion = strpos($contenidoarchivo, $encuentralo);
     
     

      
      $trozo = substr ( $contenidoarchivo , 0 , $posicion + 5  );
      $resto = substr ( $contenidoarchivo , $posicion + 5  );
      
      
     

  echo '<br>';
  $cambiado = str_replace("OR", "AND", $trozo);
  

  $actualizado = $cambiado .= $resto; 
	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  echo $actualizado, '<br><br><br><br>';
	  echo '</span>';
	  //INICIO INSERT MUTANTE
	  
	  // Create connection

$conexion = pg_connect($_SESSION['conexion']);
// Check connection


//Trigger
			$encuentra = 'CREATE TRIGGER';
            $pos = strpos($actualizado, $encuentra);
            echo '<br>';
            

            $restoo = substr ( $actualizado , $pos+14  );
            
           
            $auxiliar = explode(" ", $restoo);  
            
            
            $final = str_replace('$', '' ,$auxiliar[1]);
			
			$final = $final . '_' . $contador;
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentra2 = 'FUNCTION';
            $pos2 = strpos($contenidoarchivo, $encuentra2);

            $restoo2 = substr ( $contenidoarchivo , $pos2 + 8  );
            //echo $resto2;
            
            $auxiliar2 = explode(" ", $restoo2);  
            $final2 = str_replace('$', '' ,$auxiliar2[1]);
			
			
           
             
            //fin funcion

//FIN FUNCION

//CUERPOS 
$partes = explode("|", $actualizado);  
			$cuerpofuncion = $partes[0]; //CUERPO FUNCION
			$cuerpotrigger = $partes[1]; //CUERPO TRIGGER
			
			
			

//FIN CUERPOS




	   //$mutante    =   "INSERT INTO mutantes VALUES ('$actualizado');";
	   $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final2','$final', '$cuerpofuncion', '$cuerpotrigger','$oper','');";
//pg_query($conexion,$mutante);

$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}


/*
if (pg_query($conexion,$mutante) === FALSE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $mutante . "<br>" . pg_last_error($conexion);
}
*/
pg_close($conexion);
	
	  
	  
	  //FIN INSERT MUTANTE
	  
	  
	  
	  

  }
  else{
      
      
      $encuentralo = 'TRUE';
      $posicion = strpos($actualizado, $encuentralo, $posicion);
            $contenidoarchivo = substr ( $copia , 0 , $posicion);

      
      
      $resto = substr ( $actualizado , $posicion );    
      $new = 'TRUE';
      $old = 'FALSE';
      $cambio1 = preg_replace('/TRUE/', $old, $resto, 1);
      
      echo '<br>';
      $actualizado = $contenidoarchivo.$cambio1; 
      
	  //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  echo $actualizado, '<br><br><br><br>';
	  echo '</span>';
	  
	  

					
					
					
					
		// Create connection

$conexion = pg_connect($_SESSION['conexion']);
// Check connection


//Trigger
			$encuentralo3 = 'CREATE TRIGGER';
            $posicion3 = strpos($actualizado, $encuentralo3);
            echo '<br>';
            

            $resto3 = substr ( $actualizado , $posicion3+14  );
            
           
            $aux3 = explode(" ", $resto3);  
            
            
            $final3 = str_replace('$', '' ,$aux3[1]);
			$final3 = $final3 . '_' . $contador;
			
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentralo4 = 'FUNCTION';
            $posicion4 = strpos($contenidoarchivo, $encuentralo4);

            $resto4 = substr ( $contenidoarchivo , $posicion4 + 8  );
            //echo $resto2;
            
            $aux4 = explode(" ", $resto4);  
            $final4 = str_replace('$', '' ,$aux4[1]);
            
			
             
            //fin funcion

//FIN FUNCION


//CUERPOS 
$partes2 = explode("|", $actualizado);  
			$cuerpofuncion2 = $partes2[0]; //CUERPO FUNCION
			$cuerpotrigger2 = $partes2[1]; //CUERPO TRIGGER
			
			
//FIN CUERPOS





	  // $mutante    =   "INSERT INTO mutantes VALUES ('$actualizado');";
	    $mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final4','$final3', '$cuerpofuncion2', '$cuerpotrigger2','$oper','');";
$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}


/*
if (pg_query($conexion,$mutante) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $mutante . "<br>" . $pg_last_error;
}
*/
pg_close($conexion);
	
      
     
    }
 


}

	
	
	
	
	//FIN ALGORITMO
	
	
	
	
	
	
	
	
	
	
	
	
	}
	}





                } //FIN DEL FOREACH
//fclose($archivo);

echo '</div>';
?>

<input class="MyButton" type="button" value="Casos de prueba" onclick="window.location.href='casosPrueba.php'" style="margin-left: 30px;";/>

  <div id="left">
       <div class="text">
		
			
	</div>
     </div>
	<div style="clear: both"></div>

</div>

<!-- content ends -->
<div id="mainbot"><img src="images/spaser.gif" alt="" /></div>
</div>
<!-- footer begins -->


</div>
</body>
</html>
