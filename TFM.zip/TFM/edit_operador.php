<?php
session_start();
								
								$conexion = pg_connect($_SESSION['conexion']);
								
								//Recuperamos el id modificado al hacer click 
								$idoper =$_POST['idoper'];
    
								$nombre=$_POST['nombre'];
								$descripcion=$_POST['descripcion'];
								$codigo = $_POST['codigo'];
								
								
								$sql = "update operadores set nombre='$nombre', descripcion='$descripcion', codigo='$codigo' where idoper='$idoper'" ;
								pg_query ($conexion, $sql);

								//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
								pg_free_result($res);
								 
								//Cerramos la conexión
								pg_close($conexion);
								
								header('Location: lista_operadores.php');
?>