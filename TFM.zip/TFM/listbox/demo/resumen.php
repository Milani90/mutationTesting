<?php
session_start(); //Iniciamos o Continuamos la sesion
if (isset($_SESSION['login'])) //Si llego un Nickname via el formulario lo grabamos en la Sesion
{
 
}
else{
	 header('location: login.php');
}
//set_time_limit(300);//5 minutos de tiempo de respuesta
set_time_limit(400);


 //Activamos todas las notificaciones de error posibles
  error_reporting (E_ALL);

  //Definimos el tratamiento de errores no controlados
  set_error_handler(function () 
  {
    throw new Exception("Error");
  });
  
    function LogDeErrores($numeroDeError, $descripcion, $fichero, $linea, $contexto){
	
   error_log("Error: [".$numeroDeError."] ".$descripcion." ".$fichero." ".$linea." ".json_encode($contexto)." \n\r", 3, "log_errores.txt");
   $error = explode ("ERROR:", $descripcion);
  
   $_SESSION['descripcionErrorTrigger'] = isset($error[1]) ? $error[1] : null ;	
  // throw new Exception("Error");
  }
  set_error_handler("LogDeErrores");
  $numeroMutantes = $_SESSION['numeroMutantes'] ;
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Manage Triggers</title>
  <!-- Bootstrap core CSS -->
  <link href="./../../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  

  <!-- Custom fonts for this template -->
  <link href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:500,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,800,800i" rel="stylesheet">
  <link href="./../../vendor/fontawesome-free/css/all.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="./../../css/resume.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="estilo.css"/>
  <!-- PROPIOS DE LOS LISTADOS -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
	<!--cambio pestañas-->
	<script type="text/javascript" src="jquery-1.7.2.min.js"></script>

<!--nnuevos -->
<!--
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/jquery.tablesorter.js"></script>
	
	<script type="text/javascript" src="bootbox.min.js"></script>
	-->

	
<style type="text/css">
    body {
        color: #566787;
		background: #f5f5f5;
		font-family: 'Varela Round', sans-serif;
		font-size: 13px;
	}
	.table-wrapper {
        background: #fff;
        padding: 20px 25px;
        margin: 30px 0;
		border-radius: 3px;
        box-shadow: 0 1px 1px rgba(0,0,0,.05);
    }
	.table-title {        
		padding-bottom: 15px;
		background: #435d7d;
		color: #fff;
		padding: 16px 30px;
		margin: -20px -25px 10px;
		border-radius: 3px 3px 0 0;
    }
    .table-title h2 {
		margin: 5px 0 0;
		font-size: 24px;
	}
	.table-title .btn-group {
		float: right;
	}
	.table-title .btn {
		color: #fff;
		float: right;
		font-size: 13px;
		border: none;
		min-width: 50px;
		border-radius: 2px;
		border: none;
		outline: none !important;
		margin-left: 10px;
	}
	.table-title .btn i {
		float: left;
		font-size: 21px;
		margin-right: 5px;
	}
	.table-title .btn span {
		float: left;
		margin-top: 2px;
	}
    table.table tr th, table.table tr td {
        border-color: #e9e9e9;
		padding: 12px 15px;
		vertical-align: middle;
    }
	table.table tr th:first-child {
		width: 60px;
	}
	table.table tr th:last-child {
		width: 100px;
	}
    table.table-striped tbody tr:nth-of-type(odd) {
    	background-color: #fcfcfc;
	}
	table.table-striped.table-hover tbody tr:hover {
		background: #f5f5f5;
	}
    table.table th i {
        font-size: 13px;
        margin: 0 5px;
        cursor: pointer;
    }	
    table.table td:last-child i {
		opacity: 0.9;
		font-size: 22px;
        margin: 0 5px;
    }
	table.table td a {
		font-weight: bold;
		color: #566787;
		display: inline-block;
		text-decoration: none;
		outline: none !important;
	}
	table.table td a:hover {
		color: #2196F3;
	}
	table.table td a.edit {
        color: #FFC107;
    }
    table.table td a.delete {
        color: #F44336;
    }
    table.table td i {
        font-size: 19px;
    }
	table.table .avatar {
		border-radius: 50%;
		vertical-align: middle;
		margin-right: 10px;
	}
    .pagination {
        float: right;
        margin: 0 0 5px;
    }
    .pagination li a {
        border: none;
        font-size: 13px;
        min-width: 30px;
        min-height: 30px;
        color: #999;
        margin: 0 2px;
        line-height: 30px;
        border-radius: 2px !important;
        text-align: center;
        padding: 0 6px;
    }
    .pagination li a:hover {
        color: #666;
    }	
    .pagination li.active a, .pagination li.active a.page-link {
        background: #03A9F4;
    }
    .pagination li.active a:hover {        
        background: #0397d6;
    }
	.pagination li.disabled i {
        color: #ccc;
    }
    .pagination li i {
        font-size: 16px;
        padding-top: 6px
    }
    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }    
	/* Custom checkbox */
	.custom-checkbox {
		position: relative;
	}
	.custom-checkbox input[type="checkbox"] {    
		opacity: 0;
		position: absolute;
		margin: 5px 0 0 3px;
		z-index: 9;
	}
	.custom-checkbox label:before{
		width: 18px;
		height: 18px;
	}
	.custom-checkbox label:before {
		content: '';
		margin-right: 10px;
		display: inline-block;
		vertical-align: text-top;
		background: white;
		border: 1px solid #bbb;
		border-radius: 2px;
		box-sizing: border-box;
		z-index: 2;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		content: '';
		position: absolute;
		left: 6px;
		top: 3px;
		width: 6px;
		height: 11px;
		border: solid #000;
		border-width: 0 3px 3px 0;
		transform: inherit;
		z-index: 3;
		transform: rotateZ(45deg);
	}
	.custom-checkbox input[type="checkbox"]:checked + label:before {
		border-color: #03A9F4;
		background: #03A9F4;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		border-color: #fff;
	}
	.custom-checkbox input[type="checkbox"]:disabled + label:before {
		color: #b8b8b8;
		cursor: auto;
		box-shadow: none;
		background: #ddd;
	}
	/* Modal styles */
	.modal .modal-dialog {
		max-width: 900px;
		
	}
	.modal .modal-header, .modal .modal-body, .modal .modal-footer {
		padding: 20px 30px;
	}
	.modal .modal-content {
		border-radius: 3px;
		/*height: 600px;*/
	}
	.modal .modal-footer {
		background: #ecf0f1;
		border-radius: 0 0 3px 3px;
	}
    .modal .modal-title {
        display: inline-block;
    }
	.modal .form-control {
		border-radius: 2px;
		box-shadow: none;
		border-color: #dddddd;
	}
	.modal textarea.form-control {
		resize: vertical;
	}
	.modal .btn {
		border-radius: 2px;
		min-width: 100px;
	}	
	.modal form label {
		font-weight: normal;
	}	
</style>

	
  
  <!-- FIN LISTADOS -->
  <script type = "text/javascript">
	// Dadas la division que contiene todas las pestañas y la de la pestaña que se 
// quiere mostrar, la funcion oculta todas las pestañas a excepcion de esa.
function cambiarPestanna(pestannas,pestanna) {
    
    // Obtiene los elementos con los identificadores pasados.
    pestanna = document.getElementById(pestanna.id);
    listaPestannas = document.getElementById(pestannas.id);
    
    // Obtiene las divisiones que tienen el contenido de las pestañas.
    cpestanna = document.getElementById('c'+pestanna.id);
    listacPestannas = document.getElementById('contenido'+pestannas.id);
    
    i=0;
    // Recorre la lista ocultando todas las pestañas y restaurando el fondo 
    // y el padding de las pestañas.
    while (typeof listacPestannas.getElementsByTagName('div')[i] != 'undefined'){
        $(document).ready(function(){
            $(listacPestannas.getElementsByTagName('div')[i]).css('display','none');
            $(listaPestannas.getElementsByTagName('li')[i]).css('background','');
            $(listaPestannas.getElementsByTagName('li')[i]).css('padding-bottom','');
        });
        i += 1;
    }

    $(document).ready(function(){
        // Muestra el contenido de la pestaña pasada como parametro a la funcion,
        // cambia el color de la pestaña y aumenta el padding para que tape el  
        // borde superior del contenido que esta juesto debajo y se vea de este 
        // modo que esta seleccionada.
        $(cpestanna).css('display','');
        $(pestanna).css('background','dimgray');
        $(pestanna).css('padding-bottom','2px'); 
    });

}

function Abrir_ventana (pagina) {
var opciones="toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=yes, width=508, height=365, top=85, left=140";
window.open(pagina,"",opciones);
}
	
	</script>

</head>

<body id="page-top">

  <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
    <a class="navbar-brand js-scroll-trigger" href="#page-top">
      <span class="d-block d-lg-none">Clarence Taylor</span>
        
    </a>
	
	
	<span class="d-none d-lg-block">
        <img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="img/PL_PgSQL.png" alt="">
      </span>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav">	  
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="./../../triggers.php">Triggers</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="./../../suites.php">Test Suites</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="./../../lista_operadores.php">Mutation operators</a>
        </li>
		<li class="nav-item">
		<a class="nav-link js-scroll-trigger" href="./index.php">Mutation Process</a>
        </li>
		<li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="./../../perfil.php">Profile</a>
        </li>
		<li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="./../../logout.php">Logout</a>
        </li>
      </ul>
    </div>
  </nav>





    <div class="container" >
        <div class="table-wrapper" style="height: 1600px;">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-6">
						<h2>Results of  <b>Mutation Process</b></h2>
					</div>
					<div class="col-sm-6">
						

						<!--<a href="#deleteEmployeeModal" class="btn btn-danger" data-toggle="modal"><i class="material-icons">&#xE15C;</i> <span>Delete</span></a>						-->
					</div>
					
                </div>
            </div>
			
			<br>
			<br>
			
			

<!--<div style="margin-bottom: 200px;">-->


<CENTER>
<table style="width: 80%;" BORDER>
<tr>
<td style="text-align:center">NUMBER OF NOT EQUIVALENT MUTANTS</td>
<td style="text-align:center">ALIVE MUTANTS</td>
<td style="text-align:center">KILLED MUTANTS</td>
</tr>

<?php
$conexion = pg_connect($_SESSION['conexion']);

$consultaMutantes = "select count(distinct idmutation) as kill
from test_suites, execution_tests, mutations
where test_suites.idtest= execution_tests.idtest and mutations.idmutation=execution_tests.idmutacion and
 idtrigger = '".$_SESSION['triggerElegido']."' and idoperator in (".$_SESSION['sqlOperadores'].") and test_suites.idsuite = '".$_SESSION['suite']."'  
 and not equivalent and veredicto = true";


$mutantes = pg_query($conexion, $consultaMutantes);
$SelMutantes = pg_fetch_array($mutantes, null, PGSQL_ASSOC);


$percentMutantesKill=$SelMutantes['kill'];


$allMutantes =
"select count(distinct idmutation) as total
from test_suites, execution_tests, mutations
where test_suites.idtest= execution_tests.idtest and mutations.idmutation=execution_tests.idmutacion and
 idtrigger = '".$_SESSION['triggerElegido']."' and idoperator in (".$_SESSION['sqlOperadores'].") and test_suites.idsuite = '".$_SESSION['suite']."'  
 and not equivalent";


$numMutantes = pg_query($conexion, $allMutantes);
$nMutantes = pg_fetch_array($numMutantes, null, PGSQL_ASSOC);

$numeroMutantes=$nMutantes['total'];

$percentMutantesVivos = $numeroMutantes - $percentMutantesKill;


pg_close($conexion);
?>

<tr>
<td style="text-align:center">
<?php 

echo $numeroMutantes;
?>
</td><td style="text-align:center">
<?php 

if ($percentMutantesVivos == 0) 
{	echo '0 %';
}
else{
	echo round($percentMutantesVivos/$numeroMutantes,2) * '100'.' %';
}

?>
</td>
<td style="text-align:center">
<?php 

if ($percentMutantesKill == 0) 
{	echo '0 %';
}
else{
	$porcentajeMuertos = $percentMutantesKill/$numeroMutantes;
	echo round($porcentajeMuertos,2) * '100'.' %';
}
?>
</td>

</td>

</tr>

</table>

<br><br>

<CENTER>

	
	<div class="contenedor">
        
        <div id="pestanas">
            <ul id=lista>
		<?php
		
		// Miro si hay alguno vivo la pestaña 1 es para los vivos y la 2 para los matados
		
			if($percentMutantesVivos != 0){
			?>
			<li id="pestana1"><a href='javascript:cambiarPestanna(pestanas,pestana1);'>ALIVE MUTANTS</a></li>
            <li id="pestana2"><a href='javascript:cambiarPestanna(pestanas,pestana2);'>KILLED MUTANTS</a></li>
			<?php
				}
				else{
			?>
			
            <li id="pestana1"><a href='javascript:cambiarPestanna(pestanas,pestana1);'>KILLED MUTANTS</a></li>
			<li id="pestana2"><a href='javascript:cambiarPestanna(pestanas,pestana2);'>ALIVE MUTANTS</a></li>
			<?php
				}
			?>
			
                
            </ul>
        </div>

        <body onload="javascript:cambiarPestanna(pestanas,pestana1);">
        <div id="contenidopestanas">
		<?php

				if($percentMutantesVivos != 0){
			?>
		<div id="cpestana1">
		<!--<span> opcion 1 - pestaña 1</span>-->
				<form action = "actualizar_equivalent.php" method = "POST">
				<table style="width: 80%;" BORDER>
				<TR>
				<?php
				$conexion = pg_connect($_SESSION['conexion']);
				
				$consultaVivos = "select * from public.\"MutantsAliveView\" where idtrigger = ".$_SESSION['triggerElegido']." and idoperator in (".$_SESSION['sqlOperadores'].") and idsuite = ".$_SESSION['suite'].";";
				
				$vivos = pg_query($conexion, $consultaVivos);
				
				?>
				<td style="text-align:center">IDMUTANTE</td><td style="text-align:center">OPERADOR</td>
				<td style="text-align:center">CHANGE</td><td style="text-align:center">EQUIVALENT</td>
				<?php

				?>
				</TR>
				<?php 
				
				while ($res = pg_fetch_array($vivos, null, PGSQL_ASSOC)) {						 
					?>
				<tr>
					
					<TD style="text-align: center"><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"] ?>')"><?php echo $res["idmutation"];
							$_SESSION['idmutanteFinal'] = $_SESSION['idmutanteFinal'].','.$res["idmutation"];
					?></a></TD>
					<TD style="text-align: center"><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"]  ?>')">
					
					<?php 
					
					echo $res['name'];
					?>
					
					</a></TD>
					<TD><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"]  ?>')"><?php echo $res["change"]; ?></a></TD>
					<td>
					<?php
							
					if($res['equivalent']== f ){
						
					?>
					<input style="margin-left:40%" type="checkbox" name="equivalent<?php echo $res['idmutation']; ?>"" id="equivalent<?php echo $res['idmutation']; ?>" value="equivalent">
					<?php
					 }
					 else
					 {
						 
					?>
					
					<input style="margin-left:40%" type="checkbox" name="equivalent<?php echo $res['idmutation']; ?>"" id="equivalent<?php echo $res['idmutation']; ?>" value="equivalent" checked>
					<?php
					 }
					?>
					</td>
			
				</TR>
							<?php
					 }
					 ?>
				</table>
				<br> <br>
				<input type="submit" class="btn btn-primary" value="Save">
				<?php

				pg_close($conexion);
				
				?>
				</form>
				
            </div>
			
			
            <div id="cpestana2">
			<!--<span> opcion 1 - pestaña 2</span>-->
                <table style="width: 80%;" BORDER>
				<TR>
				<?php
				
				$conexion = pg_connect($_SESSION['conexion']);
				$consultaMuertos = "select * from public.\"MutantsKilledView\" where idtrigger = ".$_SESSION['triggerElegido']." and idoperator in (".$_SESSION['sqlOperadores'].") and idsuite = ".$_SESSION['suite'].";";
				
								
				$muertos = pg_query($conexion, $consultaMuertos); 
				
				if($percentMutantesKill != 0){
					
				?>
				<td style="text-align:center">IDMUTANTE</td><td style="text-align:center">OPERADOR</td><td style="text-align:center">CHANGE</td>
				<?php 
				
				}
				?>
				
				</TR>
				<?php 
									
				 while ($res = pg_fetch_array($muertos, null, PGSQL_ASSOC)) {
				
				?>
				
				<tr>
					<TD style="text-align: center"><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"] ?>')"><?php echo $res["idmutation"]  ?></a></TD>
					<TD style="text-align: center"><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"]  ?>')">
					
					<?php 
					
					echo $res['name'];
					?>
					</a></TD>
					<TD><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"]  ?>')"><?php echo $res["change"]; ?></a></TD>
					
					</TR>
					
					<?php
					 }
					 ?>
				</table>
				<?php 
				pg_close($conexion);
				?>
            </div>
			<?php
				}
			else{
			?>
			<!--<SPAN> opcion 2 </span>-->
            <div id="cpestana2">
			
                <table style="width: 80%;" BORDER>
				<TR>
				<?php
				
				$conexion = pg_connect($_SESSION['conexion']);
				$consultaVivos = "select * from public.\"MutantsAliveView\" where idtrigger = ".$_SESSION['triggerElegido']." and idoperator in (".$_SESSION['sqlOperadores'].") and idsuite = ".$_SESSION['suite'].";";
				
								
				$vivos = pg_query($conexion, $consultaVivos); 				
				
				if($percentMutantesVivos != 0){
					
				?>
				<td style="text-align:center">IDMUTANTE</td><td style="text-align:center">OPERADOR</td><td style="text-align:center">CHANGE</td><td style="text-align:center">EQUIVALENT</td>
				<?php 
				
				}
				?>
				
				</TR>
				<?php 

											
				 while ($res = pg_fetch_array($vivos, null, PGSQL_ASSOC)) {
				
				?>
				
				<tr>
					<TD style="text-align: center"><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"] ?>')"><?php echo $res["idmutation"]  ?></a></TD>
					<TD style="text-align: center"><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"]  ?>')">
					
					<?php 
					
					echo $res['name'];
					?>
					</a></TD>
					<TD><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"]  ?>')"><?php echo $res["change"]; ?></a></TD>
					<td>
					<?php
							
					if($res['equivalent']== f ){
						
					?>
					<input style="margin-left:40%" type="checkbox" name="equivalent<?php echo $res['idmutation']; ?>"" id="equivalent<?php echo $res['idmutation']; ?>" value="equivalent">
					<?php
					 }
					 else
					 {
						 
					?>
					
					<input style="margin-left:40%" type="checkbox" name="equivalent<?php echo $res['idmutation']; ?>"" id="equivalent<?php echo $res['idmutation']; ?>" value="equivalent" checked>
					<?php
					 }
					?>
					</td>
					</TR>
					<?php
					 }
					 ?>
				</table>
				
				<?php 
				
				pg_close($conexion);
				?>
				
            </div>
			<div id="cpestana1">
				<form action = "actualizar_equivalent.php" method = "POST">
				<table style="width: 80%;" BORDER>
				<TR>
				<?php
				$conexion = pg_connect($_SESSION['conexion']);
				
				$consultaMuertos = "select * from public.\"MutantsKilledView\" where idtrigger = ".$_SESSION['triggerElegido']." and idoperator in (".$_SESSION['sqlOperadores'].") and idsuite = ".$_SESSION['suite'].";";
				
				
				$muertos = pg_query($conexion, $consultaMuertos);
				
				if($percentMutantesKill != 0){
					
				?>
				<td style="text-align:center">IDMUTANTE</td><td style="text-align:center">OPERADOR</td>
				<td style="text-align:center">CHANGE</td>
				<?php
				
				}
				?>
				</TR>
				<?php 
				

			 while ($res = pg_fetch_array($muertos, null, PGSQL_ASSOC)) {
						 
					?>
				
				
				<tr>
					
					<TD style="text-align: center"><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"] ?>')"><?php echo $res["idmutation"];
							$_SESSION['idmutanteFinal'] = $_SESSION['idmutanteFinal'].','.$res["idmutation"];
					?></a></TD>
					<TD style="text-align: center"><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"]  ?>')">
					
					<?php 
					
					echo $res['name'];
					?>
					
					</a></TD>
					<TD><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"]  ?>')"><?php echo $res["change"]; ?></a></TD>
								
				</TR>
				<?php
					 }
				?>
				</table>
				<?php 
				
				if($percentMutantesVivos != 0){
				?>
				<br> <br>
				
				<input type="submit" class="btn btn-primary" value="Save">
				
				
				<?php
				}
				pg_close($conexion);
				
				?>
				
				</form>
            </div>
			
			<?php
				}
				?>
			
            
    </div>
	
</div >
	</div>
</div>


</body>
</html>                                		                            