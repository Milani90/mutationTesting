<?php
session_start(); //Iniciamos o Continuamos la sesion
if (isset($_SESSION['login'])) //Si llego un Nickname via el formulario lo grabamos en la Sesion
{
 
}
else{
	 header('location: login.php');
}


  //Activamos todas las notificaciones de error posibles
  error_reporting (E_ALL);

  //Definimos el tratamiento de errores no controlados
  set_error_handler(function () 
  {
    throw new Exception("Error");
  });
  
  function LogDeErrores($numeroDeError, $descripcion, $fichero, $linea, $contexto){
	  echo '<br>';
   error_log("Error: [".$numeroDeError."] ".$descripcion." ".$fichero." ".$linea." ".json_encode($contexto)." \n\r", 3, "log_errores.txt");
   $error = explode ("ERROR:", $descripcion);
  //$_SESSION['descripcionErrorTrigger'] = $error[1];
  $_SESSION['descripcionErrorTrigger'] = isset($error[1]) ? $error[1] : null ;	
   throw new Exception("Error");
  }
  set_error_handler("LogDeErrores");


//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");

//INICIO

	//$host = "host=127.0.0.1 ";
	$host = $_SESSION['host'];
	//$port = "port=5432 ";
	$port = $_SESSION['port'];
	$dbname = "dbname=" . $_SESSION['databaseNameTrigger'];
	//$user = " user=postgres ";
	$user = $_SESSION['user'];
	//$password = "password=root";
	$password = $_SESSION['passConf'];
	$confConexion = $host ." ". $port ." ". $dbname ." " .$user ." ". $password;
	echo $confConexion;

	$con = pg_connect($confConexion);

//FIN







	

	$usuario= $_SESSION['login'];
	
$triggerHeader = $_POST['triggerHeader']; 
$_SESSION["triggerHeader"] = $triggerHeader;

$triggerHeaderEsc = pg_escape_string($triggerHeader);




$triggerFunction = $_POST['triggerFunction']; 
$_SESSION["triggerFunction"] = $triggerFunction; //VARIABLE SESION
$triggerFunctionEsc = pg_escape_string($triggerFunction);
echo 'TEXTO: ', $triggerFunctionEsc;
echo '<br>';
$funcion = explode(" ", $triggerFunctionEsc);

$restoFunction = "";
$nombreFuncion = "";
$encuentra = 'OR REPLACE FUNCTION';
$pos = strpos($triggerFunctionEsc, $encuentra);
// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
if ($pos === false) {
    $funcion[2] = isset($funcion[2]) ? $funcion[2] : null;
	$nombreFuncion = $funcion[2];
}
else
{
	$funcion[4] = isset($funcion[4]) ? $funcion[4] : null;
	$nombreFuncion = $funcion[4];
}

	
//$funcion[2] = isset($funcion[2]) ? $funcion[2] : null;
//echo 'FUNCION: ', $funcion[2];
//$nombreFuncion = $funcion[2];
echo '<br>';
echo 'NOMBRE DE LA FUNCION: ', $nombreFuncion;
if($funcion[2] == null && $funcion[4] == null){
}else{
$deleteFuncion ="DROP FUNCTION IF EXISTS $nombreFuncion CASCADE";
echo '<br>';
echo 'borrar: ', $deleteFuncion;
pg_query($con,$deleteFuncion);
}




/*
$triggerName = $_POST['triggerName']; 
$_SESSION["triggerName"] = $triggerName;
$description = $_POST['description']; 
$_SESSION["descriptionTrigger"] = $description;
*/
$triggerName = trim($_POST['triggerName']); 
  //if (isset($_POST['$triggerName']) && !empty($_POST['$triggerName'])) {
	  if($triggerName == ''){
	 
	 $_SESSION['triggerName'] = $triggerName;
	$_SESSION['triggerNameError'] = "El campo nombre contiene espacios";
    header('location: error_trigger.php');
    }
	else{
	$_SESSION['triggerNameError'] = null;	
	}
	
$_SESSION["triggerName"] = $triggerName;
$description = trim($_POST['description']); 
  //if (isset($_POST['$description']) && !empty($_POST['$description'])) {
	  if($description==''){
		$_SESSION['descriptionTrigger'] = $description;
	   $_SESSION['descriptionError'] = "El campo descripcion222 contiene espacios";
		header('location: error_trigger.php'); 
		
    }
	else{
		
		$_SESSION['descriptionError'] = null;
  }
  $_SESSION['descriptionTrigger'] = $description;





$databaseName = $_POST['databaseName'];
$_SESSION["databaseNameTrigger"] = $databaseName; 


$triggerFunctionValido = false;
echo '<br>';echo '<br>';
//echo 'FUNCION:', $triggerFunction ;
echo '<br>';echo '<br>';

$triggerFunctionEsc = str_replace('"','\'', $triggerFunctionEsc);
echo 'TRIGGERFUNCTION: <br>', $triggerFunctionEsc;
echo '<br>';
echo '<br>';
echo '<br>';


  try 
  {
//$triggerFunctionIns = pg_query($triggerFunctionEsc) or die('La consulta fallo: ' . pg_last_error());//MENSAJE ERROR
$triggerFunctionIns = pg_query($triggerFunctionEsc);

//$triggerFunctionIns = pg_query($triggerFunctionEsc) or exit('La función introducida es erronea');
 //pg_query($aux)  or exit('La función introducida es erronea');
// echo 'Consulta OK';
 
if($triggerFunctionIns){
	//$triggerFunction = $triggerFunction;
	
	$triggerFunctionValido = true;
	echo " Correct inserting function";
}
else
{
	echo " Error inserting function";
}

  
echo '<br>';
echo '<br>';
echo '<br>';

$triggerHeaderValido = false;

$triggerHeaderEsc = str_replace('"','\'',$triggerHeaderEsc);

echo '<br>';
echo '<br>';
echo '<br>';

echo 'TRIGGER HEADER   : <br>', $triggerHeaderEsc;
//$triggerHeaderIns = pg_query($triggerHeaderEsc) or die('La consulta fallo: ' . pg_last_error()); //MENSAJE DE ERROR
$triggerHeaderIns = pg_query($triggerHeaderEsc);
if($triggerHeaderIns){
	
	
	$triggerHeaderValido = true;
	echo " Correct inserting trigger";
}
else
{
	echo " Error inserting trigger";
}



if($triggerFunctionValido == true && $triggerHeaderValido == true){
	echo 'ANTES';
	
	 //pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
	$conexion =  pg_connect($_SESSION['conexion']);
//$sql = "insert into triggers(name,headertrigger,bodytrigger,login,databasename,description) values ('$triggerName', addslashes('$triggerHeader'), addslashes('$triggerFunction') ,'$usuario', '$databaseName', '{$description}')";
$sql = "insert into triggers(name,headertrigger,bodytrigger,login,databasename,description) values ('$triggerName', '$triggerHeader', '$triggerFunction' ,'$usuario', '$databaseName', '{$description}')";
//$sql = "insert into triggers(name,headertrigger,bodytrigger,login,databasename,description) values ('$triggerName', $triggerHeaderEsc, $triggerFunctionEsc ,'$usuario', '$databaseName', '$description')";

echo 'INSERT INTO TRIGGERSSSSSSSSSSSSS: ', $sql;

	echo '<br>';
	echo 'DESPUES';
	
	echo 'CONSULTA INSERT : ',  $sql;

 
//Ejecutamos la consulta
//$res = pg_query($sql) or die('La consulta fallo: ' . pg_last_error());
$res = pg_query($conexion,$sql);

//$res = pg_query($sql) or exit("No se ha podido realizar la inserción del trigger");
//$res = pg_query($sql);
  
  if($res)
  {
	echo "Trigger insertado correctamente";
	header('location: triggers.php');
  }
  else{
	echo "Error critico";
	header('location: error_trigger.php'); 
	//echo die('La consulta fallo: ' . pg_last_error());
  }
  
 
//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
pg_free_result($res);

pg_close($conexion);



//BORRAMOS EL TRIGGER INSERTADO
$triggerFunction = $_POST['triggerFunction']; 
$_SESSION["triggerFunction"] = $triggerFunction; //VARIABLE SESION
$triggerFunctionEsc = pg_escape_string($triggerFunction);
echo 'TEXTO: ', $triggerFunctionEsc;
echo '<br>';
$funcion = explode(" ", $triggerFunctionEsc);
$restoFunction = "";
$nombreFuncion = "";
$encuentra = 'OR REPLACE FUNCTION';
$pos = strpos($triggerFunctionEsc, $encuentra);
// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
if ($pos === false) {
    $funcion[2] = isset($funcion[2]) ? $funcion[2] : null;
	$nombreFuncion = $funcion[2];
}
else
{
	$funcion[4] = isset($funcion[4]) ? $funcion[4] : null;
	$nombreFuncion = $funcion[4];
}

	
//$funcion[2] = isset($funcion[2]) ? $funcion[2] : null;
//echo 'FUNCION: ', $funcion[2];
//$nombreFuncion = $funcion[2];
echo '<br>';
echo 'NOMBRE DE LA FUNCION: ', $nombreFuncion;
if($funcion[2] == null && $funcion[4] == null){
}else{

$deleteFuncion ="DROP FUNCTION IF EXISTS $nombreFuncion CASCADE";
echo '<br>';
echo 'borrar: ', $deleteFuncion;
pg_query($con,$deleteFuncion);
}
//FIN BORRADO TRIGGER INSERTADO




header('location: triggers.php');


 
} 



  }//fin del try
   catch(Exception $e) //capturamos un posible error
  {
    //mostramos el texto del error al usuario	  
    echo "Error al insertar el trigger." . PHP_EOL;
	echo "Revise el código." . PHP_EOL;
	
	
	header('location: error_trigger.php'); 
  }
  



  //Restablecemos el tratamiento de errores
  restore_error_handler();
?>