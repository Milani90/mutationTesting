<!-- Edit Modal HTML -->
	<div id="edit" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content" style="width: 1000px; ">
					<div class="modal-header">						
						<h4 class="modal-title">Edit Trigger</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					
									<div class="modal-body">
									<div class="form-group">
										<label>TRIGGER NAME</label>
										<input type="text" class="form-control" name="enombre2222"  id="enombre222">
										 
									</div>
									
									<div class="form-group">
										<label>DESCRIPTION</label>
										<input type="text" class="form-control" name="edescripcion2222" id="edescripcion2222">
										
									</div>
									<div class="form-group">
										<label>TRIGGER HEADER</label>
										<textarea class="form-control" name="ecuerpo_trigger2222" id="ecuerpo_trigger2222"></textarea>

									</div>
									<div class="form-group">
									<label>TRIGGER FUNCTION</label>
									<textarea class="form-control" name="efuncion_trigger2222" id="efuncion_trigger2222"></textarea>
									
									</div>
									<input type="hidden" class="form-control" name="eidtrigger2222" id="eidtrigger222">

															
								</div>
								<div class="modal-footer">
								<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">				
									<input type="submit" id="update" class="btn btn-info" value="Save">
								</div>	
									
			</div>
		</div>
	</div>