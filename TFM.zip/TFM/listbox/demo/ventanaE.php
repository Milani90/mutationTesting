<html>
<head>
<script language="JavaScript">
function Abrir_ventana (pagina) {
var opciones="toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=yes, width=508, height=365, top=85, left=140";
window.open(pagina,"",opciones);
}
</script>
</head>
<body>
<a href="javascript:Abrir_ventana('showMutant.php?id=12695')"><font size="1" face="Verdana">Click aquí para abrir la ventana</font></a>
<br><br>
<a href="javascript:Abrir_ventana('showMutant.php?id=12695')"><font size="1" face="Verdana">Click aquí para abrir la ventana</font></a>
<br><br><br><br>
<?php

//echo '<script type="text/javascript">';
echo "<script> <a href='javascript:Abrir_ventana('www.google.es')'>Abre ventana 22222</a></script>";
//echo '</script>';

//$var = "Hola Pepe";
//echo "<script> alert('".$var."'); </script>";
?>


</body>
</html>