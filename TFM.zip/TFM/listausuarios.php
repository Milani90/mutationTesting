<?php


//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
$conexion = pg_connect($_SESSION['conexion']);




			$usuarios = array();

//$sqlUsuarios = "select login from users";
//$usuarios= pg_query($sqlUsuarios);

			$res = pg_query("SELECT * from users");
			while ($reg = pg_fetch_array($res, null, PGSQL_ASSOC)) {
			
			$suiteSecuencia = trim($reg["login"]);
			echo $suiteSecuencia;
			echo '<br>';
			//array_push ( $usuarios , $suiteSecuencia );
			$usuarios[] = $suiteSecuencia;
			
			}
			

foreach($usuarios as $usu){			

echo 'USUARIOS: ',$usu;
echo '<br>';
//echo 'USUARIOS: ',$usuarios;
}



$resultado = in_array('cristian', $usuarios);
echo $resultado;

?>
