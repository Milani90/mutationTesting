<?php
$host = "host=127.0.0.1 ";
	$port = "port=5432 ";
	$dbname = "dbname=pruebas ";
	$user = " user=postgres ";
	$password = "password=root";
	$confConexion = $host . $port . $dbname .$user . $password;
	//$con = pg_connect($_SESSION['conexion']);
	$con = pg_connect($confConexion);

?>