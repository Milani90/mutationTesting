<?php
session_start(); //Iniciamos o Continuamos la sesion


include('conexion.php');

$nombre= $_POST['login'];
$pass= $_POST['password'];
$_SESSION['login'] =$nombre;
$_SESSION['password'] =$pass;






	   //$consulta    =   "INSERT INTO mutantes  VALUES ('$actualizado');";
//pg_query($conexion,$mutante);

echo $nombre;
echo $pass;
//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
$conexion = pg_connect($_SESSION['conexion']);


$query=("SELECT * FROM users WHERE login='$nombre' and password='$pass'");




echo $query;

  
  $result = pg_query($conexion, $query);
  echo $result;
  $rows = pg_num_rows($result);
  echo 'NUMERO DE FILAS: ', $rows;
if($rows != 1){
	header("location: login.php");
}
else{
	header("location: index.php");
}
/*
if(!$result){ 
    // echo "Usuario no existe " . $nombre . " " . $password. " o hubo un error " . 
	echo 'pruebas';
       header("location: login.php");
    // si la consulta falla es bueno evitar que el código se siga ejecutando
    exit;
} 
else{
	echo 'CORRECTO';	
	
	if ($nombre == 'admin' || $pass == 'admin')
	{
		header("location: index_admin.php");
	}
	else{
	header("location: index.php");

	}
	
}
*/




?>
