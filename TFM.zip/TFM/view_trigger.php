<?php
	session_start();
	$conexion = pg_connect($_SESSION['conexion']);
	
	

	//Recuperamos el id modificado al hacer click 

	$nombre=$_POST['vnombre'];
	
	$descripcion=$_POST['vdescripcion'];
	$cuerpo_trigger = $_POST['vcuerpo_trigger'];
	$funcion_trigger= $_POST['vfuncion_trigger'];

	$idtrigger =$_POST['vidtrigger'];




	header('Location: triggers.php');
?>