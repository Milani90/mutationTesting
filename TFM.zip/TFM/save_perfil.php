<?php
session_start();
	$conexion = pg_connect($_SESSION['conexion']);
	
	echo $_SESSION['login'];
	$compartirinfo = 'true';
	$compartirinfoNO = 'false';
	
	if (isset($_POST["info"])) {
   
   $sql = "update users set compartirinfo = '$compartirinfo' where login='".$_SESSION['login']."'; ";
	
	
	} else {
		$sql = "update users set compartirinfo = '$compartirinfoNO' where login='".$_SESSION['login']."'; ";
	}
	pg_query($conexion,$sql);
	

	header('location: perfil.php');	
	
	
?>