<!-- Edit Modal HTML -->
	<div id="edit" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
					<div class="modal-header">						
						<h4 class="modal-title">Edit Suite</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					
									<div class="modal-body">
									<div class="form-group">
										<label>TRIGGER SUITE</label>
										<input type="text" class="form-control" name="enombre" id="enombre">
										 
									</div>
									
									<div class="form-group">
										<label>DESCRIPTION</label>
										<input type="text" class="form-control" name="edescripcion" id="edescripcion">
										
									</div>
									
									<input type="hidden" class="form-control" name="eidtrigger"  id="eidtrigger">

															
								</div>
								<div class="modal-footer">
								<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">				
									<input type="submit" id="update" class="btn btn-info" value="Save">
								</div>	
									
			</div>
		</div>
	</div>