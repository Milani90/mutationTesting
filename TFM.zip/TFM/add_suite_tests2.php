<?php
session_start(); //Iniciamos o Continuamos la sesion
if (isset($_SESSION['login'])) //Si llego un Nickname via el formulario lo grabamos en la Sesion
{
 
}
else{
	 header('location: login.php');
}

/*
  //Activamos todas las notificaciones de error posibles
  error_reporting (E_ALL);

  //Definimos el tratamiento de errores no controlados
  set_error_handler(function () 
  {
    throw new Exception("Error");
  });
*/


try{
//pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
//$host = "host=127.0.0.1 ";
$host = $_SESSION['host'];
//$port = "port=5432 ";
$port = $_SESSION['port'];
//$dbname = "dbname=tfm ";
$dbname = $_SESSION['dbname'];
//$user = " user=postgres ";
$user = $_SESSION['user'];
//$password = "password=root";
$password = $_SESSION['passConf'];
$confConexion = $host ." ". $port ." ". $dbname ." ". $user ." ". $password;
echo 'CONEXION: ', $confConexion;

$con = pg_connect($confConexion);

$description = $_POST['description'];
$_SESSION['description'] = pg_escape_string($_POST['description']);

$_SESSION['databaseName'] = pg_escape_string($_POST['databaseName']); 
$databaseName = $_POST['databaseName'];
$usuario = $_SESSION['login'];


 
$tests=$_POST['testsTabla'];



foreach($tests as $test){
 echo '<br>';
 echo 'TEST: ', $test;
//$tests = $test[$i].";" ;
 //$_SESSION["test"] = $tests[$i];
 echo '<br>';
}



//INICIO
			
			$res = pg_query("SELECT nextval('suites_idsuite_seq') as id");
			$row = pg_fetch_array($res, 0);
			$suiteSecuencia = trim($row["id"]);
			
			echo 'SECUENCIA SUITE: ', $suiteSecuencia;
			echo '<br>';
			
			
//FIN




$sql = "insert into suites(idsuite, description,login,databasename) values ($suiteSecuencia,'$description','$usuario', '$databaseName')";


//Ejecutamos la consulta
$res = pg_query($sql) or die('La consulta fallo: ' . pg_last_error());
 
//echo "Suite insertada correctamente";
 
//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
pg_free_result($res);


//INICIO
			
			$secuenciaTest = pg_query("SELECT nextval('tests_idtest_seq') as id");
			$row = pg_fetch_array($secuenciaTest, 0);
			$testSecuencia = trim($row["id"]);
			
			//echo 'SECUENCIA TEST: ', $testSecuencia;
			
//FIN 



foreach($tests as $test){
 
 
 
 $sqlTestSuite = "insert into test_suites values ($suiteSecuencia, $test)";
 $testSuite = pg_query($sqlTestSuite);
 
}

	  





	pg_close($con);
	header('location: suites.php');


}



 catch(Exception $e) //capturamos un posible error
 {
	  //pg_query("ROLLBACK TO SAVEPOINT inicio;");
    //mostramos el texto del error al usuario	  
    echo "El test: ".$_SESSION["test"]. " introducido es erroneo." . PHP_EOL;
	//die('El test es erroneo, revisalo: ' . $php_errormsg);
    
	
	//header('Location: error_add_tests.php');
  }









?>