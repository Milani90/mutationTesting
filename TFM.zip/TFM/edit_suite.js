$(document).ready(function(){
	$(document).on('click', '.edit', function(){
		
		
		
		//alert('MILANI PRUEBAS');
		var id=$(this).val();	
//alert(id);		

		//var nombre= $('#nombre'+id).text();
		var idsuite= $('#idsuite'+id).text();
		var description=$('#description'+id).text();
		//var login=$('#login'+id).text();
		//var idsuite = id;
		
	
		$('#edit').modal('show');
		
		$('#editDescription').val(description);
		$('#editIdSuite').val(id);
		$('#editIdSuite2').val(id);
		$('.editIdSuite').val(id);
		//$('#area').val(id);
		
		
		//var variableJS = "contenido de la variable javascript";
		//var randomnum = 31;
									//$cm = document.getElementById('area').value;
									//alert($cm);


		
		
		//$('#tests').val(description);
		/*
		
      $.ajax({
              url: "suites.php",
              type: "POST",
              async: true,
              data: {
                id : id} ,
                    success: function(result) {
                       $('#resultado').html(result);

                    },
                    error: function(result) {

                  $('#resultado').html('Se ha producido un error.');
                    }
              });

      */
		
		//document.cookie = 'name=234';  
		/*
		$('#edit').click( function() {
			alert('Enviando!');
				$.ajax(
						{
							url: 'suites.php?id=<?php echo $id; ?>',
							success: function( data ) {
								alert( 'El servidor devolvio "' + data + '"' );
							}
						}
					)
				}
			);
		*/
		
		/*
	$.ajax({
	  method: 'post',
	  url: 'suites.php',
	  // estas son las variables que querés pasar a PHP
	  // donde el "key" es el nombre que va a recibir
	  // en el archivo php como $_POST['total']
	  data: {total: 1239.32},
	  // esta función se llama cuando termina de procesar el
	  // request y utiliza el response para obtener la data
	  // que se imprimió desde PHP
	  success: function(response) {
		console.log(response);
	  }
	});
		
		*/
		
	});
});

$(document).ready(function(){
	$(document).on('click', '.actualizar', function(){
		alert('PRUEBAS3333');
		/*
		var id=$(this).val();		
		var descripcion= $('#descripcion'+id).text();
		var funcion_trigger=$('#funcion_trigger'+id).text();
		var cuerpo_trigger=$('#cuerpo_trigger'+id).text();
		//var address=$('#address').text();
		
	
		$('#edit').modal('show');
		$('#edescripcion').val(descripcion);
		$('#efuncion_trigger').val(funcion_trigger);
		$('#ecuerpo_trigger').val(cuerpo_trigger);
		*/
	});
});

