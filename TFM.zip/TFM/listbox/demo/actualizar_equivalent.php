<?php
session_start();


	
	$conexion = pg_connect($_SESSION['conexion']);
	//$consultaMutantesVivos = 'select * from public."ExecutionView" where veredicto = true order by idmutation';
	$consultaMutantesVivos = 'select * from public."MutantsAliveView" order by idmutation';
	$vivos = pg_query($conexion, $consultaMutantesVivos );
	
	while ($reg = pg_fetch_array($vivos, null, PGSQL_ASSOC)) {
	
		
		echo '<br>';
		
		 if(isset($_POST['equivalent'.$reg['idmutation']])) {
		
			$actualizaVeredicto = "update mutations set equivalent = true where idmutation = '".$reg['idmutation']."'";
			pg_query($conexion, $actualizaVeredicto );
			
		
		}
		else{
			$actualizaVeredicto = "update mutations set equivalent = false where idmutation = '".$reg['idmutation']."'";
			pg_query($conexion, $actualizaVeredicto );
			
		}

   	
	}
	
	echo'<script type="text/javascript">	window.location.href="resumen.php";</script>';
	

?>