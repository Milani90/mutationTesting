<?php
session_start(); //Iniciamos o Continuamos la sesion


$conexion = pg_connect($_SESSION['conexion']);

if($_REQUEST['triggerid']) {

	$consultaFuncion = "select * from triggers where idtrigger = '".$_REQUEST['triggerid']."'";
	

	$res = pg_query($conexion, $consultaFuncion);							 
	//Recorremos el array asociativo con los datos
	while ($reg = pg_fetch_array($res, null, PGSQL_ASSOC)) {
		$cuerpoFuncion = $reg['bodytrigger'];
		$databasename = $reg['databasename'];
	}


	$nombreFuncion = explode(" ", $cuerpoFuncion);
	
	
	$puntoNomFunc = substr_count($nombreFuncion[2],".");
	
	
	//CONSULTA DE BORRADO
	$sql = "DELETE FROM triggers WHERE idtrigger='".$_REQUEST['triggerid']."'";
	$resultset = pg_query($conexion, $sql) or die("database error:". pg_last_error($conexion));	
	if($resultset) {
		echo "Record Deleted";
	}
	//FIN CONSULTA DE BORRADO
	
	
	
	
	
	
	
	
	if($puntoNomFunc > 0)
	{
		$soloNombreFun = explode(".", $nombreFuncion[2]);
		$nomFuncion = $soloNombreFun[1];
	}
	else{
		$nomFuncion = $nombreFuncion[2];
	}
	
	pg_close($conexion);
	
	

}
?>
