<!--<script type="text/javascript" src="delete_suite.js"></script>-->
<?php
session_start(); //Iniciamos o Continuamos la sesion


$id = intval($_GET['idSuite']);

	# conectare la base de datos
	$con = pg_connect($_SESSION['conexion']);
    if(!$con){
        die("imposible conectarse: ".pg_error($con));
    }
    if (@pg_last_error()) {
        die("Connect failed: ".pg_last_error()." : ". pg_last_error());
    }
	$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';
	if($action == 'ajax'){
		include 'paginationTestSuite.php'; //incluir el archivo de paginación
		//las variables de paginación
		$pageTest = (isset($_REQUEST['pageTest']) && !empty($_REQUEST['pageTest']))?$_REQUEST['pageTest']:1;
		$per_pageTest = 8; //la cantidad de registros que desea mostrar
		$adjacentsTest  = 4; //brecha entre páginas después de varios adyacentes
		$offsetTest = ($pageTest - 1) * $per_pageTest;
		//Cuenta el número total de filas de la tabla*/
		$count_queryTest   = pg_query($con,"SELECT count(*) AS numrows FROM tests ");
		if ($reg= pg_fetch_array($count_queryTest)){$numrows = $reg['numrows'];}
		$total_pagesTest = ceil($numrows/$per_pageTest);
		$reloadTest = 'index.php';
		//consulta principal para recuperar los datos  
		
		
		$query = pg_query($con,"SELECT * FROM tests where idtest in (select ts.idtest from test_suites ts where ts.idsuite  = '.$id.') OFFSET '$offsetTest' LIMIT '$per_pageTest';");
		
		if ($numrows>0){
			?>
		<table class="table table-bordered">
			  <thead>
				<tr>
				  <tr>
						<th>TEST</th>
						<th>DATABASENAME</th>
						
				</tr>
			</thead>
			<tbody>
			<?php
			while($reg=pg_fetch_array($query)){
				?>
				<tr>
				
	
					
					<td width="40%"><span id="description<?php echo $reg['idtest']; ?>"><?php echo $reg['test']; ?></span></td>
					
					<td width="20%"><span id="login<?php echo $reg['idtest']; ?>"><?php echo $reg['databasename']; ?></span></td>
					
					
						
				</tr>
				<?php
			}
			 
			//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
			pg_free_result($query);
			 
			//Cerramos la conexión
			//pg_close($con);
			?>
			</tbody>
		</table>
		<div class="table-pagination pull-right">
			<?php echo paginateTestSuite($reloadTest, $pageTest, $total_pagesTest, $adjacentsTest);?>
		</div>
		
			<?php
			
		} else {
			?>
			<div class="alert alert-warning alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4>Aviso!!!</h4> No hay datos para mostrar
            </div>
			<?php
		}
	}
?>
