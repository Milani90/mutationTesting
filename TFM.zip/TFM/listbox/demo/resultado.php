<?php
session_start(); //Iniciamos o Continuamos la sesion
if (isset($_SESSION['login'])) //Si llego un Nickname via el formulario lo grabamos en la Sesion
{
 
}
else{
	 header('location: login.php');
}
//set_time_limit(300);//5 minutos de tiempo de respuesta
set_time_limit(400);


 //Activamos todas las notificaciones de error posibles
  error_reporting (E_ALL);

  //Definimos el tratamiento de errores no controlados
  set_error_handler(function () 
  {
    throw new Exception("Error");
  });
  
    function LogDeErrores($numeroDeError, $descripcion, $fichero, $linea, $contexto){
	
   error_log("Error: [".$numeroDeError."] ".$descripcion." ".$fichero." ".$linea." ".json_encode($contexto)." \n\r", 3, "log_errores.txt");
   $error = explode ("ERROR:", $descripcion);
 //  echo $error;
  
   $_SESSION['descripcionErrorTrigger'] = isset($error[1]) ? $error[1] : null ;	
  // throw new Exception("Error");
  }
  set_error_handler("LogDeErrores");
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Manage Triggers</title>
  <!-- Bootstrap core CSS -->
  <link href="./../../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:500,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,800,800i" rel="stylesheet">
  <link href="./../../vendor/fontawesome-free/css/all.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="./../../css/resume.min.css" rel="stylesheet">
  <!-- PROPIOS DE LOS LISTADOS -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!--nnuevos -->
<!--
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/jquery.tablesorter.js"></script>
	
	<script type="text/javascript" src="bootbox.min.js"></script>
	-->

	
<style type="text/css">
    body {
        color: #566787;
		background: #f5f5f5;
		font-family: 'Varela Round', sans-serif;
		font-size: 13px;
	}
	.table-wrapper {
        background: #fff;
        padding: 20px 25px;
        margin: 30px 0;
		border-radius: 3px;
        box-shadow: 0 1px 1px rgba(0,0,0,.05);
    }
	.table-title {        
		padding-bottom: 15px;
		background: #435d7d;
		color: #fff;
		padding: 16px 30px;
		margin: -20px -25px 10px;
		border-radius: 3px 3px 0 0;
    }
    .table-title h2 {
		margin: 5px 0 0;
		font-size: 24px;
	}
	.table-title .btn-group {
		float: right;
	}
	.table-title .btn {
		color: #fff;
		float: right;
		font-size: 13px;
		border: none;
		min-width: 50px;
		border-radius: 2px;
		border: none;
		outline: none !important;
		margin-left: 10px;
	}
	.table-title .btn i {
		float: left;
		font-size: 21px;
		margin-right: 5px;
	}
	.table-title .btn span {
		float: left;
		margin-top: 2px;
	}
    table.table tr th, table.table tr td {
        border-color: #e9e9e9;
		padding: 12px 15px;
		vertical-align: middle;
    }
	table.table tr th:first-child {
		width: 60px;
	}
	table.table tr th:last-child {
		width: 100px;
	}
    table.table-striped tbody tr:nth-of-type(odd) {
    	background-color: #fcfcfc;
	}
	table.table-striped.table-hover tbody tr:hover {
		background: #f5f5f5;
	}
    table.table th i {
        font-size: 13px;
        margin: 0 5px;
        cursor: pointer;
    }	
    table.table td:last-child i {
		opacity: 0.9;
		font-size: 22px;
        margin: 0 5px;
    }
	table.table td a {
		font-weight: bold;
		color: #566787;
		display: inline-block;
		text-decoration: none;
		outline: none !important;
	}
	table.table td a:hover {
		color: #2196F3;
	}
	table.table td a.edit {
        color: #FFC107;
    }
    table.table td a.delete {
        color: #F44336;
    }
    table.table td i {
        font-size: 19px;
    }
	table.table .avatar {
		border-radius: 50%;
		vertical-align: middle;
		margin-right: 10px;
	}
    .pagination {
        float: right;
        margin: 0 0 5px;
    }
    .pagination li a {
        border: none;
        font-size: 13px;
        min-width: 30px;
        min-height: 30px;
        color: #999;
        margin: 0 2px;
        line-height: 30px;
        border-radius: 2px !important;
        text-align: center;
        padding: 0 6px;
    }
    .pagination li a:hover {
        color: #666;
    }	
    .pagination li.active a, .pagination li.active a.page-link {
        background: #03A9F4;
    }
    .pagination li.active a:hover {        
        background: #0397d6;
    }
	.pagination li.disabled i {
        color: #ccc;
    }
    .pagination li i {
        font-size: 16px;
        padding-top: 6px
    }
    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }    
	/* Custom checkbox */
	.custom-checkbox {
		position: relative;
	}
	.custom-checkbox input[type="checkbox"] {    
		opacity: 0;
		position: absolute;
		margin: 5px 0 0 3px;
		z-index: 9;
	}
	.custom-checkbox label:before{
		width: 18px;
		height: 18px;
	}
	.custom-checkbox label:before {
		content: '';
		margin-right: 10px;
		display: inline-block;
		vertical-align: text-top;
		background: white;
		border: 1px solid #bbb;
		border-radius: 2px;
		box-sizing: border-box;
		z-index: 2;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		content: '';
		position: absolute;
		left: 6px;
		top: 3px;
		width: 6px;
		height: 11px;
		border: solid #000;
		border-width: 0 3px 3px 0;
		transform: inherit;
		z-index: 3;
		transform: rotateZ(45deg);
	}
	.custom-checkbox input[type="checkbox"]:checked + label:before {
		border-color: #03A9F4;
		background: #03A9F4;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		border-color: #fff;
	}
	.custom-checkbox input[type="checkbox"]:disabled + label:before {
		color: #b8b8b8;
		cursor: auto;
		box-shadow: none;
		background: #ddd;
	}
	/* Modal styles */
	.modal .modal-dialog {
		max-width: 900px;
		
	}
	.modal .modal-header, .modal .modal-body, .modal .modal-footer {
		padding: 20px 30px;
	}
	.modal .modal-content {
		border-radius: 3px;
		/*height: 600px;*/
	}
	.modal .modal-footer {
		background: #ecf0f1;
		border-radius: 0 0 3px 3px;
	}
    .modal .modal-title {
        display: inline-block;
    }
	.modal .form-control {
		border-radius: 2px;
		box-shadow: none;
		border-color: #dddddd;
	}
	.modal textarea.form-control {
		resize: vertical;
	}
	.modal .btn {
		border-radius: 2px;
		min-width: 100px;
	}	
	.modal form label {
		font-weight: normal;
	}	
</style>

	
  
  <!-- FIN LISTADOS -->
  

</head>

<body id="page-top">

  <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
    <a class="navbar-brand js-scroll-trigger" href="#page-top">
      <span class="d-block d-lg-none">Mutation Testing</span>
        
    </a>
	
	
	<span class="d-none d-lg-block">
        <img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="img/PL_PgSQL.png" alt="">
      </span>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav">	  
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="./../../triggers.php">Triggers</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="./../../suites.php">Test Suites</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="./../../lista_operadores.php">Mutation operators</a>
        </li>
		<li class="nav-item">
		<a class="nav-link js-scroll-trigger" href="./index.php">Mutation Process</a>
        </li>
		<li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="./../../perfil.php">Profile</a>
        </li>
		<li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="./../../logout.php">Logout</a>
        </li>
      </ul>
    </div>
  </nav>

    <div class="container" >
        <div class="table-wrapper" style="height: 600px;">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-6">
						<h2>Results of  <b>Mutation Process</b></h2>
					</div>
					<div class="col-sm-6">
						

						<!--<a href="#deleteEmployeeModal" class="btn btn-danger" data-toggle="modal"><i class="material-icons">&#xE15C;</i> <span>Delete</span></a>						-->
					</div>
					
                </div>
            </div>
			<br>
			<br>
			
			<?php
			
			$conexion = pg_connect($_SESSION['conexion']);
			
			$ejecucionesPdtes = "select idmutation, idtest from mutations m, test_suites t where idtrigger =".$_SESSION['triggerElegido']." and idoperator in (".$_SESSION['sqlOperadores'].") and 
			                idsuite = '".$_POST['suite']."' and  not m.equivalent and not exists (select * from execution_tests where idmutacion= m.idmutation and idtest=t.idtest)";
			
			$consultaPdtes = pg_query($conexion,$ejecucionesPdtes);
			
			if (pg_num_rows($consultaPdtes) > 0){
			
			$triggerElegido =  "select * from triggers where idtrigger =".$_SESSION['triggerElegido']."";
			$consultaTrigger = pg_query($conexion,$triggerElegido);
			
			$trigger = pg_fetch_array($consultaTrigger, null, PGSQL_ASSOC);
			$triggerOriginal = $trigger['headertrigger'];
			$funcionOriginal =  $trigger['bodytrigger'];
			$_SESSION['databaseElegida'] = $trigger['databasename'];						
			
			pg_close($conexion);
			
			
			//conexion bd trigger elegido 
			
			$host = $_SESSION['host'];
			$port = $_SESSION['port'];
			$dbname = "dbname=" .$_SESSION['databaseElegida'];
			$user = $_SESSION['user'];
			$password = $_SESSION['passConf'];
			$confConexion = $host ." ". $port ." ". $dbname ." " .$user ." ". $password;

			//HACEMOS EL BACKUP ANTES DE EJECUTAR LOS TRIGGERS
			
			$conexionTablas =	pg_connect($confConexion);		
					
			$listaTablasOriginal = pg_query($conexionTablas,"select tablename as table from pg_tables  where schemaname = 'public';");
			
			while ($listaTablas = pg_fetch_array($listaTablasOriginal, null, PGSQL_ASSOC)) {
				$nombreTabla = $listaTablas['table'];
				pg_query($conexionTablas,"drop table if exists backup_".$nombreTabla.";");
			}
			pg_close($conexionTablas);
				
			$conexionBackup = pg_connect($confConexion);
			
			$tablas = pg_query($conexionBackup,"select tablename as table from pg_tables  where schemaname = 'public';");
					
			while ($listaTablas = pg_fetch_array($tablas, null, PGSQL_ASSOC)) {
				
					$nombreTabla = $listaTablas['table'];
					pg_query($conexionBackup,"create table if not exists backup_".$nombreTabla." as (select * from ".$nombreTabla.");");
					
			}
			pg_query($conexionBackup, "COMMIT");
			pg_close($conexionBackup);
			
			// Aplicamos los test

			
			$conexion = pg_connect($_SESSION['conexion']);
			
			// Buscamos los tests de la test suite elegida no ejecutados contra los mutantes objetivo y que no estén marcados como equivalentes
			
			$test = "select distinct t1.idtest, test from mutations m, test_suites t1, tests t2 where idtrigger = ".$_SESSION['triggerElegido']." and idoperator in (".$_SESSION['sqlOperadores'].") and 
			         t1.idsuite = ".$_POST['suite']." and  t1.idtest=t2.idtest and not m.equivalent and not exists (select * from execution_tests where idmutacion= m.idmutation and idtest=t1.idtest)";

			$res = pg_query($conexion,$test);
			
						
			while ($reg = pg_fetch_array($res, null, PGSQL_ASSOC)) {
				
				//CREAMOS EL TRIGGER y funciones originales Y ELIMINAMOS LAS TABLAS bdtrigger si existen
				
				$confConexionTrigger = pg_connect($confConexion);
				$borrarFuncion = "drop function if exists ".$nombreFuncion." cascade;";
				pg_query($confConexionTrigger,$borrarFuncion);
				pg_query($confConexionTrigger,$funcionOriginal);
				pg_query($confConexionTrigger,$triggerOriginal);
				
				$tablas = pg_query("select tablename as table from pg_tables  where schemaname = 'public' and tablename like 'bdtrigger_%' ;");			
				
				while ($listaTablas = pg_fetch_array($tablas, null, PGSQL_ASSOC)) {				
					$nombreTabla = $listaTablas['table'];
					
					pg_query($confConexionTrigger,"drop table if exists ".$nombreTabla.";");	
					
				}
				
				pg_close($confConexionTrigger);
			
				// Recuperamos el test 
			
				$casoTest = $reg['test'];
				$idtest = $reg['idtest'];
								
				//Ejecutamos el test contra el trigger original y guardamos en bdtrigger el resultado si no da error.
				

				$conexionTest =	pg_connect($confConexion);	
				pg_query($conexionTest, "BEGIN");		
				
				$exectest=pg_query($conexionTest, $casoTest);
				
				
								
				if ($exectest){
				
					$tablas = pg_query("select tablename as table from pg_tables  where schemaname = 'public' and tablename not like 'bdtrigger_%' and tablename not like 'backup_%';");			
					while ($listaTablas = pg_fetch_array($tablas, null, PGSQL_ASSOC)) {
						$nombreTabla = $listaTablas['table'];
						pg_query($conexionTest,"create table if not exists bdtrigger_".$nombreTabla." as (select * from ".$nombreTabla.");");
						
				
					}
					
					pg_query($conexionTest,"COMMIT;");								
					
												
					pg_close($conexionTest);
						
					//Restauración de la copia original	de la base de datos
						
					$conexionBackup = pg_connect($confConexion);
					
					$tablas = pg_query($conexionBackup,"select tablename as table from pg_tables where schemaname = 'public' and tablename not like 'backup_%' and tablename not like 'bdtrigger_%';");
				
					while ($listaTablas = pg_fetch_array($tablas, null, PGSQL_ASSOC)) {
						$nombreTabla = $listaTablas['table'];
						pg_query($conexionBackup,"truncate ".$nombreTabla." cascade;");
					}
					
					$query="select oid, relname from pg_class where relkind='r' and 
					oid not in (select distinct conrelid from pg_constraint where contype='f')
					and relname not like 'pg_%' and relname not like 'bdtrigger_%' and relname not like 'backup_%' and relname not like 'sql_%';";

					//Se crea una lista con los oid:  oid1,oid2,...,oidx 

					$Oids = '';					
					$conexionBackup = pg_connect($confConexion);
					$tablas = pg_query($conexionBackup,$query);
					while ($listaTablas = pg_fetch_array($tablas, null, PGSQL_ASSOC)) {

						if ($Oids == "") {$Oids = $listaTablas['oid'];}	
						else {$Oids = $Oids .','.$listaTablas['oid'];}

						pg_query("insert into ". $listaTablas['relname']. " (select * from backup_".$listaTablas['relname'].");");
						
					}


					$query="select oid, relname from pg_class p
					where relkind='r' and oid not in (".$Oids.") and
					not exists (select * from pg_constraint where contype ='f' and conrelid=p.oid and confrelid not in (".$Oids."))
					and relname not like 'pg_%' and relname not like 'bdtrigger_%' and relname not like 'backup_%' 
					and relname not like 'sql_%';";
					
										
					$tablas = pg_query($conexionBackup,$query);

					while (pg_num_rows($tablas) <> 0){

						while ($listaTablas = pg_fetch_array($tablas, null, PGSQL_ASSOC)) {

							if ($Oids == "") {$Oids = $listaTablas['oid'];}	
							else {$Oids = $Oids .','.$listaTablas['oid'];}

							pg_query("insert into ". $listaTablas['relname']. " (select * from backup_".$listaTablas['relname'].");");
							
						}
						
						$query="select oid, relname from pg_class p
						where relkind='r' and oid not in (".$Oids.") and
						not exists (select * from pg_constraint where contype ='f' and conrelid=p.oid and confrelid not in (".$Oids."))
						and relname not like 'pg_%' and relname not like 'bdtrigger_%' and relname not like 'backup_%' 
						and relname not like 'sql_%';";

						$tablas = pg_query($conexionBackup,$query);
					}
					
					
					
					pg_query($conexionBackup,"COMMIT;");
					pg_close($conexionBackup);
						
				
					// Ejecutar los mutantes contra el test
					// Busco los mutantes que no se han ejecutado previamente contra el test que estamos usando 
					
					$ejecucionesPdtes = "select distinct m.* from mutations m where idtrigger = ".$_SESSION['triggerElegido']." and idoperator in (".$_SESSION['sqlOperadores'].") 
					and not m.equivalent and not exists (select * from execution_tests where idmutacion= m.idmutation and idtest=".$idtest.")";
					
					$conexion = pg_connect($_SESSION['conexion']);
					$listadoMutantes = pg_query($conexion, $ejecucionesPdtes);
					
					pg_close($conexion);
					

					// Ejecutamos cada mutante. Se instala la funcion o trigger y funcion dependiendo del tipo de mutante
					
					
					while ($mutante = pg_fetch_array($listadoMutantes, null, PGSQL_ASSOC)) {
												
						$funcionMutante = $mutante['functionbody'];
						
						$triggerMutante = $mutante['triggerbody'];
						
						$nombreFuncion = $mutante['functionname'];
						$nombreTrigger = $mutante['triggername'];
						$idmutacion = $mutante['idmutation'];
						
						$tipo=$mutante['type'];
												
						$conexionMutante = pg_connect($confConexion);
						
						$borrarFuncion = "drop function if exists ".$nombreFuncion." cascade;";
						pg_query($conexionMutante,$borrarFuncion);
						pg_query($conexionMutante,$funcionMutante);
						pg_query($conexionMutante,$triggerMutante);						
						
						
						
						
								
						pg_query($conexionMutante,"COMMIT;");
						
						
						$mutanteKill = false;
						  
						// Se ejecuta el test actual creando una transacción
						
	
						pg_query($conexionMutante,"BEGIN");	
				
						$exectest=pg_query($conexionMutante, $casoTest);
						
						if (!$exectest) {
						
							pg_query($conexionMutante,"ROLLBACK;");
							$conexion = pg_connect($_SESSION['conexion']);
							pg_query($conexion,"insert into execution_tests(idmutacion, idtest, veredicto) values ('$idmutacion', '$idtest', true)");
							pg_query($conexion,"COMMIT;");
							pg_close($conexion);
							$mutanteKill=true;
						}
						
						// Si no ha habido error se chequean los estados del trigger original y del mutante tras la aplicación del test
						
						else {							
									
								
							$tablas = pg_query($conexionMutante,"select tablename as table from pg_tables where schemaname = 'public' and tablename not like 'backup_%' and tablename not like 'bdtrigger_%';");
							
						// Chequeamos los estados del trigger y del mutante para determinar si el mutante ha sido matado o sigue vivo

							while ($listaTablas = pg_fetch_array($tablas, null, PGSQL_ASSOC) and !$mutanteKill) {
							
									
									$nombreTabla = $listaTablas['table'];
								
									$numFilasEstadoTriggerOr = pg_query($conexionMutante,"select * from  bdtrigger_".$nombreTabla."");	
									$numFilasTriggerOrig = pg_num_rows($numFilasEstadoTriggerOr);
								
								
									$numFilasEstadoMutante = pg_query($conexionMutante,"select * from ".$nombreTabla."");
									$numFilasMutante = pg_num_rows($numFilasEstadoMutante);
								
																
									if($numFilasTriggerOrig == $numFilasMutante){									
										$unionFilas = "select * from bdtrigger_".$nombreTabla." UNION select * from ".$nombreTabla."";
										$union = pg_query($conexionMutante,$unionFilas);
										$numFilasUnion = pg_num_rows($union);
										
											
										if($numFilasMutante <> $numFilasUnion){
											$mutanteKill = true;
										}
										
									}
									else {
										$mutanteKill = true;
									}
																					
							}	
							
							// Se hace rollback de la base de datos del trigger para cancelar las actualizaciones provocadas por la ejecución
							// del test y posible ejecución del mutante.
							pg_query($conexionMutante,"ROLLBACK;");
							
							
							//insertamos el resultado de la ejecucion
							
							$valorMutanteKill = json_encode($mutanteKill);
								
							$conexion = pg_connect($_SESSION['conexion']);
							
							$insertResult = "insert into execution_tests(idmutacion, idtest, veredicto) values (".$idmutacion.",".$idtest.",".$valorMutanteKill.")";

							pg_query($conexion, $insertResult );
							pg_query($conexion,"COMMIT;");
							
							pg_close($conexion);	
						}
					
						pg_close($conexionMutante);
						
						
					} //loop mutantes
					
				} //cierre error trigger contra test
				

			} // cierre loop tests
			


			$conexionTablas =	pg_connect($confConexion);		
			$listaTablasOriginal = pg_query($conexionTablas,"select tablename as table from pg_tables  where schemaname = 'public' and (tablename like 'backup_%' or tablename like 'bdtrigger_%');");
			
			while ($listaTablas = pg_fetch_array($listaTablasOriginal, null, PGSQL_ASSOC)) {

				$nombreTabla = $listaTablas['table'];
				pg_query($conexionTablas,"drop table if exists ".$nombreTabla.";");
				
				
			}
			
			$borrarFuncion = "drop function if exists ".$nombreFuncion." cascade;";
			pg_query($conexionTablas,$borrarFuncion);
			pg_query($conexionTablas,"COMMIT;");
			pg_close($conexionTablas);


		}
		else {
			pg_close($conexion);
		}
		//cierre if inicial
		
	$_SESSION['suite'] = $_POST['suite']; 
	
			
	echo '<script type="text/javascript">	window.location.href="resumen.php";</script>';
?> 
            
</div>
	</div>
	
</body>
</html>                                		                            