<!DOCTYPE html>
<html lang="en">

<head>
<!-- Custom styles for this template -->
  <link href="css/create_user.css" rel="stylesheet">


<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

</head>
<body>

<div class="container" style="1px solid #435d7d;">
   <div class="row">
        <div class="col-lg-6 col-centrada">


				<form>
					<div class="modal-header">						
						<h4 class="modal-title">Create New User</h4>
						
					</div>
					<div class="modal-body">					
						<div class="form-group">
							<label>Name</label>
							<input type="text" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Email</label>
							<input type="email" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Password</label>
							<input type="email" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Repeat Password</label>
							<input type="email" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Address</label>
							<textarea class="form-control" required></textarea>
						</div>
						<div class="form-group">
							<label>Phone</label>
							<input type="text" class="form-control" required>
						</div>					
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel" onClick="location.href='login.php'">
						<input type="submit" class="btn btn-success" value="Create" onClick="location.href='index.php'">
					</div>
				</form>
				</div>
				
				</div>	</div>
				</div>
			

	</body>

</html>
