<?php
session_start();
echo '<div style="margin-left: 30px;">';
//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
$conexion = pg_connect($_SESSION['conexion']);


pg_set_client_encoding($conexion, "UNICODE");



$login = $_SESSION['login'];

$triggerid = $_POST['trigger'];  

echo 'TRIGGER: ', $triggerid;
echo '<br>';
$consulta = "select * from triggers where idtrigger = '".$triggerid."'";

$consultaTriggerId = pg_query($conexion,$consulta)  or die('La consulta fallo: ' . pg_last_error());

while ($reg = pg_fetch_array($consultaTriggerId, null, PGSQL_ASSOC)) {
	$trigger = $reg['bodytrigger'];
	
}
$copia = $trigger;

//$valor = $_POST['operador'];  
//$operadores = $_POST['duallistbox_demo2'];  
$operadores = $_POST['to'];  

foreach($operadores as $oper){
 echo 'OPERADOR: ',$oper;
if($oper == 1  )
{
	echo "<br>";
	echo "Has marcado la opción 1.";
	echo "<br>";
		if (strpos($trigger, 'NEW') !== false) {
			echo "<br>";
			echo "Si es posible realizar la operación";
		}
		else{
			echo "<br>";
			echo "NO es posible realizar la operación";
			echo "<br>";
		}
	
		echo '<br>';
		$reemplazos = substr_count($trigger, 'NEW');
		echo "Nº mutantes posibles: ", substr_count($trigger, 'NEW'); 
		
		echo '<br><br><br>';
		
		echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
		echo '<br>';
		
		echo $trigger;	
		$original=$trigger;	
		echo "<br><br>";
		echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
		echo '<br>';
		
	//INICIO ALGORITMO
	
	
$mutantes = substr_count($trigger, 'NEW');
//echo "Nº mutantes posibles: ", substr_count($contenidoarchivo, 'NEW'); 


for ($contador = 1; $contador <= $mutantes; $contador++){  
 
  if($contador === 1){
      echo '<br>';
     
      
      $encuentralo = 'NEW';
      $posicion = strpos($trigger, $encuentralo);
     
      
      $trozo = substr ( $trigger , 0 , $posicion + 3  );
      $resto = substr ( $trigger , $posicion + 3  );
      
      
  echo '<br>';
  $cambiado = str_replace("NEW", "OLD", $trozo);
  

  $actualizado = $cambiado .= $resto; 
	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  echo $actualizado, '<br><br><br><br>';
	  echo '</span>';
	  //INICIO INSERT MUTANTE
	  
	  // Create connection

//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
$conexion = pg_connect($_SESSION['conexion']);



//Trigger
			$encuentra = 'CREATE TRIGGER';
            $pos = strpos($actualizado, $encuentra);
            echo '<br>';
            

            $restoo = substr ( $actualizado , $pos+14  );
            
           
            $auxiliar = explode(" ", $restoo);  
            
            
            $final = str_replace('$', '' ,$auxiliar[1]);
			
			$final = $final . '_' . $contador;
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentra2 = 'FUNCTION';
            $pos2 = strpos($trigger, $encuentra2);

            $restoo2 = substr ( $trigger , $pos2 + 8  );
            //echo $resto2;
            
            $auxiliar2 = explode(" ", $restoo2);  
            $final2 = str_replace('$', '' ,$auxiliar2[1]);
			
			
           
             
            //fin funcion

//FIN FUNCION

//CUERPOS 
			$partes = explode("|", $actualizado);  
			$cuerpofuncion = $partes[0]; //CUERPO FUNCION
			$cuerpotrigger = $partes[1]; //CUERPO TRIGGER
			

//FIN CUERPOS



	
	 $mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$final2','$final', '$cuerpofuncion', '$cuerpotrigger','$login','$triggerid','$oper','false');";


		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}

		pg_close($conexion);
	
	  
	  
	  //FIN INSERT MUTANTE
	  

  }

else{
      
      
      $encuentralo = 'NEW';
      $posicion = strpos($actualizado, $encuentralo, $posicion);
            $trigger = substr ( $copia , 0 , $posicion);
      //$prefijo = substr ( $actualizado,0, 8);
      
      
      $resto = substr ( $actualizado , $posicion );    
      $new = 'NEW';
      $old = 'OLD';
      $cambio1 = preg_replace('/NEW/', $old, $resto, 1);
      
      echo '<br>';
      $actualizado = $trigger.$cambio1; 
      
	  //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $actualizado, '<br><br><br><br>';
	  echo $actualizado, '<br><br><br><br>';
	  echo '</span>';
	  
	  

					
					
					
					
		// Create connection

			//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
			$conexion = pg_connect($_SESSION['conexion']);
			

//Trigger
			$encuentralo3 = 'CREATE TRIGGER';
            $posicion3 = strpos($actualizado, $encuentralo3);
            echo '<br>';
            

            $resto3 = substr ( $actualizado , $posicion3+14  );
            
           
            $aux3 = explode(" ", $resto3);  
            
            
            $final3 = str_replace('$', '' ,$aux3[1]);
			$final3 = $final3 . '_' . $contador;
			
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentralo4 = 'FUNCTION';
            $posicion4 = strpos($trigger, $encuentralo4);

            $resto4 = substr ( $trigger , $posicion4 + 8  );
            //echo $resto2;
            
            $aux4 = explode(" ", $resto4);  
            $final4 = str_replace('$', '' ,$aux4[1]);
            
			
             
            //fin funcion

//FIN FUNCION


//CUERPOS 
			$partes2 = explode("|", $actualizado);  
			$cuerpofuncion2 = $partes2[0]; //CUERPO FUNCION
			$cuerpotrigger2 = $partes2[1]; //CUERPO TRIGGER
			
			
//FIN CUERPOS



		$mutante    =   "INSERT INTO mutations(triggername,functionname, triggerbody,functionbody,login,idtrigger,idoperator, equivalent) VALUES ('$final4','$final3', '$cuerpofuncion2', '$cuerpotrigger2','$login', '$triggerid','$oper','true');";
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
	

		pg_close($conexion);
	
      
     
    }//FIN DEL ELSE OPER1
	
}//FIN DEL FOR Nº MUTANTES
	//FIN ALGORITMO

}
//BREAK;

} //FIN DEL FOREACH
//fclose($archivo);

echo '</div>';
?>