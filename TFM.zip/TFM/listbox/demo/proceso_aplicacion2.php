<TABLE BORDER="1" style="width:100%">
<TR>
   <TH style="text-align:center">IDMUTANTE</TH>
   <TH style="text-align:center">FUNCTION/TRIGGER</TH>
   <TH style="text-align:center">OPERADOR</TH>
   <!--<TH style="text-align:center">MUTANT TRIGGER</TH>-->
   <TH style="text-align:center">CHANGE</TH>
</TR>
<!--
<TR>
   <TD>Dato 1</TD>
   <TD>Dato 2</TD>
   <TD>Dato 3</TD>
   <TD>Dato 4</TD>
</TR>
-->



<?php
  //set_time_limit(30);
  
  //	TRATAMIENTO DE WARNINGS
   function LogDeErrores($numeroDeError, $descripcion, $fichero, $linea, $contexto){
	 
   error_log("Error: [".$numeroDeError."] ".$descripcion." ".$fichero." ".$linea." ".json_encode($contexto)." \n\r", 3, "log_errores.txt");
   //$error = explode ("ERROR:", $descripcion);
   //$_SESSION['descripcionErrorMutanteEjecucion'] = $error[1];
  // throw new Exception("Error");
  }
  set_error_handler("LogDeErrores");
  
  //FIN TRATAMIENTO WARNINGS
  
  
  
  
//session_start();
echo '<div style="margin-left: 30px;">';
$conexion = pg_connect($_SESSION['conexion']);

pg_set_client_encoding($conexion, "UNICODE");


$_SESSION['NOOPAPLY'] == "";
$_SESSION['NOOPGEN'] == "";
$login = $_SESSION['login'];

$triggerid = $_POST['trigger'];
$_SESSION['triggerElegido'] =  $_POST['trigger'];
$contador = 1; 

//echo 'TRIGGER: ', $triggerid;
//echo '<br>';
$consulta = "select * from triggers where idtrigger = '".$triggerid."'";
//echo 'CONSULTA:', $consulta;
//echo '<br>';
$databaseElegida = "";

$consultaTriggerId = pg_query($conexion,$consulta)  or die('La consulta fallo: ' . pg_last_error());

while ($reg = pg_fetch_array($consultaTriggerId, null, PGSQL_ASSOC)) {
	$databaseElegida = $reg['databasename'];
	$function = $reg['bodytrigger'];

	$trigger = $reg['headertrigger'];
	  
    $trigger = preg_replace("[\n|\r|\n\r|\t]", " ", $trigger);
	
	$array = explode(' ',$trigger);  // convierte en array separa por espacios;
    $salida ='';
    // quita los campos vacios y pone un solo espacio
    for ($i=0; $i < count($array); $i++) { 
        if(strlen($array[$i])>0) {
            $salida.= ' ' . $array[$i];
        }
    }
  $trigger=trim($salida);
}

echo '<hr style=" border-top: 1px solid blue; width: 750px;">';

		echo $trigger; 
		echo '<br>';
		echo '<br>';
		echo $function;	
		$original=$function;	

		echo '<hr style=" border-top: 1px solid blue; width: 750px;">';


$copia = $function;


//$valor = $_POST['operador'];  
//$operadores = $_POST['duallistbox_demo2'];  
$operadores = $_POST['to'];  
$_SESSION['operadoresElegidos'] = $_POST['to'];  


//inicio nombres funciones y triggers

//nombres de triggers y funciones 
//Trigger

$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
$posicionCreateTrigger = strpos(strtolower($trigger), strtolower($encuentraCreateTrigger));

$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
			   
$aux3 = explode(" ", $restoCreateTrigger);  
				
$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
//echo 'NOMBRE TRIGGER: ', $nombreTriggerOriginal;
//echo '<BR>';

//FIN TRIGGER

//FUNCION
//CAMBIO OR REPLACE

$restoFunction = "";
$encuentra = strtolower('OR REPLACE FUNCTION');
$pos = strpos(strtolower($copia), strtolower($encuentra));

// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
if ($pos === TRUE) {				
	$encuentraFunction = STRTOLOWER('OR REPLACE FUNCTION');
	
	$posicionFunction = strpos(strtolower($copia), $encuentraFunction);
	
	$restoFunction = substr ( $copia , $posicionFunction + 19  );
} else {
	$encuentraFunction = 'FUNCTION';

	$posicionFunction = strpos($copia, $encuentraFunction);
	
	 $restoFunction = substr ( $copia , $posicionFunction + 8  );
}
//FIN CAMBIO OR REPLACE

$nFunction = explode(" ", $restoFunction);  
$nombreFuncion = str_replace('$', '' ,$nFunction[1]);

//conexion bd trigger elegido 
			
$host = $_SESSION['host'];
$port = $_SESSION['port'];
$dbname = "dbname=".$databaseElegida;
$user = $_SESSION['user'];
$password = $_SESSION['passConf'];
$confConexion = $host ." ". $port ." ". $dbname ." " .$user ." ". $password;

$conexionTablas =	pg_connect($confConexion);		
$borrarFuncion = "drop function if exists ".$nombreFuncion." cascade;";
pg_query($conexionTablas,$borrarFuncion);
pg_query($conexionTablas,"COMMIT;");
pg_close($conexionTablas);




//fin funcion
//fin nombres funciones y triggers	
	
//comprobamos si estan esos triggers antes de crearlos

///echo 'COMPROBAMOS MUTANTES ANTES DE CREARLOS: ';
///echo '<br>';

$consultaOperadores = "select * from mutations where idtrigger = '".$triggerid."';";
$listaOperadores = pg_query($consultaOperadores);
$arrayoper = array();

	
$existeOperador1 = false;
$sqlOperadores = "";	
	

/*while ($compruebaOper = pg_fetch_array($listaOperadores, null, PGSQL_ASSOC)) {
//$arrayoper = $compruebaOper['idoperator'];
array_push($arrayoper, $compruebaOper['idoperator']);

}
*/
foreach($operadores as $oper){
	
	if($sqlOperadores == "")
	{
			$sqlOperadores = $oper;
	}	
	else	
	{
			$sqlOperadores = $sqlOperadores.','.$oper;
	}
	//abrimos conexion
	$conexion = pg_connect($_SESSION['conexion']);
	
	$consulta = "select * from mutations where idtrigger = '".$triggerid."' and idoperator = '".$oper."'";
	
	$filasAfectadas = pg_query($consulta);
	$rows = pg_num_rows($filasAfectadas);
	
	
	if($rows == 0)
	{

		if($oper == 1  ) //Para cada operador 
		{
	
			
			$hayInsert = substr_count(strtolower($trigger), strtolower('INSERT'));
			$hayUpdate = substr_count(strtolower($trigger), strtolower('UPDATE'));
			$hayDelete = substr_count(strtolower($trigger), strtolower('DELETE'));
			//SI HAY UPDATE Y NO INSERT Y UPDATE NO SE APLICA
			if($hayUpdate > 0 && $hayInsert == 0 && $hayDelete == 0 )
			{


					//INICIO ALGORITMO
					
				$mutantesNEW = substr_count(strtolower($copia), strtolower('NEW.'));

				$mutanteOper1 = "";
				$mutaciones = $function;
				

				for ($cont = 1; $cont <= $mutantesNEW; $cont++){  
				  
				  
				 
					  $encuentraNew = strtolower('NEW.');
					  $posicion = strpos(strtolower($mutaciones), $encuentraNew);
					
					  $contenidoarchivo = substr ( strtolower($copia) , 0 , $posicion);
					  
					
					 
					  $resto = substr ( $mutaciones , $posicion );    
			

					  $old = strtolower('OLD.');
					  $cambio1 = preg_replace(strtolower('/NEW./'), $old, strtolower($resto), 1);
					  $mutaciones = preg_replace(strtolower('/NEW./'), $old, strtolower($mutaciones), 1);
					  

					  $mutanteOper1 = $contenidoarchivo.$cambio1; 
					

        		// Create connection

				///	$conexion = pg_connect($_SESSION['conexion']);
 		

				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change,type ) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper1','$login','$triggerid','$oper','false', 'Replace NEW BY OLD', 'FUNCTION');";
		  
		  
	   
					$result = pg_query($conexion, $mutante);
					if (!$result) {
					  echo "Ocurrió un error.\n";
					  exit;
					}
							

				//	pg_close($conexion);
					//fin conexion
				
				  //}
				  //fin else del new__
				  
				  
				}
				
				
				
			//inicio old
			$mutanteOper1 = "";
			$mutaciones = $function;

			//INICIO ALGORITMO
			$mutantesOLD = substr_count(strtolower($copia), strtolower('OLD.'));
			

			for ($cont = 1; $cont <= $mutantesOLD; $cont++){  
			 
	
		  $encuentraOld = strtolower('OLD.');
		  $posicion = strpos(strtolower($mutaciones), $encuentraOld);
		  
		  
		  $contenidoarchivo = substr ( strtolower($copia) , 0 , $posicion);
		
      
		  $resto = substr ( strtolower($mutaciones) , $posicion );    
		  $new = strtolower('NEW.');
		  $old = strtolower('OLD.');
		  $cambio1 = preg_replace(strtolower('/OLD./'), $new, strtolower($resto), 1);
		  $mutaciones = preg_replace(strtolower('/OLD./'), $new, strtolower($mutaciones), 1);
		  
			$mutanteOper1 = $contenidoarchivo.$cambio1; 
			

       		// Create connection

		///	$conexion = pg_connect($_SESSION['conexion']);

			
					

	      $mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper1','$login','$triggerid','$oper','false', 'Replace OLD BY NEW', 'FUNCTION');";
		  
	   
			$result = pg_query($conexion, $mutante);
			if (!$result) {
			  echo "Ocurrió un error.\n";
			  exit;
			}
		


		///	pg_close($conexion);
			//fin conexion
			//}
		}//fin bucle reemplazo old
				}//FIN UPDATE Y NO INSERT Y UPDATE NO SE APLICA
				
			}//fin operador1
			//INICIO OPERADOR2
			//INICIO OPERADOR 2 - ADD OPERACION
			if($oper == 2)
			{
				
				
				
				
				
				//inicio 
				
				$mutantesINSERT = substr_count(strtolower($trigger), strtolower(' INSERT '));
				$mutantesUPDATE = substr_count(strtolower($trigger), strtolower(' UPDATE '));
				$mutantesDELETE = substr_count(strtolower($trigger), strtolower(' DELETE '));
								
				$posicionON = strpos(strtolower($trigger), strtolower(" ON "));
				$cabecera = substr(strtolower($trigger), 0, $posicionON );
				$resto = substr(strtolower($trigger), $posicionON+1);
				
				if($mutantesINSERT + $mutantesUPDATE + $mutantesDELETE < 3)
				{
					
					
					if($mutantesINSERT == 0){
						$mutanteOper2 = $cabecera." or insert ".$resto;
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper2', '$function','$login','$triggerid','$oper','false', 'ADD INSERT clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
					}
					if($mutantesDELETE == 0){
						$mutanteOper2 = $cabecera." or delete ".$resto;
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper2', '$function','$login','$triggerid','$oper','false', 'ADD DELETE clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
					}
					if($mutantesUPDATE == 0)
					{
						$mutanteOper2 = $cabecera." or update ".$resto;
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper2', '$function','$login','$triggerid','$oper','false', 'ADD UPDATE clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
					}
					
				}		
					
				
			
				
				
				//fin
	
			}//FIN OPERADOR2 -ADD OPERATION
			
			//INICIO OPERADOR3
			//INICIO OPERADOR 3
			if($oper == 3)
			{
				
				
				$mutantesINSERT = substr_count(strtolower($trigger), strtolower(' INSERT '));
				$mutantesUPDATE = substr_count(strtolower($trigger), strtolower(' UPDATE '));
				$mutantesDELETE = substr_count(strtolower($trigger), strtolower(' DELETE '));
				
				$posicionON = strpos(strtolower($trigger), strtolower(' ON '));
				$posicionOR = strpos(strtolower(substr($trigger,0,$posicionON)), strtolower(" OR "));
				
				
				
				if($mutantesINSERT + $mutantesUPDATE + $mutantesDELETE > 1)
				{
					$posicionTimeAfter = strpos(strtolower($trigger), strtolower(" AFTER "));
					$posicionTimeBefore = strpos(strtolower($trigger), strtolower(" BEFORE "));
					
					
					
					if($posicionTimeAfter == false)
					{
						$mutanteOper3 = substr_replace ( $trigger ," " , $posicionTimeBefore+ 7,  $posicionOR + 3 - ($posicionTimeBefore+7));
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper3', '$function','$login','$triggerid','$oper','false', 'Delete event clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
					}
					else{
						$mutanteOper3 = substr_replace ( $trigger ," " , $posicionTimeAfter +6,  $posicionOR + 3 - ($posicionTimeAfter+6));
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper3', '$function','$login','$triggerid','$oper','false', 'Delete event clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
					}
					
					
					if($mutantesINSERT + $mutantesUPDATE + $mutantesDELETE == 2)
					{
						$posicionFinal = strpos(strtolower($trigger), strtolower(" ON "), $posicionOR + 4);
						$mutanteOper3 = substr_replace ( $trigger ," " , $posicionOR,  $posicionFinal - $posicionOR);
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper3', '$function','$login','$triggerid','$oper','false', 'Delete event clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
					}
					else{
						$posicionOR2 = strpos(substr(strtolower($trigger), 0, $posicionON), strtolower(" OR "), $posicionOR+4);
						$mutanteOper3 = substr_replace ( $trigger ," " , $posicionOR,  $posicionOR2 - $posicionOR);
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper3', '$function','$login','$triggerid','$oper','false', 'Delete event clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
						
						$posicionFinal = strpos(strtolower($trigger), strtolower(" ON "), $posicionOR2 + 4 );
						$mutanteOper3 = substr_replace ( $trigger ," " , $posicionOR2,  $posicionFinal - $posicionOR2);
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper3', '$function','$login','$triggerid','$oper','false', 'Delete event clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
					}
							
					}
					
				}
			
			
			}//INICIO OPERADOR4
			
			if($oper == 4)
			{
				
				
				
				//inicio 
				$mutantesINSERT = substr_count(strtolower($trigger), strtolower(' INSERT '));
				$mutantesUPDATE = substr_count(strtolower($trigger), strtolower(' UPDATE '));
				$mutantesDELETE = substr_count(strtolower($trigger), strtolower(' DELETE '));
				
				$posicionON = strpos(strtolower($trigger), strtolower(" ON "));
				$posicionOR = strpos(strtolower(substr($trigger,0,$posicionON)), strtolower(" OR "));
				
				
				if($mutantesINSERT + $mutantesUPDATE + $mutantesDELETE < 3)
				{
					$posicionTimeAfter = strpos(strtolower($trigger), strtolower("AFTER"));
					$posicionTimeBefore = strpos(strtolower($trigger), strtolower("BEFORE"));
					
					
					if($posicionOR == false)
					{
						
						if($posicionTimeAfter == true){
							$posicionInicio = $posicionTimeAfter+6;
							$posicionFinal = strpos(strtolower($trigger), strtolower(" ON "), $posicionInicio);
							
						}
						else{
							$posicionInicio = $posicionTimeBefore+7;
							$posicionFinal = strpos(strtolower($trigger), strtolower(" ON "), $posicionInicio);
						}
						$cadena = substr (strtolower($trigger) , $posicionInicio , $posicionFinal- $posicionInicio ) ;
						
						if(strncmp($cadena, strtolower("INSERT"), strlen("INSERT")) === 0) {
							$oper1 = "DELETE";
							$oper2 = "UPDATE";
						}
						else if(strncmp($cadena, strtolower("DELETE"), strlen("DELETE")) === 0){
							$oper1 = "INSERT";
							$oper2 = "UPDATE";
						}
						else
						{
							$oper1 = "INSERT";
							$oper2 = "DELETE";
						}
						
						
						$mutanteOper4 = substr_replace ( $trigger ,$oper1 , $posicionInicio,  $posicionFinal - $posicionInicio);
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper4', '$function','$login','$triggerid','$oper','false', 'REPLACE clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
						$mutanteOper4 = substr_replace ( $trigger ,$oper2 , $posicionInicio,  $posicionFinal - $posicionInicio);
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper4', '$function','$login','$triggerid','$oper','false', 'REPLACE clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
					}
					else{
						
						//INICIO
						$posicion = 0;
						if($posicionTimeAfter == true){
							$posicionInicio = $posicionTimeAfter+5;
							
							$posicionFinal1 = strpos(substr(strtolower($trigger),0,$posicionON), strtolower(" OR "), $posicionInicio);
							$posicionAccion1 = strpos(substr(strtolower($trigger),0,$posicionON), strtolower(" "), $posicionInicio+1);
							
						}
						else{
							$posicionInicio = $posicionTimeBefore+6;
							$posicionFinal1 = strpos(substr(strtolower($trigger),0,$posicionON), strtolower(" OR "), $posicionInicio);
							$posicionAccion1 = strpos(substr(strtolower($trigger),0,$posicionON), strtolower(" "), $posicionInicio+1);
						}
						
						$cadena1 = substr ( strtolower($trigger) , $posicionInicio+1 , $posicionFinal1 - $posicionInicio-1 ) ;
						$accion1 = substr ( strtolower($trigger) , $posicionInicio+1 , $posicionAccion1 - $posicionInicio-1 ) ;
						
						
						$posicionON = strpos(strtolower($trigger), strtolower(" ON "), $posicionFinal1);
						$posicionAccion2 = strpos(strtolower($trigger), strtolower(" "), $posicionFinal1+4);
						
						
						$cadena2 = substr ( strtolower($trigger) , $posicionFinal1+4 , $posicionON - $posicionFinal1-4 ) ;
						$accion2 = substr ( strtolower($trigger) , $posicionFinal1+4 , $posicionAccion2 - $posicionFinal1-4 ) ;
						
						$oper1 = "";
						
						
						
						if((strncmp($accion1, "insert", strlen("INSERT")) === 0)  and (strncmp($accion2, "delete", strlen("DELETE")) === 0 )) 
						{
							$oper1 = "UPDATE";
						}
						
						if ((strncmp($accion1, "delete", strlen("DELETE")) === 0)  and (strncmp($accion2, "insert", strlen("INSERT")) === 0 ))   {
							$oper1 = "UPDATE";
						}
						
						
						if((strncmp($accion1, "insert", strlen("INSERT")) === 0 ) and (strncmp($accion2, "update", strlen("UPDATE")) === 0 )) {
							$oper1 = "DELETE";
						}
						
						
						if ((strncmp($accion1, "update", strlen("UPDATE")) === 0)  and (strncmp($accion2, "insert", strlen("INSERT")) === 0 ))   {
					
							$oper1 = "DELETE";
						}
						
						
						if((strncmp($accion1, "update", strlen("UPDATE")) === 0)  and (strncmp($accion2, "delete", strlen("DELETE")) === 0 )) {
							$oper1 = "INSERT";
							
						}
						
						
						if((strncmp($accion1, "delete", strlen("delete")) === 0)  and (strncmp($accion2, "update", strlen("UPDATE")) === 0 ))  {
						
							$oper1 = "INSERT";
						}
						
						
						
						
						$mutanteOper4 = substr_replace ( $trigger ,$oper1 , $posicionInicio+1,  $posicionFinal1 - $posicionInicio-1);
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper4', '$function','$login','$triggerid','$oper','false', 'REPLACE clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
						$mutanteOper4 = substr_replace ( $trigger ,$oper1 , $posicionFinal1+4,  $posicionON - $posicionFinal1-4);
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper4', '$function','$login','$triggerid','$oper','false', 'REPLACE clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
					
						//FIN
						
						
						
					}
				}
					
			}//FIN OPERADOR4
			
			//INICIO OPERADOR8
			
			
			if($oper == 8 )
			{
				//operador +
												
			$mutantesARITMas = preg_match_all( '/\+/',strtolower($copia));
					
			$mutanteOper8 = "";
			$mutaciones = $copia;
			
			for ($cont = 1; $cont <= $mutantesARITMas; $cont++){  
		
				$encuentraARITMas = strtolower('/\+/');
			
		
				preg_match($encuentraARITMas, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];

				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+1 );    
				
		
				$cambio1 = '-'.$resto;
				$cambio2 = '*'.$resto;
				$cambio3 = '/'.$resto;
								
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper8 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace + by -', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper8 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger',  '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace + by *', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper8 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger',  '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace + by /', 'FUNCTION');";
				pg_query($conexion, $mutante);
				
			}
			//Fin operador +
			
			//operador -
												
			$mutantesARITMenos = preg_match_all( '/-/',strtolower($copia));
		
			$mutanteOper8 = "";
			$mutaciones = $copia;
			
			for ($cont = 1; $cont <= $mutantesARITMenos; $cont++){  
		
				$encuentraARITMenos = strtolower('/-/');
			
		
				preg_match($encuentraARITMenos, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];

				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+1 );    
				
		
				$cambio1 = '+'.$resto;
				$cambio2 = '*'.$resto;
				$cambio3 = '/'.$resto;
								
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper8 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace - by +', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper8 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace - by *', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper8 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace  - by /', 'FUNCTION');";
				pg_query($conexion, $mutante);
				
			}
			//Fin operador -
			
			//operador *
												
			$mutantesARITMulti = preg_match_all( '/\*/',strtolower($copia));
		
			$mutanteOper8 = "";
			$mutaciones = $copia;
			
			for ($cont = 1; $cont <= $mutantesARITMulti; $cont++){  
		
				$encuentraARITMulti = strtolower('/\*/');
			
		
				preg_match($encuentraARITMulti, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];

				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+1 );    
				
		
				$cambio1 = '+'.$resto;
				$cambio2 = '-'.$resto;
				$cambio3 = '/'.$resto;
								
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper8 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace * by +', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper8 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace * by -', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper8 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace * by /', 'FUNCTION');";
				pg_query($conexion, $mutante);
				
			}
			//Fin operador *
			
			//operador /
												
			$mutantesARITDiv = preg_match_all( '/\//',strtolower($copia));
			
			$mutanteOper15 = "";
			$mutaciones = $copia;
			
			for ($cont = 1; $cont <= $mutantesARITDiv; $cont++){  
		
				$encuentraARITDiv = strtolower('/\//');
			
		
				preg_match($encuentraARITDiv, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];

				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+1 );    
				
		
				$cambio1 = '+'.$resto;
				$cambio2 = '-'.$resto;
				$cambio3 = '*'.$resto;
								
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper8 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger','$mutanteOper8','$login','$triggerid','$oper','false', 'Replace / by +', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper8 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger','$mutanteOper8','$login','$triggerid','$oper','false', 'Replace / by -', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper8 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace / by *', 'FUNCTION');";
				pg_query($conexion, $mutante);
				
			}
			//Fin operador /
				
				


			}	//FIN OPERADOR8
			
			
		//INICIO OPERADOR9
		if($oper == 9  )
		{

			$existe = false;
			$existeOperador9 = true;

			

			//INICIO ALGORITMO
		
		
			$mutantesAND = preg_match_all( "/[\s)\n]and[\s(\n]/",strtolower($copia));
		
			$mutanteOper9 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesAND; $cont++){  
		
				$encuentraAND = strtolower("/[\s)\n]and[\s(\n]/");
		
				preg_match($encuentraAND, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion+1);
				$resto = substr ( strtolower($mutaciones) , $posicion+4 );    
				
		
				$cambio1 = 'OR '.$resto;
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion+1);
				
		
				$mutaciones = $inicioMutations.$cambio1;
				
				
				$mutanteOper9 = $contenidoarchivo.$cambio1; 
				
			

       		// Create connection
			$conexion = pg_connect($_SESSION['conexion']);
			
	
			
	      $mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper9','$login','$triggerid','$oper','false', 'Replace AND BY OR', 'FUNCTION');";
		  
		  
	   
			$result = pg_query($conexion, $mutante);
			if (!$result) {
			  echo "Ocurrió un error.\n";
			  exit;
			}
		
			pg_close($conexion);
			//fin conexion
		
	}//FIN ALGORITMO

			$mutantesOR = preg_match_all( "/[\s)\n]or[\s(\n]/",strtolower($copia));

			$mutanteOper9 = "";
			$mutaciones = $function;
			

	for ($cont = 1; $cont <= $mutantesOR; $cont++){  
		
				//INICIO
				$encuentraOR = strtolower("/[\s)\n]or[\s(\n]/");
				preg_match($encuentraOR, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion+1);
				  
				$resto = substr ( strtolower($mutaciones) , $posicion+3 );    
				
				
				$cambio1 = 'AND'.$resto;
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				
				$mutaciones = $inicioMutations.$cambio1;
				
				
				$mutanteOper9 = $contenidoarchivo.$cambio1; 
				
				//FIN
			  
				// Create connection

				$conexion = pg_connect($_SESSION['conexion']);

							
				
					$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper9','$login','$triggerid','$oper','false', 'Replace OR BY AND', 'FUNCTION');";
						 
						  
	   
				$result = pg_query($conexion, $mutante);
				if (!$result) {
				  echo "Ocurrió un error.\n";
				  exit;
				}
		
				pg_close($conexion);
				//fin conexion
		   

      

			
		}//FIN ALGORITMO


}//FIN OPERADOR 9
			
			
			//FIN OPERADOR9
			
			//INICIO OPERADOR10
			
			if($oper == 10  ){
			
				$mutantesAFTER = substr_count(strtolower($trigger), strtolower(' AFTER '));
				$mutantesBEFORE = substr_count(strtolower($trigger), strtolower(' BEFORE '));
  
				
				//INICIO ALGORITMO
	
				if ($mutantesBEFORE=== 1){
						
					$encuentraBefore = strtolower(' BEFORE ');
					$posicion = strpos(strtolower($trigger), $encuentraBefore);
		   
					$inicio = substr ( strtolower($trigger) , 0 , $posicion);
					$resto = substr ( strtolower($trigger) , $posicion + 8 );
		
					$mutanteOper10 = $inicio.' AFTER '.$resto; 
					
				}
				else{
					$encuentraAfter = strtolower(' AFTER ');
					$posicion = strpos(strtolower($trigger), $encuentraAfter);
					
					$inicio = substr ( strtolower($trigger) , 0 , $posicion);
					$resto = substr ( strtolower($trigger) , $posicion + 7 );
					$mutanteOper10 = $inicio.' BEFORE '.$resto; 
					
				}
								 
			
				//INICIO INSERT MUTANTE	  
				$conexion = pg_connect($_SESSION['conexion']);
				
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper10', '$function','$login','$triggerid','$oper','false','Replace AFTER by BEFORE', 'TRIGGER');"; 
				$result = pg_query($conexion, $mutante);
				if (!$result) {
				  echo "Ocurrió un error.\n";
				  echo pg_last_error($conexion);
				  exit;
				}
				
				pg_close($conexion);

	}//FIN OPERADOR10

		//INICIO OPERADOR11
		if($oper == 11  )
		{
	
	
			$existeOper11 = false;
			$existeOperador11 = true;
			$mutantesFOREACHROW = substr_count(strtolower($trigger), strtolower('FOR EACH ROW'));
			$mutantesFOREACHSTATEMENT = substr_count(strtolower($trigger), strtolower('FOR EACH STATEMENT'));
  
			$mutantesConjunto = $mutantesFOREACHROW + $mutantesFOREACHSTATEMENT;	

		$reemplazos = substr_count($trigger, 'FOR EACH ROW');

		
	//INICIO ALGORITMO
	
	
	$mutantes = substr_count(strtolower($trigger), strtolower('FOR EACH ROW'));

	$reemplazos = substr_count(strtolower($trigger), strtolower('FOR EACH STATEMENT'));

	//INICIO ALGORITMO
	
	$mutantes = substr_count(strtolower($trigger), strtolower('FOR EACH STATEMENT'));

	for ($contadorMutantes = 1; $contadorMutantes <= $mutantes; $contadorMutantes++){  
		if($contadorMutantes === 1){

        
		$encuentraStatement = strtolower('FOR EACH STATEMENT');
		$posicion = strpos(strtolower($trigger), $encuentraStatement);
     
		$trozo = substr ( strtolower($trigger) , 0 , $posicion + 18  );
		$resto = substr ( strtolower($trigger) , $posicion + 18  );
      
      
		$mutanteOper11 = str_replace(strtolower("FOR EACH STATEMENT"), strtolower("FOR EACH ROW"), strtolower($trigger));
  
		
		
	  //INICIO INSERT MUTANTE

      
      
      		// Create connection

			$conexion = pg_connect($_SESSION['conexion']);
			// Check connection

	
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper11', '$function','$login','$triggerid','$oper','false','Replace FOR EACH STATEMENT BY EACH ROW', 'TRIGGER');";
	   
	   $result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}

		pg_close($conexion);
		
		//FIN INSERT MUTANTE

		}
		else{
     
			$encuentraStatement = strtolower('FOR EACH STATEMENT');
			$posicion = strpos(strtolower($mutanteOper11), $encuentraStatement, $posicion);
			$trigger1 = substr ( strtolower($trigger) , 0 , $posicion);
      
			$resto = substr ( strtolower($mutanteOper11) , $posicion );    
			$row = strtolower('FOR EACH ROW');
			$statement = strtolower('FOR EACH STATEMENT');
			$cambio1 = preg_replace(strtolower('FOR EACH STATEMENT'), $row, $resto, 1);
      

			$mutanteOper11 = $trigger1.$cambio1; 
			
	  
      		// Create connection

			$conexion = pg_connect($_SESSION['conexion']);

	
			$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper11', '$function','$login','$triggerid','$oper','false','Replace FOR EACH STATEMENT BY EACH ROW','TRIGGER');";
					  
			$result = pg_query($conexion, $mutante);
			if (!$result) {
			  echo "Ocurrió un error.\n";
			  exit;
			}
			pg_close($conexion);
			//fin conexion
      
			}
		}//FIN ALGORITMO



		}//FIN OPERADOR 11
			

		//INICIO 12 
		
		//INICIO OPERADOR 12

		if($oper == 12  )
		{
	

			$conexion = pg_connect($_SESSION['conexion']);
			$existeOper12 = false;
			$existeOperador12 = true;
			$mutantesWHEN = substr_count(strtolower($trigger), strtolower('WHEN'));
 
			$original=$function;	
		
		
			//INICIO ALGORITMO
	
	
			$mutantes = substr_count(strtolower($trigger), strtolower('WHEN'));


			for ($contadorMutantes = 1; $contadorMutantes <= $mutantes; $contadorMutantes++){  
 
				if($contadorMutantes === 1){
	
     
      
					$encuentraWhen = strtolower('WHEN');
					$posicionWhen = strpos(strtolower($trigger), $encuentraWhen);
					
					$encuentraExecute = strtolower('EXECUTE');
					$posicionExecute = strpos(strtolower($trigger), $encuentraExecute);
					
				  
					$parte1= substr(strtolower($trigger),0, $posicionWhen);
					$parte2 = substr(strtolower($trigger),$posicionExecute);
				  
					$mutanteOper12 = $parte1.$parte2;

					$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper12', '$function','$login','$triggerid','$oper','false','Remove clause WHEN from the statement', 'TRIGGER');"; 	
					

						$conexion = pg_connect($_SESSION['conexion']);
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
						pg_close($conexion);
					
				  }
 
			}

			//FIN ALGORITMO
	
			}  //FIN OPERADOR12
		
			//INICIO OPERADOR13
			if($oper == 13)
			{

				$existeOper13 = false;
				$existeOperador13 = true; 
	
				$reemplazos = substr_count(strtolower($copia), strtolower('NOT AND'));
	
	
				
				
				//INICIO OPER NOT
					$mutantesNOT = preg_match_all( "/[\s(\n]not[\s(\n]/",strtolower($copia));

			$mutanteOper13 = "";
			$mutaciones = $function;
			

	for ($cont = 1; $cont <= $mutantesNOT; $cont++){  
		
				//INICIO
				$encuentraNOT = strtolower("/[\s(\n]not[\s(\n]/");
				preg_match($encuentraNOT, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion+1);
				  
				$resto = substr ( strtolower($mutaciones) , $posicion+4 );    
				
				
				$cambio1 = $resto;
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion+1);
				
				$mutaciones = $inicioMutations.'@@@'.$cambio1;
				
				
				$mutanteOper13 = $contenidoarchivo.$cambio1; 
				
		
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper13','$login','$triggerid','$oper','false', 'Remove logical operator NOT', 'FUNCTION');";
			    $conexion = pg_connect($_SESSION['conexion']);
				$result = pg_query($conexion, $mutante);
				if (!$result) {
				  echo "Ocurrió un error.\n";
				  echo "<BR>";
				  echo 
				  exit;
				}
		
				pg_close($conexion);
	
	}//FIN ALGORITMO


	}
	//FIN OPERADOR13
	if($oper == 14) 
	{
		
		//INICIOOOOOOOO
		// Create connection

					$conexion = pg_connect($_SESSION['conexion']);

		//FINNNNNNNNNNN
		//INICIO ALGORITMO
			$mutantesRELMayorIgual = preg_match_all( "/>=/",strtolower($copia));
		
			$mutanteOper14 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesRELMayorIgual; $cont++){  
		
				$encuentraRELMayorIgual = strtolower("/>=/");
		
				preg_match($encuentraRELMayorIgual, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);

				$posicion = $matches[0][1];
				
				
				
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+2 );    
				
		
				$cambio1 = '<='.$resto;
				$cambio2 = '<>'.$resto;
				$cambio3 = '='.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper14 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal,'$nombreFuncion, '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace >= by <=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal,'$nombreFuncion, '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace >= by <>', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace >= by =', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace >= by >', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace >= by <', 'FUNCTION');";
				pg_query($conexion, $mutante);
		
			}
			
			//operador2
			$mutantesRELMenorIgual = preg_match_all( "/<=/",strtolower($copia));
		
			$mutanteOper14 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesRELMenorIgual; $cont++){  
		
				$encuentraRELMenorIgual = strtolower("/<=/");
		
				preg_match($encuentraRELMenorIgual, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);

				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion +2);    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<>'.$resto;
				$cambio3 = '='.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper14 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <= by >=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <= by <>', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <= by =', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <= by >', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <= by <', 'FUNCTION');";
				pg_query($conexion, $mutante);
				
		
		
		
			}
			//Operador2
			
			//OPERADOR3
			$mutantesRELDistinto = preg_match_all( "/<>/",strtolower($copia));
		
			$mutanteOper14 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesRELDistinto; $cont++){  
		
				$encuentraRELDistinto = strtolower("/<>/");
		
				preg_match($encuentraRELDistinto, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);

				$posicion = $matches[0][1];
				
				
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+2 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '='.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper14 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <> by >=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <> by <=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <> by =', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <> by >', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion, '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <> by <', 'FUNCTION');";
				pg_query($conexion, $mutante);
				
			}
			//fin operador3
			
			//operador4
			$mutantesRELIgualIgual = preg_match_all( "/[^><]=/",strtolower($copia));
			
			
		
			$mutanteOper14 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesRELIgualIgual; $cont++){  
		
				$encuentraRELIgualIgual = strtolower("/[^><]=/");
		
				preg_match($encuentraRELIgualIgual, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);

				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion+1);
				$resto = substr ( strtolower($mutaciones) , $posicion+2);    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '<>'.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper14 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace = by >=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace = by <=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace = by <>', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace = by >', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace = by <', 'FUNCTION');";
				pg_query($conexion, $mutante);
			}
			
			//fin operador4
			
			//operador Mayor
			$mutantesRELMayor = preg_match_all( "/[^<]>[^=]/",strtolower($copia));
		
			$mutanteOper14 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesRELMayor; $cont++){  
		
				$encuentraRELMayor = strtolower("/[^<]>[^=]/");
		
				preg_match($encuentraRELMayor, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion+1);
				$resto = substr ( strtolower($mutaciones) , $posicion+2 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '<>'.$resto;
				$cambio4 = '<'.$resto;
				$cambio5 = '='.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion+1);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper14 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace > by >=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace > by <=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace > by <>', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace > by <', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace > by =', 'FUNCTION');";
				pg_query($conexion, $mutante);
			}
			//Fin operador Mayor
			
			//operador Menor
												
			$mutantesRELMenor = preg_match_all( '/<[^>=]/',strtolower($copia));
			
		
			$mutanteOper14 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesRELMenor; $cont++){  
		
				$encuentraRELMenor = strtolower('/<[^>=]/');
			
		
				preg_match($encuentraRELMenor, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];

				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+1 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '<>'.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '='.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper14 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace < by >=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace < by <=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace < by <>', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace < by >', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace < by =', 'FUNCTION');";
				pg_query($conexion, $mutante);
			}
			//Fin operador Menor
			
			//OPERADOR3
			$mutantesRELDistinto2 = preg_match_all( "/!=/",strtolower($copia));
		
			$mutanteOper14 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesRELDistinto2; $cont++){  
		
				$encuentraRELDistinto2 = strtolower("/!=/");
		
				preg_match($encuentraRELDistinto2, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				
				
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+2 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '='.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper14 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper','$nombreFuncionOper', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace != by >=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper','$nombreFuncionOper', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace != by <=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper','$nombreFuncionOper', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace != by =', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper','$nombreFuncionOper', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace != by >', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper','$nombreFuncionOper', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace != by <', 'FUNCTION');";
				pg_query($conexion, $mutante);
				
			}
			//fin operador3
			
			
			
			
	
	}
	
	$posicionWhen = strpos(strtolower($trigger), strtolower('WHEN'));
			
	if($posicionWhen == TRUE)//si no hay condicion when no se puede aplicar este operador
	{
	
	//INICIO OPER15 ARREPH
	if($oper == 15)
	{
		//operador +
												
			$mutantesARITMas = preg_match_all( '/\+/',strtolower($trigger));
					
			$mutanteOper15 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesARITMas; $cont++){  
		
				$encuentraARITMas = strtolower('/\+/');
			
		
				preg_match($encuentraARITMas, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];

				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+1 );    
				
		
				$cambio1 = '-'.$resto;
				$cambio2 = '*'.$resto;
				$cambio3 = '/'.$resto;
								
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper15 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace + by -', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper15 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace + by *', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper15 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace + by /', 'TRIGGER');";
				pg_query($conexion, $mutante);
				
			}
			//Fin operador +
			
			//operador -
												
			$mutantesARITMenos = preg_match_all( '/-/',strtolower($trigger));
		
			$mutanteOper15 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesARITMenos; $cont++){  
		
				$encuentraARITMenos = strtolower('/-/');
			
		
				preg_match($encuentraARITMenos, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];

				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+1 );    
				
		
				$cambio1 = '+'.$resto;
				$cambio2 = '*'.$resto;
				$cambio3 = '/'.$resto;
								
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper15 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace - by +', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper15 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace - by *', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper15 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace  - by /', 'TRIGGER');";
				pg_query($conexion, $mutante);
				
			}
			//Fin operador -
			
			//operador *
												
			$mutantesARITMulti = preg_match_all( '/\*/',strtolower($trigger));
		
			$mutanteOper15 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesARITMulti; $cont++){  
		
				$encuentraARITMulti = strtolower('/\*/');
			
		
				preg_match($encuentraARITMulti, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];

				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+1 );    
				
		
				$cambio1 = '+'.$resto;
				$cambio2 = '-'.$resto;
				$cambio3 = '/'.$resto;
								
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper15 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace * by +', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper15 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace * by -', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper15 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace * by /', 'TRIGGER');";
				pg_query($conexion, $mutante);
				
			}
			//Fin operador *
			
			//operador /
												
			$mutantesARITDiv = preg_match_all( '/\//',strtolower($trigger));
			
			$mutanteOper15 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesARITDiv; $cont++){  
		
				$encuentraARITDiv = strtolower('/\//');
			
		
				preg_match($encuentraARITDiv, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];

				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+1 );    
				
		
				$cambio1 = '+'.$resto;
				$cambio2 = '-'.$resto;
				$cambio3 = '*'.$resto;
								
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper15 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace / by +', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper15 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace / by -', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper15 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace / by *', 'TRIGGER');";
				pg_query($conexion, $mutante);
				
			}
			//Fin operador /
			
			
			
		
		
	}
	
	
	
	
	if($oper == 16)
	{
		
		
		//INICIO
		// Create connection

					$conexion = pg_connect($_SESSION['conexion']);

					
		//FINNNNNNNNNNN
		//INICIO ALGORITMO
			$mutantesRELMayorIgual = preg_match_all( "/>=/",strtolower($trigger));
		
			$mutanteOper16 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesRELMayorIgual; $cont++){  
		
				$encuentraRELMayorIgual = strtolower("/>=/");
		
				preg_match($encuentraRELMayorIgual, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				//$posicion = strpos(strtolower($mutaciones), $encuentraRELMayorIgual);
				$posicion = $matches[0][1];
				
				
				
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+2 );    
				
		
				$cambio1 = '<='.$resto;
				$cambio2 = '<>'.$resto;
				$cambio3 = '='.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper16 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace >= by <=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace >= by <>', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace >= by =', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace >= by >', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace >= by <', 'TRIGGER');";
				pg_query($conexion, $mutante);
		
			}
			
			//operador2
			$mutantesRELMenorIgual = preg_match_all( "/<=/",strtolower($trigger));
		
			$mutanteOper16 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesRELMenorIgual; $cont++){  
		
				$encuentraRELMenorIgual = strtolower("/<=/");
		
				preg_match($encuentraRELMenorIgual, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				//$posicion = strpos(strtolower($mutaciones), $encuentraRELMenorIgual);
				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion +2);    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<>'.$resto;
				$cambio3 = '='.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper16 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <= by >=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <= by <>', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <= by =', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <= by >', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <= by <', 'TRIGGER');";
				pg_query($conexion, $mutante);
				
		
		
		
			}
			//Operador2
			
			//OPERADOR3
			$mutantesRELDistinto = preg_match_all( "/<>/",strtolower($trigger));
		
			$mutanteOper16 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesRELDistinto; $cont++){  
		
				$encuentraRELDistinto = strtolower("/<>/");
		
				preg_match($encuentraRELDistinto, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				//$posicion = strpos(strtolower($mutaciones), $encuentraRELDistinto);
				$posicion = $matches[0][1];
				
				
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+2 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '='.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper16 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <> by >=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <> by <=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <> by =', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <> by >', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <> by <', 'TRIGGER');";
				pg_query($conexion, $mutante);
				
			}
			//fin operador3
			
			//operador4
			$mutantesRELIgualIgual = preg_match_all( "/[^><]=/",strtolower($trigger));
			
			
		
			$mutanteOper16 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesRELIgualIgual; $cont++){  
		
				$encuentraRELIgualIgual = strtolower("/[^><]=/");
		
				preg_match($encuentraRELIgualIgual, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				//$posicion = strpos(strtolower($mutaciones), $encuentraRELIgualIgual);
				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion+1);
				$resto = substr ( strtolower($mutaciones) , $posicion+1 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '<>'.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion+1);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper16 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace = by >=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace = by <=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace = by <>', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace = by >', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion','$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace = by <', 'TRIGGER');";
				pg_query($conexion, $mutante);
			}
			
			//fin operador4
			
			//operador Mayor
			$mutantesRELMayor = preg_match_all( "/[^<]>[^=]/",strtolower($trigger));
		
			$mutanteOper16 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesRELMayor; $cont++){  
		
				$encuentraRELMayor = strtolower("/[^<]>[^=]/");
		
				preg_match($encuentraRELMayor, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion+1);
				$resto = substr ( strtolower($mutaciones) , $posicion+1 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '<>'.$resto;
				$cambio4 = '<'.$resto;
				$cambio5 = '='.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion+1);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper16 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace > by >=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace > by <=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace > by <>', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace > by <', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace > by =', 'TRIGGER');";
				pg_query($conexion, $mutante);
			}
			//Fin operador Mayor
			
			//operador Menor
												
			$mutantesRELMenor = preg_match_all( '/<[^>=]/',strtolower($trigger));
			
		
			$mutanteOper16 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesRELMenor; $cont++){  
		
				$encuentraRELMenor = strtolower('/<[^>=]/');
			
		
				preg_match($encuentraRELMenor, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];

				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+1 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '<>'.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '='.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper16 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace < by >=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace < by <=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace < by <>', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace < by >', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace < by =', 'TRIGGER');";
				pg_query($conexion, $mutante);
			}
			//Fin operador Menor
			
			//OPERADOR3
			$mutantesRELDistinto2 = preg_match_all( "/!=/",strtolower($trigger));
		
			$mutanteOper16 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesRELDistinto2; $cont++){  
		
				$encuentraRELDistinto2 = strtolower("/!=/");
		
				preg_match($encuentraRELDistinto2, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				//$posicion = strpos(strtolower($mutaciones), $encuentraRELDistinto);
				$posicion = $matches[0][1];
				
				
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+2 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '='.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper16 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace != by >=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion','$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace != by <=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace != by =', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace != by >', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace != by <', 'TRIGGER');";
				pg_query($conexion, $mutante);
				
			}
			//fin operador3
			
			
			
			
	
		//FIN OPER16
	}
	if($oper == 17)
	{
		//INICIO OPER17
		

			

			
			//INICIO ALGORITMO
			$mutantesAND = preg_match_all( "/[\s)\n]and[\s(\n]/",strtolower($trigger));
		
			$mutanteOper17 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesAND; $cont++){  
		
				$encuentraAND = strtolower("/[\s)\n]and[\s(\n]/");
		
				preg_match($encuentraAND, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion+1);
				$resto = substr ( strtolower($mutaciones) , $posicion+4 );    
				
		
				$cambio1 = 'OR '.$resto;
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion+1);
				
		
				$mutaciones = $inicioMutations.$cambio1;
				
				
				$mutanteOper17 = $contenidoarchivo.$cambio1; 
				
			

       		// Create connection
			$conexion = pg_connect($_SESSION['conexion']);
			
	
			
	      $mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper17','$copia','$login','$triggerid','$oper','false', 'Replace AND BY OR', 'TRIGGER');";
		  
		  
	   
			$result = pg_query($conexion, $mutante);
			if (!$result) {
			  echo "Ocurrió un error.\n";
			  exit;
			}
		
			pg_close($conexion);
			//fin conexion
		
	}//FIN ALGORITMO

			
			$mutantesOR = preg_match_all( "/[\s)\n]or[\s(\n]/",substr (strtolower($trigger) , $posicionWhen));
			$clausulaOR = preg_match_all( "/[\s)\n]or[\s(\n]/", strtolower($trigger) );
			
			if($clausulaOR <> $mutantesOR){
				$mutaciones = substr (strtolower($trigger), 0, strpos(strtolower($trigger), strtolower(" OR ") ) );
				$mutaciones = $mutaciones.'@@@@'.substr (strtolower($trigger), strpos(strtolower($trigger), strtolower(" OR " ))+4 );
							 
			}
			else{
				$mutaciones = $trigger;
			}
																		

			$mutanteOper17 = "";
			
			

	for ($cont = 1; $cont <= $mutantesOR; $cont++){  
		
				//INICIO
				$encuentraOR = strtolower("/[\s)\n]or[\s(\n]/");
				preg_match($encuentraOR, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				
				if($posicion>$posicionWhen){
				
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion+1);
				  
				$resto = substr ( strtolower($mutaciones) , $posicion+3 );    
				
				
				$cambio1 = 'AND'.$resto;
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				
				$mutaciones = $inicioMutations.$cambio1;
				
				
				$mutanteOper17 = $contenidoarchivo.$cambio1; 
				
				//FIN
			  
				// Create connection

				$conexion = pg_connect($_SESSION['conexion']);

				
							
				
					$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper17','$copia','$login','$triggerid','$oper','false', 'Replace OR BY AND', 'TRIGGER');";
						 
						  
	   
				$result = pg_query($conexion, $mutante);
				if (!$result) {
				  echo "Ocurrió un error.\n";
				  exit;
				}
		
				pg_close($conexion);
				//fin conexion
		   

			}

			
		}//FIN ALGORITMO
		//FIN OPER17
			
	}
	if($oper == 18)
	{
		//INICIO OPER18
		
	
			
			$hayInsert = substr_count(strtolower($trigger), strtolower('INSERT'));
			$hayUpdate = substr_count(strtolower($trigger), strtolower('UPDATE'));
			$hayDelete = substr_count(strtolower($trigger), strtolower('DELETE'));
			//SI HAY UPDATE Y NO INSERT Y UPDATE NO SE APLICA
			if($hayUpdate > 0 && $hayInsert == 0 && $hayDelete == 0 )
			{

				
					//INICIO ALGORITMO
					
				$mutantesNEW = substr_count(strtolower($trigger), strtolower('NEW.'));

				$mutanteOper18 = "";
				$mutaciones = $trigger;
				

				for ($cont = 1; $cont <= $mutantesNEW; $cont++){  
				  
				  
				 
					  $encuentraNew = strtolower('NEW.');
					  $posicion = strpos(strtolower($mutaciones), $encuentraNew);
					
					  $contenidoarchivo = substr ( strtolower($trigger) , 0 , $posicion);
					  
					
					 
					  $resto = substr ( $mutaciones , $posicion );    
			

					  $old = strtolower('OLD.');
					  $cambio1 = preg_replace(strtolower('/NEW./'), $old, strtolower($resto), 1);
					  $mutaciones = preg_replace(strtolower('/NEW./'), $old, strtolower($mutaciones), 1);
					  

					  $mutanteOper18 = $contenidoarchivo.$cambio1; 
					

        		// Create connection

					$conexion = pg_connect($_SESSION['conexion']);

	

				
 		
				
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change,type ) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper18','$copia','$login','$triggerid','$oper','false', 'Replace NEW BY OLD', 'TRIGGER');";
		  
		  
	   
					$result = pg_query($conexion, $mutante);
					if (!$result) {
					  echo "Ocurrió un error.\n";
					  exit;
					}
							

					pg_close($conexion);
					//fin conexion
				
				  //}
				  //fin else del new__
				  
				  
				}
				
				
				
			//inicio old
			$mutanteOper18 = "";
			$mutaciones = $trigger;

			//INICIO ALGORITMO
			$mutantesOLD = substr_count(strtolower($trigger), strtolower('OLD.'));
			

			for ($cont = 1; $cont <= $mutantesOLD; $cont++){  
			 
	
		  $encuentraOld = strtolower('OLD.');
		  $posicion = strpos(strtolower($mutaciones), $encuentraOld);
		  
		  
		  $contenidoarchivo = substr ( strtolower($trigger) , 0 , $posicion);
		
      
		  $resto = substr ( strtolower($mutaciones) , $posicion );    
		  $new = strtolower('NEW.');
		  $old = strtolower('OLD.');
		  $cambio1 = preg_replace(strtolower('/OLD./'), $new, strtolower($resto), 1);
		  $mutaciones = preg_replace(strtolower('/OLD./'), $new, strtolower($mutaciones), 1);
		  
			$mutanteOper18 = $contenidoarchivo.$cambio1; 
			

       		// Create connection

			$conexion = pg_connect($_SESSION['conexion']);

			
					

	      $mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper18','$copia','$login','$triggerid','$oper','false', 'Replace OLD BY NEW', 'TRIGGER');";
		  
	   
			$result = pg_query($conexion, $mutante);
			if (!$result) {
			  echo "Ocurrió un error.\n";
			  exit;
			}
		


			pg_close($conexion);
			//fin conexion
			//}
		}//fin bucle reemplazo old
				}//FIN UPDATE Y NO INSERT Y UPDATE NO SE APLICA
				
		//FIN OPER18
	}
	
	if($oper == 19)
	{
		$existeOper19 = false;
				$existeOperador19 = true; 
	
				$reemplazos = substr_count(strtolower($copia), strtolower('NOT AND'));
	
	
				
				//INICIO ALGORITMO
	
				
				
				//INICIO OPER NOT
					$mutantesNOT = preg_match_all( "/[\s(\n]not[\s(\n]/",strtolower($trigger));

			$mutanteOper19 = "";
			$mutaciones = $trigger;
			

	for ($cont = 1; $cont <= $mutantesNOT; $cont++){  
		
				//INICIO
				$encuentraNOT = strtolower("/[\s(\n]not[\s(\n]/");
				preg_match($encuentraNOT, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion+1);
				  
				$resto = substr ( strtolower($mutaciones) , $posicion+4 );    
				
				
				$cambio1 = $resto;
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion+1);
				
				
				$mutaciones = $inicioMutations.'@@@'.$cambio1;
				
				
				$mutanteOper19 = $contenidoarchivo.$cambio1; 
				// Create connection

				$conexion = pg_connect($_SESSION['conexion']);
				
		
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper19','$copia','$login','$triggerid','$oper','false', 'Remove logical operator NOT', 'TRIGGER');";
				
				  
				$result = pg_query($conexion, $mutante);
				if (!$result) {
				  echo "Ocurrió un error.\n";
				  exit;
				}
		
				pg_close($conexion);
	
	}//FIN ALGORITMO

		
	}

			}//FIN DE CONDICION WHEN

			//INCLUIR AQUI RESTO DE OPERADORES
			
		}//ROWS = 0
		
}//FIN FOREACH DE OPERADORES 

		$_SESSION['sqlOperadores']=$sqlOperadores;
	

		$conexion = pg_connect($_SESSION['conexion']);
		$reg = pg_query("select * from public.mutations where idtrigger = '".$triggerid."' and idoperator in (".$sqlOperadores.") ");	
		
		$numFilasResultado = pg_num_rows($reg);	
		
		if($numFilasResultado > 0){
			
			
			//conexion bd trigger elegido 
			$host = $_SESSION['host'];
			$port = $_SESSION['port'];
			$dbname = "dbname=" . $databaseElegida ;
			$user = $_SESSION['user'];
			$password = $_SESSION['passConf'];
			$confConexion = $host ." ". $port ." ". $dbname ." " .$user ." ". $password;


			
			while ($res = pg_fetch_array($reg, null, PGSQL_ASSOC)) {
			
				$confTablas=pg_connect($confConexion);	
			
			    $funcionname = $res["functionname"];
				$triggername = $res["triggername"];
				$idTriggerSel = $res["idtrigger"];
				$operator=$res["idoperator"];
				$functionBody = $res["functionbody"];
				$idmutant=$res["idmutation"];
				$triggerBody = $res["triggerbody"];
				//instalar y desinstalar triggers, capturar el error, y se produce, coger el id mutation,y se borra de la tabla
								
					$funcionEjecucion = pg_query($confTablas,$functionBody);
					if (!$funcionEjecucion){
						pg_close($confTablas);
						$conexion = pg_connect($_SESSION['conexion']);
						pg_query($conexion,"DELETE FROM MUTATIONS where idmutation = ".$idmutant."");
						pg_close($conexion);
						
					}
					else{
						$triggerEjecucion = pg_query($confTablas,$triggerBody);
						if (!$triggerEjecucion){
							pg_close($confTablas);
							$conexion = pg_connect($_SESSION['conexion']);
							pg_query($conexion,"DELETE FROM MUTATIONS where idmutation = ".$idmutant."");
							pg_close($conexion);
						}
						$confTablas=pg_connect($confConexion);
						pg_query($confTablas,"DROP FUNCTION IF EXISTS ".$funcionname." CASCADE");
						pg_close($confTablas);
						
					}
					
			}	
			
			$conexion = pg_connect($_SESSION['conexion']);
			
			
			$reg = pg_query("select * from public.\"mutationsView\" where idtrigger = '".$triggerid."' and idoperator in (".$sqlOperadores.") order by name,change ");	
			
			$mutantesCreados = pg_num_rows($reg);	
			$_SESSION['numeroMutantes'] = $mutantesCreados;
			
			if($mutantesCreados == 0)
			{
				$_SESSION['NOOPGEN'] = "No valid mutants have been generated";
				
				echo'<script type="text/javascript"> 
					window.location.href="index_error.php";</script>';
				//no se ha generado ningun mutante
				
			}
			else{
				
				while ($res = pg_fetch_array($reg, null, PGSQL_ASSOC)) {
					?>
					<TR>
					<TD style="text-align: center"><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"] ?>')"><?php echo $res["idmutation"]  ?></a></TD>
					<TD style="text-align: center"><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"]  ?>')"><?php echo $res["type"] ?></a></TD>
					<TD style="text-align: center"><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"]  ?>')"><?php echo $res["name"] ?></a></TD>
					<TD><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"]  ?>')"><?php echo $res["change"] ?></a></TD>
					</TR>
					<?php
//					$mutantesCreados = $mutantesCreados + 1;
				}
				
			}

		}
		else{
			//No hay mutantes
		
			$_SESSION['NOOPAPLY'] = "No mutants have been generated";
					
			//echo'<script type="text/javascript"> 
			//window.location.href="index_error.php";</script>';

		}
		//}
  
			
			pg_close($conexion);
			//fin conexion
		
	
  
    

?>
</TABLE>