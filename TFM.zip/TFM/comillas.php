<?php


$test = "hola ' soy cristian' me llamo cris";
$suiteSelected = str_replace('\'','"', $test);
echo $suiteSelected;

?>