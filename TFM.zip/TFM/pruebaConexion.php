<?php

require("conexion.php");

pg_query("insert into employees(idemp,name) values (20,'domingo')");


?>