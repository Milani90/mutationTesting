 
<html>
<head>
</head>
<body>
<form id="dataForm" name="dataForm" method="post" 
enctype="multipart/form-data" action="resback.php">
    <input type="file" name="path" id="path" style="width:300px"/>
    <input type="submit" value="Import" name="actionButton" 
id="actionButton" >
    <input type="submit" value="Export" name="actionButton" 
id="actionButton" >
</form>
</body>
</html>

