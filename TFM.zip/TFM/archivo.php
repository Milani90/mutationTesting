<?php

session_start(); //Iniciamos o Continuamos la sesion
$conexion = pg_connect($_SESSION['conexion']);
$id=$_POST['id'];
$_SESSION['idListadoSuite'] = $id;


$array = array();

$sql = 'SELECT test FROM tests where idtest in (select ts.idtest from test_suites ts where ts.idsuite  = '.$id.')';
$result = pg_query($sql);

while($fila=pg_fetch_array($result,null, PGSQL_ASSOC)){ 	
	$array[] = array(
        "id" => $fila['test']
        
    );
}


$resultado=json_encode($array);

echo $resultado;

	
						
								
						
								
?>