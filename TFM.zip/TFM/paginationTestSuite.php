<?php
function paginateTestSuite($reloadTest, $pageTest, $tpagesTest, $adjacentsTest) {
	$prevlabel = "&lsaquo; Previous";
	$nextlabel = "Next &rsaquo;";
	$out = '<ul class="pagination pagination-large">';
	
	// previous label

	if($pageTest==1) {
		$out.= "<li class='disabled'><span><a>$prevlabel</a></span></li>";
	} else if($pageTest==2) {
		$out.= "<li><span><a href='javascript:void(0);' onclick='loadTest(1)'>$prevlabel</a></span></li>";
		//$out.= "<li><span><a href='javascript:location.reload();' onclick='load(1)'>$prevlabel</a></span></li>";
		
	}else {
		$out.= "<li><span><a href='javascript:void(0);' onclick='loadTest(".($pageTest-1).")'>$prevlabel</a></span></li>";
		//$out.= "<li><span><a href='javascript:location.reload();' onclick='load(".($page-1).")'>$prevlabel</a></span></li>";
		

	}
	
	// first label
	if($pageTest>($adjacentsTest+1)) {
		$out.= "<li><a href='javascript:void(0);' onclick='loadTest(1)'>1</a></li>";
		//$out.= "<li><a href='javascript:location.reload();' onclick='load(1)'>1</a></li>";
		
	}
	// interval
	if($pageTest>($adjacentsTest+2)) {
		$out.= "<li><a>...</a></li>";
	}

	// pages

	$pmin = ($pageTest>$adjacentsTest) ? ($pageTest-$adjacentsTest) : 1;
	$pmax = ($pageTest<($tpagesTest-$adjacentsTest)) ? ($pageTest+$adjacentsTest) : $tpagesTest;
	for($i=$pmin; $i<=$pmax; $i++) {
		if($i==$pageTest) {
			$out.= "<li class='active'><a>$i</a></li>";
		}else if($i==1) {
			$out.= "<li><a href='javascript:void(0);' onclick='loadTest(1)'>$i</a></li>";
			//$out.= "<li><a href='javascript:location.reload();' onclick='load(1)'>$i</a></li>";
			
		}else {
			$out.= "<li><a href='javascript:void(0);' onclick='loadTest(".$i.")'>$i</a></li>";
			//$out.= "<li><a href='javascript:location.reload();' onclick='load(".$i.")'>$i</a></li>";
			
		}
	}

	// interval

	if($pageTest<($tpagesTest-$adjacentsTest-1)) {
		$out.= "<li><a>...</a></li>";
	}

	// last

	if($pageTest<($tpagesTest-$adjacentsTest)) {
		$out.= "<li><a href='javascript:void(0);' onclick='loadTest($tpagesTest)'>$tpagesTest</a></li>";
		//$out.= "<li><a href='javascript:location.reload();' onclick='load($tpages)'>$tpages</a></li>";
		
	}

	// next

	if($pageTest<$tpagesTest) {
		$out.= "<li><span><a href='javascript:void(0);' onclick='loadTest(".($pageTest+1).")'>$nextlabel</a></span></li>";
		//$out.= "<li><span><a href='javascript:location.reload();' onclick='load(".($page+1).")'>$nextlabel</a></span></li>";
		
	}else {
		$out.= "<li class='disabled'><span><a>$nextlabel</a></span></li>";
	}
	
	$out.= "</ul>";
	return $out;
}
?>