<?php
session_start();
							
								$conexion = pg_connect($_SESSION['conexion']);
								
							
								//Recuperamos el id modificado al hacer click 
								$idtest =$_POST['idtest'];
    
						
								
																
								$sql = "delete from tests where idtest='$idtest'" ;
							
								pg_query ($conexion, $sql);

								//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
								pg_free_result($res);
								 
								//Cerramos la conexión
								pg_close($conexion);
								
								header('Location: lista_operadores.php');
					
								else{
								
								
								}
								
								?>