$(document).ready(function(){  
	$('.delete').click(function(e){   
	   e.preventDefault();   
	   var triggerid = $(this).attr('data-emp-id');
	   var nameTrigger = $(this).attr('data-nombre-id');
									
	   var parent = $(this).parent("td").parent("tr");   
	   bootbox.dialog({
			message: "Are you sure you want to delete '"+ nameTrigger + "'?",
			title: "",
			buttons: {
				success: {
					  label: "No",
					  className: "btn-success",
					  callback: function() {
					  $('.bootbox').modal('hide');
				  }
				},
				danger: {
				  label: "Delete!",
				  className: "btn-danger",
				  callback: function() {       
				   $.ajax({        
						type: 'POST',
						url:  'delete_trigger_modal.php',
						data: 'triggerid='+triggerid        
				   })
				   .done(function(response){        
						bootbox.alert(response);
						parent.fadeOut('slow');        
				   })
				   .fail(function(){        
						bootbox.alert('Error....');               
				   })              
				  }
				}
			}
	   });   
	});  
 });