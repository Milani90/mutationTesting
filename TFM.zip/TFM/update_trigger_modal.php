<?php
$(document).ready(function(){
	$(document).on('click', '.update', function(){
		var id=$(this).val();		
		
		$nombre= $('#enombre'+id).text();
		
		$descripcion=$('#edescripcion'+id).text();
		$cuerpo_trigger=$('#ecuerpo_trigger'+id).text();
		$funcion_trigger=$('#efuncion_trigger'+id).text();
		$idtrigger = $('#eidtrigger'+id).text();
		
	
	
	//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
	$conexion = pg_connect($_SESSION['conexion']);
	
//if($_REQUEST['triggerid']) {
	//$sql = "DELETE FROM triggers WHERE idtrigger='".$_REQUEST['triggerid']."'";
	//NOMBRE, DESCRIPCION, CUERPO_TRIGGER, FUNCION_TRIGGER
	//$sql = "UPDATE triggers SET nombre = '$nombre',  description = '$descripcion', cuerpo_trigger = '$cuepo_trigger', funcion_trigger = '$funcion_trigger' WHERE idtrigger = '".$_REQUEST['idtrigger']."'";
	$sql = "DELETE FROM triggers WHERE idtrigger='".$_REQUEST['triggerid']."'";
	$resultset = pg_query($conexion, $sql) or die("database error:". pg_last_error($conn));	
	if($resultset) {
		echo "Record Updated";
		}
	}
	)});
	
		
	//});
//})});
?>