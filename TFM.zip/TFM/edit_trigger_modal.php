<!-- Edit Modal HTML -->
	<div id="edit" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content" style="width: 1000px; ">
				<!--<form action="edit_trigger.php" method="POST">-->
					<div class="modal-header">						
						<h4 class="modal-title">Edit Trigger</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					
									<div class="modal-body">
									<div class="form-group">
										<label>TRIGGER NAME</label>
										<!-- $nombre = isset($reg[0]) ? $reg[0] : null ;-->
										<input type="text" class="form-control" name="enombre2222"  id="enombre222">
										 
									</div>
									
									<div class="form-group">
										<label>DESCRIPTION</label>
										<!--$descripcion = isset($reg[1]) ? $reg[1] : null ;									-->
										<input type="text" class="form-control" name="edescripcion2222" id="edescripcion2222">
										
									</div>
									<div class="form-group">
										<label>TRIGGER HEADER</label>
											<!--$cuerpo_trigger = isset($reg[2]) ? $reg[2] : null ;									-->
										<textarea class="form-control" name="ecuerpo_trigger2222" id="ecuerpo_trigger2222"></textarea>

									</div>
									<div class="form-group">
									<label>TRIGGER FUNCTION</label>
											<!--$funcion_trigger = isset($reg[3]) ? $reg[3] : null ;-->
									<textarea class="form-control" name="efuncion_trigger2222" id="efuncion_trigger2222"></textarea>
									
									</div>
									<!--$idtrigger = isset($reg[4]) ? $reg[4] : null ; -->
									<input type="hidden" class="form-control" name="eidtrigger2222" id="eidtrigger222">

															
								</div>
								<div class="modal-footer">
								<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">				
									<input type="submit" id="update" class="btn btn-info" value="Save">
								</div>	
									
									<!--break;--
								}
								-->
								
								 <!--
								//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
								pg_free_result($res);
								 
								//Cerramos la conexión
								pg_close($conexion);
								?>
								-->
								
					
				<!--</form>-->
			</div>
		</div>
	</div>