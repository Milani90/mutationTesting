<?php
session_start();
$conexion = pg_connect($_SESSION['conexion']);
$numFilas = pg_query("SELECT * FROM MUTATIONS");
$num = pg_num_rows($numFilas);
IF($num <> 79){
ECHO 'numero de filas de mutations es: ', $numFilas;

ECHO '<BR>';
echo 'FILAS: ', $num;
}


$nombre = "";
$consulta = "SELECT * FROM mutations where idtrigger = '8' LIMIT 1";
$res = pg_query($consulta);
while ($reg = pg_fetch_array($res, null, PGSQL_ASSOC)) {
	$nombre = $reg['functionname'];
}
echo 'NOMBRE: ',$nombre;
pg_close($conexion);


?>