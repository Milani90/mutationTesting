<!-- Edit Modal HTML -->
	<div id="edit" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<!--<form action="edit_trigger.php" method="POST">-->
					<div class="modal-header">						
						<h4 class="modal-title">Edit Suite</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					
									<div class="modal-body">
									<div class="form-group">
										<label>TRIGGER SUITE</label>
										<input type="text" class="form-control" name="enombre" id="enombre">
										 
									</div>
									
									<div class="form-group">
										<label>DESCRIPTION</label>
										<input type="text" class="form-control" name="edescripcion" id="edescripcion">
										
									</div>
									
									<input type="hidden" class="form-control" name="eidtrigger"  id="eidtrigger">

															
								</div>
								<div class="modal-footer">
								<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">				
									<input type="submit" id="update" class="btn btn-info" value="Save">
								</div>	
									
									<!--break;--
								}
								-->
								
								 <!--
								//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
								pg_free_result($res);
								 
								//Cerramos la conexión
								pg_close($conexion);
								?>
								-->
								
					
				<!--</form>-->
			</div>
		</div>
	</div>