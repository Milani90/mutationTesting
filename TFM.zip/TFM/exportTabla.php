<?php



	$host = "host=127.0.0.1 ";
	$port = "port=5432 ";
	$dbname = "dbname=pruebas ";
	$user = " user=postgres ";
	$password = "password=root";
	$confConexion = $host . $port . $dbname .$user . $password;
	//$con = pg_connect($_SESSION['conexion']);
	$con = pg_connect($confConexion);



$tbl_nombre  = 'employees';
$respaldoSQL = '/employees.sql'; 




$query = "select * into outfile ".$respaldoSQL." FROM $tbl_nombre;";
$result = pg_query($con,$query);
?>