	<?php
//string con comillas simples
	$cadena_con_comillas_simples = "aquí ' hay una comilla simple escapada";
	echo addslashes($cadena_con_comillas_simples);
?>
	<br>
<?php
	//string con comillas dobles
	$cadena_con_comillas_dobles = 'aquí " hay comillas dobles escapadas';
	echo addslashes($cadena_con_comillas_dobles);
?>

<br>
<?php
//string con comillas simples
	$cadena_con_comillas_simples_escapadas = addslashes("aquí ' hay una comilla simple escapada");
	echo $cadena_con_comillas_simples_escapadas;
	$cadena_con_escape_quitado = stripslashes("aquí ' ya no hay una comilla simple escapada");
	echo "<br>".$cadena_con_escape_quitado;
	
?>

<br>
<br>
<?php

//$contenido = "aquí ' hay una comilla simple escapada2";
//$contenido = ereg_replace("'", "\"", $contenido); 
//echo $contenido;

?>




<br>
<br>
<?php

$contenido2 = "aquí ' hay una comilla simple escapada22";
$contenido2 = pg_escape_string($contenido2); 
echo 'pruebas: ', $contenido2;

?>





<br>
<br>
<?php

$str = "Is your name O'Reilly?";

// Outputs: Is your name O\'Reilly?
echo addslashes($str);

?>




<br>
<br>
<?php

$contenido99 = 'aquí " hay una comilla simple escapada22';
$contenido99 = str_replace('&quot;','&#39;', $contenido99);
echo 'pruebas99: <br>', $contenido99;
echo '<br>';
echo addslashes($contenido99);
?>

<br>
<br>
<?php

$contenido66 = 'aquí " hay una" co"mi"l"la simple" escapada66';
$contenido66 = str_replace('"','\'', $contenido66);
echo 'pruebas66: <br>', $contenido66;
echo '<br>';
echo addslashes($contenido66);


?>

<br>
<br>
<?php

$contenido66 = '
CREATE FUNCTION stock_insert_trigger2() RETURNS TRIGGER AS $$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || "VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$$ LANGUAGE plpgsql';

$contenido66 = str_replace('"','\'', $contenido66);
echo 'TEXTO: <br>', $contenido66;
echo '<br>';
//echo addslashes($contenido66);


?>




