	<?php
session_start(); //Iniciamos o Continuamos la sesion
/*
if (isset($_POST['login'])) //Si llego un Nickname via el formulario lo grabamos en la Sesion
{
	$_SESSION['login'] = $_POST['login']; 
}
if ($_SESSION['login']) //Si hay un nickname en la sesion actual, creamos una variable que será mostrada
{
	
	
}
*/
//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
$conexion = pg_connect($_SESSION['conexion']);




$login = $_POST['email']; 
$password = $_POST['password']; 

 if(isset($_POST['shareInfo']))
 {
	$shareInfo = $_POST['shareInfo']; 	 
 }
 else{
	$shareInfo = "";
 }


if ($shareInfo == 'yes')
{
	$shareInfo = 'true';
}
else
{
	$shareInfo = 'false';
}

if($_POST['password']==$_POST['password2'])
{
     # son iguales
}else{
     # no son iguales
}




$sql = "insert into users(login,password,compartirinfo) values ('$login', '$password','$shareInfo')";
		//insert into triggers(name,headertrigger,bodytrigger,login,databasename,description) values ('$triggerName', '$triggerHeader', '$triggerFunction' ,'cristian', 'tfm', '{$description}');																							
//$sql = "insert into triggers(name, description, headertrigger, bodytrigger, login) values ('nombre', 'description','{triggerheader}', '{triggerfunction}' ,'$usuario')";						
//$sql = "insert into triggers(name, headertrigger, bodytrigger, login, description) values ('nombre', 'null', 'null' ,'$usuario', 'pruebas')";						
//$sql = "insert into triggers(name, login) values ('nombre','$usuario')";						
 
//Ejecutamos la consulta
$res = pg_query($sql) or die('La consulta fallo: ' . pg_last_error());
 
echo "Usuario insertado correctamente";
 
//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
pg_free_result($res);
 
//Cerramos la conexión
pg_close($conexion);
//header('location: index.php');
?>