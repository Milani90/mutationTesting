<?php
//export PGPASSWORD="root";
//exec("pg_basebackup -U postgres -h localhost -p 5433 tfm > C:/xampp/htdocs/TFM/paraguay2.sql");
//exec("pg_dump -i -h localhost -p 5432 -U postgres -F c -b -v -f 'C:/xampp/htdocs/TFM/back.sql' tfm");
//exec("set PGPASSWORD='root'");
//exec("export PGPASSWORD='root'");
//exec("set PGPASSWORD='root'");
//exec("pg_dump.exe -U postgres -d tfm -f C:\xampp\htdocs\TFM\cristiano2.sql");
putenv("PGPASSWORD='root'");
exec("'C:\Program Files (x86)\PostgreSQL\10\bin\pg_dump' tfm > database.sql");
//exec("pg_dump.exe -U postgres -d tfm -f C:\xampp\htdocs\TFM\cristiano2.sql");
//pg_dump.exe -U postgres -d tfm -f C:\xampp\htdocs\TFM\cristiano22.sql
?>