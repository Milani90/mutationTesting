<?php


$mostrar = isset($_GET['juegosPorPagina']) ? $_GET['juegosPorPagina'] : 0;

echo $mostrar;


?>
<form class="Motrar" action="desplegable2.php" method="get">
    <p>Mostrar:</p>
    <select  name="juegosPorPagina"  onChange="submit()">
        <option name="10" value="10">10</option>
        <option name="20" value="20">20</option>
        <option name="40" value="40">40</option>
    </select>
</form>