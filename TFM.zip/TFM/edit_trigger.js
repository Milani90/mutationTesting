$(document).ready(function(){
	$(document).on('click', '.edit', function(){
		var id=$(this).val();		
		/*
		var descripcion= $('#descripcion'+id).text();
		var funcion_trigger=$('#funcion_trigger'+id).text();
		var cuerpo_trigger=$('#cuerpo_trigger'+id).text();
		var descripcion= $('#descripcion'+id).text();
		var funcion_trigger=$('#funcion_trigger'+id).text();
		*/
		var nombre= $('#nombre'+id).text();
		var descripcion=$('#descripcion'+id).text();
		var cuerpo_trigger=$('#cuerpo_trigger'+id).text();
		var funcion_trigger=$('#funcion_trigger'+id).text();
		//var idtrigger = $('#idtrigger'+id).text();
		var idtrigger = id;
		
	
		$('#edit').modal('show');
	
		
		$('#enombre').val(nombre);
		$('#edescripcion').val(descripcion);
		$('#ecuerpo_trigger').val(cuerpo_trigger);
		$('#efuncion_trigger').val(funcion_trigger);
		$('#eidtrigger').val(idtrigger);
		
		
		
	});
});

$(document).ready(function(){
	$(document).on('click', '.actualizar', function(){
		alert('PRUEBAS222');
		/*
		var id=$(this).val();		
		var descripcion= $('#descripcion'+id).text();
		var funcion_trigger=$('#funcion_trigger'+id).text();
		var cuerpo_trigger=$('#cuerpo_trigger'+id).text();
		//var address=$('#address').text();
		
	
		$('#edit').modal('show');
		$('#edescripcion').val(descripcion);
		$('#efuncion_trigger').val(funcion_trigger);
		$('#ecuerpo_trigger').val(cuerpo_trigger);
		*/
	});
});

