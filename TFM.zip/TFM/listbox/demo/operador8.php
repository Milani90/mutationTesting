<?php
if($oper == 8  )
{
	echo "<br>";
	echo "Has marcado la opción 1, Operador1: MAS - MENOS.";
	echo "<br>";
		if (strpos($function, '+') !== false) {
			echo "<br>";
			echo "Si es posible realizar la operación";
			
		}
		else{
			echo "<br>";
			echo "NO es posible realizar la operación";
			echo "<br>";
		}
	
		echo '<br>';
		$reemplazos = substr_count($function, '+');
		echo "Nº mutantes posibles: ", substr_count($function, '+'); 
		echo '<br>';
		
		echo '<br><br><br>';
		
		echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
		echo '<br>';
		
		echo $function;	
		$original=$function;	
		echo "<br><br>";
		echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
		echo '<br>';
		
	//INICIO ALGORITMO
	
	
$mutantes = substr_count($function, '+');


for ($contador = 1; $contador <= $mutantes; $contador++){  
 
  if($contador === 1){
      echo '<br>';
     
      
      $encuentraMas = '+';
      $posicionMas = strpos($function, $encuentraMas);
     
      
      $trozo = substr ( $function , 0 , $posicionMas + 1  );
      $resto = substr ( $function , $posicionMas + 1  );
      
      
	  echo '<br>';
	  $cambiado = str_replace("+", "-", $trozo);
  

	$mutanteOper1 = $cambiado .= $resto; 
	if($contador == 0){
		$contador = 1;
	  }
	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br>';

	  echo $mutanteOper1, '<br>';
	  
	  echo '</span>';
	  
	  //INICIO INSERT MUTANTE
	  
	$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");


//Trigger
			$encuentraCreateTrigger = 'CREATE TRIGGER';
            //$posCreateTrigger = strpos($mutanteOper1, $encuentraCreateTrigger);
			$posCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
            echo '<br>';
            

            $restoo = substr ( $trigger , $posCreateTrigger+14  );
            
           
            $auxiliar = explode(" ", $restoo);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
			
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
			
			
			
//FIN TRIGGER

//FUNCION
           
            $encuentraFunction = 'FUNCTION';
            $posicionFunction = strpos($function, $encuentraFunction);

            $restoFunction = substr ( $function , $posicionFunction + 8  );

            
            $nombreFunction = explode(" ", $restoFunction);  

			
            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			

			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper1);
			
			
			echo '<br>';


			

//FIN FUNCION



	//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE
			


	
	
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nomTrigger','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');"; 
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerOriginal','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');"; 
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerMutante','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');"; 
		
		


		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}

		pg_close($conexion);
	
	  
	  
	  //FIN INSERT MUTANTE
	  

  }
  else{
      
      
      $encuentraMas = '+';
      $posicionMas = strpos($mutanteOper1, $encuentraMas, $posicionMas);
      $function = substr ( $copia , 0 , $posicionMas);
      
      
      $resto = substr ( $mutanteOper1 , $posicionMas );    
      $mas = '+';
      $menos = '-';
      $cambio1 = preg_replace('/+/', $menos, $resto, 1);
      
      echo '<br>';
      $mutanteOper1 = $function.$cambio1; 
      if($contador == 0){
		$contador = 1;
	  }
	  echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br>';

	  echo $mutanteOper1, '<br>';

	  echo '</span>';

		// Create connection

			$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");

//Trigger
			$encuentraCreateTrigger = 'CREATE TRIGGER';
            $posicionCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
            echo '<br>';
            

            $restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
            
           
            $aux3 = explode(" ", $restoCreateTrigger);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			

			
			
			
			
			
			
			
			
//FIN TRIGGER

//FUNCION

			//INICIO
			
			
			//FIN


           
            $encuentraFunction = 'FUNCTION';
            $posicionFunction = strpos($function, $encuentraFunction);

            $restoFunction = substr ( $function , $posicionFunction + 8  );
            
            $nombreFunction = explode(" ", $restoFunction);  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper1);
			echo '<br>';


//FIN FUNCION





	//INICIO
		$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
		$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE



	
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerOriginal','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');";
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerMutante','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');";
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
	

		pg_close($conexion);
	
      
     
    }//FIN DEL ELSE OPER1
 
}



//}fin oper1

//if($oper ==2 )
//{
	echo "<br>";
	echo "Has marcado la opción 1, OPERADOR1: MENOS - MAS .";
	echo "<br>";
	if (strpos($copia, '-') !== false) {
		echo "<br>";
	echo "Si es posible realizar la operación";
	}
	else{
		echo "<br>";
	echo "NO es posible realizar la operación";
	}
	echo "<br>";
	$reemplazos = substr_count($copia, '-');
	echo "Nº mutantes posibles: ", substr_count($copia, '-'); 
	echo '<br>';
	

	echo "<br><br>";
	/*
	echo "<hr align='left' noshade='noshade' size='2' width='100%' />";


	echo '<br>';

	echo $copia;	
	//$original = $contenidoarchivo;	
	$original=$copia;	

	echo '<hr style=" border-top: 1px solid blue; width: 750px;">';
	echo '<br>';
	*/
	//INICIO ALGORITMO
	

	echo '<br>';
$mutantes = substr_count($copia, '-');
//echo "Nº mutantes posibles333: ", substr_count($copia, '-'); 


for ($cont = 1; $cont <= $mutantes; $cont++){  
  if($cont === 1){
      echo '<br>';
     
      
      $encuentraMenos = '-';
      $posicion = strpos($copia, $encuentraMenos);
     
     

      
      $trozo = substr ( $copia , 0 , $posicion + 3  );
      $resto = substr ( $copia , $posicion + 3  );
      
      
     

  echo '<br>';
  $cambiado = str_replace("-", "+", $trozo);
  

  $mutanteOper1 = $cambiado .= $resto; 
  if($contador == 0){
		$contador = 1;
	  }
	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $mutanteOper1, '<br><br><br><br>';
	  echo $mutanteOper1, '<br>';
	  echo '</span>';
	  //INICIO INSERT MUTANTE

      
      
      		// Create connection

$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
// Check connection

//Trigger
			$encuentraCreateTrigger = 'CREATE TRIGGER';
            $posCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
            echo '<br>';
            

            $restoo = substr ( $trigger , $posCreateTrigger+14  );
            
           
            $auxiliar = explode(" ", $restoo);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
	
	
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			

			
//FIN TRIGGER

//FUNCION

           
            $encuentraFunction = 'FUNCTION';
            $posicionFunction = strpos($copia, $encuentraFunction);

            $restoFunction = substr ( $copia , $posicionFunction + 8  );
            //echo $resto2;
            
            $nombreFunction = explode(" ", $restoFunction);  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			$search = $nombreTrigger;
			
			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			
			
			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper1);
			
			
			
           
             
            //fin funcion

//FIN FUNCION

			

//FIN CUERPOS

	//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE

	   $mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerOriginal','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');";
	   //$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerMutante','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');";
	   
//pg_query($conexion,$mutante);


$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}


pg_close($conexion);
	
	  
	  
	  //FIN INSERT MUTANTE

 }
  else{
      
      
      $encuentraMenos = '-';
      $posicion = strpos($mutanteOper1, $encuentraMenos, $posicion);
            $contenidoarchivo = substr ( $copia , 0 , $posicion);
      
      
      
      $resto = substr ( $mutanteOper1 , $posicion );    
      $mas = '+';
      $menos = '-';
      $cambio1 = preg_replace('/-/', $mas, $resto, 1);
      
      echo '<br>';
      $mutanteOper1 = $contenidoarchivo.$cambio1; 
      if($contador == 0){
		$contador = 1;
	  }
	  	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br>';
	  echo $mutanteOper1, '<br>';
	  echo '</span>';

	  
        		// Create connection

$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");

//Trigger
			$encuentraCreateTrigger = 'CREATE TRIGGER';
            $posicionCreateTrigger = strpos($mutanteOper1, $encuentraCreateTrigger);
            echo '<br>';
            

            $restoCreateTrigger = substr ( $mutanteOper1 , $posicionCreateTrigger+14  );
            
           
            $aux3 = explode(" ", $restoCreateTrigger);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			

		
			
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentraFunction = 'FUNCTION';
            $posicionFunction = strpos($contenidoarchivo, $encuentraFunction);

            $restoFunction = substr ( $contenidoarchivo , $posicionFunction + 8  );

            
            $nombreFunction = explode(" ", $restoFunction);  
		
            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
	
			
			$search = $nombreTrigger;
			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper1);
			


//FIN FUNCION

	//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE
 
	      $mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerOriginal','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');";
		  //$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerMutante','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');";
		  
	   
$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}



pg_close($conexion);
//fin conexion
      

      

    }
}//FIN ALGORITMO

}//FIN OPERADOR1
?>