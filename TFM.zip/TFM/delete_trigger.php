<?php
session_start();
	
	$conexion = pg_connect($_SESSION['conexion']);
	
								
								
	//Recuperamos el id modificado al hacer click 
	$idtrigger =$_POST['idtrigger'];
	
    
	
								
	

	//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
	pg_free_result($eliminado);
	
	

	$consultaFuncion = "select * from triggers where idtrigger = '$idtrigger'";
	$cuerpoTrigger = pg_query($conexion, $consultaFuncion);

	$res = pg_query($sql);							 
	//Recorremos el array asociativo con los datos
	while ($reg = pg_fetch_array($res, null, PGSQL_ASSOC)) {
		$cuerpoFuncion = $res['cuerpoTrigger'];
		$databasename = $res['databasename'];
	}


	$nombreFuncion = explode(" ", $cuerpoFuncion);
	
	
	$host = "host=127.0.0.1 ";
	$port = "port=5432 ";
	$dbname = "dbname=" . $databasename;
	$user = " user=postgres ";
	$password = "password=root";
	$confConexion = $host . $port . $dbname .$user . $password;
	
	
	            
            
	
	$eliminaFunction = "DROP FUNCTION '.$nombreFuncion[1].' CASCADE;";
	pg_query ($conexion, $eliminado);
	
	
	
	
								 
	//Cerramos la conexión
	pg_close($conexion);
								
	//header('Location: triggers.php');
								
								
?>