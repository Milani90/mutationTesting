<?php

//$string = "Esto es un\nejemplo con espacios\n y salto de linea";
$string = "Esto AND AND AND ANDERVIT linea";
echo preg_match_all("/[\sAND\s]/", $string);

$num = explode ( "AND " , $string ) ;
echo '<br>';
echo 'NUM: ',count($num) ;

?>