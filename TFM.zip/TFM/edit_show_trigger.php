<?php
	session_start();
	//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
	
	

 //Activamos todas las notificaciones de error posibles
  error_reporting (E_ALL);

  //Definimos el tratamiento de errores no controlados
  set_error_handler(function () 
  {
    throw new Exception("Error");
  });
  
    function LogDeErrores($numeroDeError, $descripcion, $fichero, $linea, $contexto){
	  echo '<br>';
   error_log("Error: [".$numeroDeError."] ".$descripcion." ".$fichero." ".$linea." ".json_encode($contexto)." \n\r", 3, "log_errores.txt");
  // $error = explode ("ERROR:", $descripcion);
  // $_SESSION['descripcionErrorTrigger'] = isset($error[1]) ? $error[1] : null ; 
   throw new Exception("Error");
  }
  set_error_handler("LogDeErrores");


	


//INICIO
try 
  {


$conexion = pg_connect($_SESSION['conexion']);
//Recuperamos el id modificado al hacer click 


	$nombre=$_POST['enombre'];
	echo $nombre;
	echo '<br>';echo '<br>';echo '<br>';
	$descripcion=$_POST['edescripcion'];
	//$descripcion=$_POST['description']; 
	//$descripcion=$_SESSION["descriptionTrigger"];
	echo $descripcion;
	//echo '<br>';echo '<br>';echo '<br>';
/*
	$cuerpo_trigger = $_POST['ecuerpo_trigger'];
	echo $cuerpo_trigger;
	echo '<br>';echo '<br>';echo '<br>';
	$funcion_trigger= $_POST['efuncion_trigger'];
	echo $funcion_trigger;
	echo '<br>';echo '<br>';echo '<br>';
*/
	$idtrigger = $_SESSION['idTrigger'];
	


$sql = "update triggers set name='$nombre', description='$descripcion' where idtrigger='$idtrigger'" ;
echo 'CONSULTAAAA: ', $sql;
	
	
//	echo 'CONSULTA UPDATE : ',  $sql;





 
//Ejecutamos la consulta

pg_query($conexion,$sql);


  

//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
//	pg_free_result($res);
	





	//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
//	pg_free_result($sql);
	 
	//Cerramos la conexión
pg_close($conexion);
header('location: triggers.php');

  }
  catch(Exception $e) //capturamos un posible error
  {
    //mostramos el texto del error al usuario	  
    echo "Error al insertar el trigger." . PHP_EOL;
	echo "Revise el código." . PHP_EOL;
	
	
	//header('location: error_trigger.php'); 
  }
  


  //Restablecemos el tratamiento de errores
  restore_error_handler();



//FIN



?>