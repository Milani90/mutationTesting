$(document).ready(function(){
	$(document).on('click', '.view', function(){
				
		var id=$(this).val();		
	
		$('#view').modal('show');
	

		$('#vnombre').val('preubas');
		$('#vdescripcion').val(descripcion);
		$('#vcuerpo_trigger').val(cuerpo_trigger);
		$('#vfuncion_trigger').val(funcion_trigger);
		$('#vidtrigger').val(idtrigger);
		
		$('#cristianCuerpo').val('asfdafdaff');
		$('#cristianFuncion').val('asdfasdfad');
		
	});
});

$(document).ready(function(){
	$(document).on('click', '.actualizar', function(){
		
	});
});

