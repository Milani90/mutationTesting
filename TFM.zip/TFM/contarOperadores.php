<?php
$aux = "esto > es una pruebas";
$mutantesRELMayor = preg_match_all( "[^<]>[^=]",strtolower($aux));
echo $mutantesRELMayor;


echo '<br>';

//buscando al menos 2 numeros seguidos en la cadena
//if (preg_match('/[^>]<[<]/',"miemail22@<<<email.com 45")) 
if (preg_match('/<[^>=]/',"miemail22@ < email.com 45", $matches, PREG_OFFSET_CAPTURE))
	{
		
	echo "HAY COINCIDENCIA";
	$posicion = $matches[0][1];
	echo 'POSICION: ', $posicion;
	} else 
		{
		echo "NO HAY COINCIDENCIA";
		}
	
	
?>