<?php
session_start(); //Iniciamos o Continuamos la sesion


include('conexion.php');

$nombre= $_POST['login'];
$pass= $_POST['password'];
$_SESSION['login'] =$nombre;
$_SESSION['password'] =$pass;


$conexion = pg_connect($_SESSION['conexion']);


$query=("SELECT * FROM users WHERE login='$nombre' and password='$pass'");




echo $query;

  
  $result = pg_query($conexion, $query);
  echo $result;
  $rows = pg_num_rows($result);
  echo 'NUMERO DE FILAS: ', $rows;
if($rows != 1){
	header("location: login.php");
}
else{
	header("location: index.php");
}




?>
