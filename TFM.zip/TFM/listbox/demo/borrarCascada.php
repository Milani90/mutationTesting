<?php 
session_start();
			$conexionBorradoF =	pg_connect($_SESSION['conexion']);	
			//$nombreFuncion = "select * from mutations where idtrigger = '".$_SESSION['triggerElegido']."'";
			$nombreFuncion = "select * from mutations where idtrigger = '225'";
			
			$nomFuncion = pg_query($nombreFuncion);
			while ($nFuncion = pg_fetch_array($nomFuncion, null, PGSQL_ASSOC)) {
				$nombreF = $nFuncion['functionname'];
				$borrarFuncion = "drop function ".$nombreF." cascade;";
				pg_query($borrarFuncion);
				break;
			}
			//drop function price_audit_v2() cascade;
			pg_close($conexionBorradoF);	

?>