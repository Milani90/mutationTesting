$(document).ready(function(){
	$(document).on('click', '.view', function(){
				
		var id=$(this).val();		
/*
		var nombre= $('#nombre'+id).text();
		alert(nombre);
		var descripcion=$('#descripcion'+id).text();
		var cuerpo_trigger=$('#cuerpo_trigger'+id).text();
		var funcion_trigger=$('#funcion_trigger'+id).text();
		//var idtrigger = $('#idtrigger'+id).text();
		var idtrigger = id;
		*/
	
		$('#view').modal('show');
	
		
		//$('#vnombre').val(nombre);
		$('#vnombre').val('preubas');
		$('#vdescripcion').val(descripcion);
		$('#vcuerpo_trigger').val(cuerpo_trigger);
		$('#vfuncion_trigger').val(funcion_trigger);
		$('#vidtrigger').val(idtrigger);
		
		$('#cristianCuerpo').val('asfdafdaff');
		$('#cristianFuncion').val('asdfasdfad');
		
		/*
		$('#enombre2222').val('CRISTIAN');
		$('#edescripcion').val(descripcion);
		$('#ecuerpo_trigger').val(cuerpo_trigger);
		$('#efuncion_trigger').val(funcion_trigger);
		$('#eidtrigger').val(idtrigger);
		*/
		//alert('PRUEBAS MILANI');
	});
});

$(document).ready(function(){
	$(document).on('click', '.actualizar', function(){
		alert('PRUEBAS222');
		/*
		var id=$(this).val();		
		var descripcion= $('#descripcion'+id).text();
		var funcion_trigger=$('#funcion_trigger'+id).text();
		var cuerpo_trigger=$('#cuerpo_trigger'+id).text();
		//var address=$('#address').text();
		
	
		$('#edit').modal('show');
		$('#edescripcion').val(descripcion);
		$('#efuncion_trigger').val(funcion_trigger);
		$('#ecuerpo_trigger').val(cuerpo_trigger);
		*/
	});
});

