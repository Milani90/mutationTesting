<?php
session_start();
// pg_execute('pg_dump --dbname=postgresql://root:root@127.0.0.1:5432/tfm > dbbackup.sql',$output);
    //echo($output);
	$con = pg_connect($_SESSION['conexion']);
/*	
	$host = "host=127.0.0.1 ";
	$_SESSION['host'] = $host;
	$port = "port=5432 ";
	$_SESSION['port'] =	$port;
	$dbname = "dbname=tfm ";
	$_SESSION['dbname'] = $dbname;
	$user = " user=postgres ";
	$_SESSION['user'] = $user;
	$password = "password=root";
	$_SESSION['passConf'] = $password;
	$confConexion = $host . $port . $dbname .$user . $password;
	$_SESSION['conexion'] = $confConexion;
	*/
	//pg_exec(pg_dump tfm > db.sql);
	//pg_exec("pg_dump -U root -W -h host tfm > tfm.sql");
	//exec("pg_dump -U root -o -f bdCristian.sql tfm");
//	exec("pg_dump -U root -o -f tfm > bdCristian.sql ");
	//exec("pg_dump -U postgres -W -h 127.0.0.1 tfm > udl.sql");
	
	exec("pg_dump -h localhost -U postgres tfm > fichero.sql");
	exec("pg_dump -u root -p tfm > udlog.sql");
	exec("pg_dump -U postgres tfm > dbexport.sql");
	exec("pg_dump -U root -W -F t tfm > udl.sql");
	exec("pg_dump -h localhost -Fc tfm > messi.sql");
	exec("pg_dump -h localhost -p 5432 -U postgres -Fc -b -v -f yo.sql tfm");
	exec("pg_dump -U postgres -h localhost -p 5433 tfm > paraguay2.sql");
	exec("pg_dump -U postgres pruebas > pg_mibd.sql");
	exec("pg_dumpall -U postgres > pg_todo.sql");
	exec("pg_dump -U postgres -f pg_mibd.sql tfm");
	
	//pg_dumpall -U postgres > pg_todo.sql
    //echo($output);
	/*
	putenv("PGPASSWORD=root");
$dumpcmd = array("pg_dump", "-i", "-U", escapeshellarg("postgres"), "-F", "c", "-b", "-v", "-f", escapeshellarg("backup4.sql"), escapeshellarg("tfm"));
exec( join(' ', $dumpcmd), $cmdout, $cmdresult );
putenv("PGPASSWORD");
if ($cmdresult != 0)
{
    # Handle error here...
    echo "error";
}
else{
	echo "copia realizada";
}
*/
exec("pg_dump -U postgres -W -h 127.0.0.1 tfm > basename.sql");
?>