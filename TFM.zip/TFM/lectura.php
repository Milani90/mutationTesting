<?php
session_start();

	$conexion = pg_connect($_SESSION['conexion']);
	// Now mysql result set is stored in php variable.
$result = pg_query($conexion ,"select distinct(idtrigger) as idtrigger from mutations"); 


$array = array();
while($row = pg_fetch_array($result, null, PGSQL_ASSOC))
{
    $array[] = $row['idtrigger'];
}
foreach ($array as $ejemplo){
	
	echo 'EJEMPLO: ',$ejemplo;
	echo '<br>';
}

	
		
if (in_array("593", $array)) {
    echo "Esta usado ese trigger";
}		

?>