<script src="view_trigger.js"></script>
<!-- Edit Modal HTML -->
	<div id="view" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				
					<div class="modal-header">						
						<h4 class="modal-title">View Trigger</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					
									<div class="modal-body">
									<div class="form-group">
										<label>TRIGGER NAME</label>
										<input type="text" class="form-control"  id="vnombre" name="vnombre" readonly>
										 
									</div>
									
									<div class="form-group">
										<label>DESCRIPTION</label>
										<input type="text" class="form-control" id="vdescripcion" name="vdescripcion" readonly>
										
									</div>
									<div class="form-group">
										<label>TRIGGER HEADER</label>
										<textarea class="form-control"  rows="5" id="vcuerpo_trigger" readonly></textarea>

									</div>
									<div class="form-group">
									<label>TRIGGER FUNCTION</label>
									<textarea class="form-control"  rows="10" id="vfuncion_trigger" readonly></textarea>
									
									</div>
									<input type="hidden" class="form-control"  id="vidtrigger" readonly>

															
								</div>
								
							
			</div>
		</div>
	</div>