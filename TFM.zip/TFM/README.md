A MUTATION TESTING FRAMEWORK FOR TRIGGERS IN POSTGRESQL

Requisitos para uso de la aplicación.

-Servidor web 
	a)Copiar los ficheros del repositorio al directorio correspondiente del servidor
-pgAdmin4
	a)Base de datos TFM (TFM.sql)
	b)Base de datos del usuario

Instrucciones básicas para uso de la aplicación.

-Para poder iniciar la aplicación es necesario la instalación de un servidor web en tu ordenador. 
A su vez, se debe añadir el módulo correspondiente de base de datos, en nuestro caso pgAdmin4.
Se debe ejecutar el script TFM.sql e instalar dicha base de datos. Posteriormente, se debe crear 
la base de datos propia del usuario. 

