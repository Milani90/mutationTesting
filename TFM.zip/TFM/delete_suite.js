$(document).ready(function(){  
	$('.delete').click(function(e){   
	   e.preventDefault();   
	   var suiteid = $(this).attr('data-emp-id');
	   var nameSuite = $(this).attr('data-nombreSuite-id');
	   var parent = $(this).parent("td").parent("tr");   
	   bootbox.dialog({
			message: "Are you sure you want to delete '"+ nameSuite+ "'?",
			title: "",
			buttons: {
				success: {
					  label: "No",
					  className: "btn-success",
					  callback: function() {
					  $('.bootbox').modal('hide');
				  }
				},
				danger: {
				  label: "Delete!",
				  className: "btn-danger",
				  callback: function() {       
				   $.ajax({        
						type: 'POST',
						url:  'delete_suite_modal.php',
						data: 'suiteid='+suiteid        
				   })
				   .done(function(response){        
						bootbox.alert(response);
						parent.fadeOut('slow');        
				   })
				   .fail(function(){        
						bootbox.alert('Error....');               
				   })              
				  }
				}
			}
	   });   
	});  
 });