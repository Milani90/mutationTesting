	<?php
session_start(); //Iniciamos o Continuamos la sesion
if (isset($_POST['login'])) //Si llego un Nickname via el formulario lo grabamos en la Sesion
{
	$_SESSION['login'] = $_POST['login']; 
}
if ($_SESSION['login']) //Si hay un nickname en la sesion actual, creamos una variable que será mostrada
{
	
	
}







$conexion = pg_connect($_SESSION['conexion']);


	$usuario = $_SESSION['login'];

	

$description = pg_escape_string($_SESSION['description']); 



$databasename = pg_escape_string($_SESSION['databaseName']); 



$tests = pg_escape_string($_SESSION['newTestAddAll']) ;

$test = explode(";", $tests);


//saco el numero de elementos
$longitud = count($test);




//Recorro todos los elementos
for($i=0; $i<$longitud-1; $i++)
{
		  
			
			
			//INICIO
			
			$secuenciaTest = pg_query("SELECT nextval('tests_idtest_seq') as id");
			$row = pg_fetch_array($secuenciaTest, 0);
			$testSecuencia = trim($row["id"]);
			
		
		  
		  
      //saco el valor de cada elemento	
	  $testInd = $test[$i];
	  	$testInd = rtrim($testInd);
		
		
		
	  $sqlTest = "insert into tests(idtest,test,databasename) values ( $testSecuencia,'$testInd', '$databasename')";


	  $resTest = pg_query($sqlTest);

	  
	  //TABLA TEST_SUITES
	  
		$sqlTestSuite = "insert into test_suites values ('".$_SESSION['idsuite']."', $testSecuencia)";
		$testSuite = pg_query($sqlTestSuite);
	  
	  
}





 
//Cerramos la conexión
pg_close($conexion);
header('location: suites.php');
//}





?>