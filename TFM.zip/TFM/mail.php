<?php
// El mensaje
$mensaje = "Esto es una prueba 1\r\nA ver si te llega correctamente 2\r\nUn saludo ";

$password = $_POST['email'];
echo $password;

//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=Pruebas user=postgres password=root");
$conexion = pg_connect($_SESSION['conexion']);
// Check connection
/*
if ($conexion->pg_connect("dbname=Pruebas") or die("Could not connect")) {
    die("Connection failed: " . $conexion->pg_connect("dbname=Pruebas") or die("Could not connect") );
} */
	
//pg_query($conexion,$mutante);
$to     = 'sergiocristianmilani@hotmail.com';
$from       = 'sergiocristianmilani@gmail.com';
$bounce     = "mybouncereceiver@example.com";
$subj       = "mysubject";
$message    = "blah";

$headers    = "From:$from\r\nReturn-path:$bounce";

mail($to, $subj, $message, $headers);

// Enviamos el email
//mail('sergiocristianmilani@hotmail.com', 'Probando la funcion MAIL desde PHP', $mensaje);


echo "EMAIL ENVIADO...";
 
 

?>