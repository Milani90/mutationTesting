<?php

	$contadorOper8 = $contador;
///	echo "<br>";
	//echo "Has marcado la opción 8, Operador: MAS - MENOS.";
	
	$existeOper8 = false;
	$mutantesIgual = substr_count(strtolower($function), '=');
	$mutantesDistinto = substr_count(strtolower($function), '<>');	
	$mutantesMenorQue = substr_count(strtolower($function), '<');
	$mutantesMenorIgual = substr_count(strtolower($function), '<=');
	$mutantesMayor = substr_count(strtolower($function), '>');
	$mutantesMayorQue = substr_count(strtolower($function), '>=');
  
	$mutantesConjunto = ($mutantesIgual*5) + ($mutantesDistinto*5) + ($mutantesMenorQue*5) + ($mutantesMenorIgual*5) + (mutantesMayor*5) + (mutantesMayorQue*5);
	echo 'MUTANTES: ',$mutantesConjunto;


	echo "<br>";
		
	
///		echo '<br>';
		

		$original=$function;	

		
	//INICIO ALGORITMO
	
	
$numIgual = substr_count($function, '=');
if($numIgual > 0){

for ($contadorMutantes = 1; $contadorMutantes <= $numIgual; $contadorMutantes++){  
 
  if($contadorMutantes === 1){
///      echo '<br>';
     
      
      $encuentraIgual = '+';
      $posicionIgual = strpos($function, $encuentraIgual);
     
      
      $trozo = substr ( $function , 0 , $posicionIgual + 1  );
      $resto = substr ( $function , $posicionIgual + 1  );
      
      
///	  echo '<br>';
	  $cambiado = str_replace("=", "<>", $trozo);
  

	$mutanteOper14 = $cambiado .= $resto; 
	if($contador == 0){
		$contador = 1;
	  }
///	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br>';

///	  echo $mutanteOper14, '<br>';
	  
///	  echo '</span>';
	  
	  //INICIO INSERT MUTANTE
	  
	$conexion = pg_connect($_SESSION['conexion']);


//Trigger
			$encuentraCreateTrigger = 'CREATE TRIGGER';
            //$posCreateTrigger = strpos($mutanteOper1, $encuentraCreateTrigger);
			$posCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
 ///           echo '<br>';
            

            $restoo = substr ( $trigger , $posCreateTrigger+14  );
            
           
            $auxiliar = explode(" ", $restoo);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
			
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
			
			
			
//FIN TRIGGER

//FUNCION
           
            $encuentraFunction = 'FUNCTION';
            $posicionFunction = strpos($function, $encuentraFunction);

            $restoFunction = substr ( $function , $posicionFunction + 8  );

            
            $nombreFunction = explode(" ", $restoFunction);  

			
            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			

			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper14);
			
			
///			echo '<br>';


			

//FIN FUNCION



	//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE
			
//COMPROBAMOS SI ESTA EL TRIGGER Y OPERADOR 
 	//echo 'OPERADOR: ', $oper; echo '<br>';
	$consulta = "select * from mutations where idtrigger = '".$triggerid."' and idoperator = '".$oper."'";
	$filasAfectadas = pg_query($consulta);
	$rows = pg_num_rows($filasAfectadas);

	//echo $rows . " row(s) returned.\n"; echo '<br>';
	
	
	
		if($rows == $mutantesConjunto)
		{
			////echo 'ESTE OPERADOR Y ESTE TRIGGER YA SE HA UTILIZADO';
			$existeOper8 = true ;
		}
		else{

	
	
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nomTrigger','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');"; 
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change) VALUES ('$nombreTriggerOriginal','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false','Replace + BY -');"; 
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerMutante','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');"; 
		
			$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}

		
	 //TABLA CRISTIAN
$res = pg_query("SELECT nextval('mutations_idmutation_seq') as id");
		$row = pg_fetch_array($res, 0);
		$mutationSecuencia = trim($row["id"]) + 1;
			
		echo '<TR>';
		echo '   <TD style="text-align:center">ARREP</TD>';
		echo '   <TD style="text-align:center">'.$mutationSecuencia.'</TD>';
		echo '	 <TD style="text-align:center">FUNCTION</TD>';
		echo '   <TD>'.$triggerMutanteActualizado.'<br>'.$functionMutante.'</TD>';
		echo '   <TD>Replace = BY <></TD>';
		echo '</TR>';
//FIN TABLA CRISTIAN

		}
		pg_close($conexion);
	
		
	  
	  //FIN INSERT MUTANTE
	  

  }
  else{
      
//INICIO + --> -
      $encuentraIgual = '=';
      $posicionIgual = strpos($mutanteOper14, $encuentraIgual, $posicionIgual);
      $function = substr ( $copia , 0 , $posicionIgual);
      
      
      $resto = substr ( $mutanteOper14 , $posicionIgual );    
      $igual = '=';
      $distinto = '<>';
      //$cambio1 = preg_replace('/+/', '/-/', $resto, 1);
	  $cambio1 = str_replace('=', '<>', $resto);
      
      echo '<br>';
      $mutanteOper14 = $function.$cambio1; 
      if($contador == 0){
		$contador = 1;
	  }
	  $contador = $contador + 1;
///	  echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br>';

///	  echo $mutanteOper14, '<br>';

///	  echo '</span>';

		// Create connection

			$conexion = pg_connect($_SESSION['conexion']);

//Trigger
			$encuentraCreateTrigger = 'CREATE TRIGGER';
            $posicionCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
            echo '<br>';
            

            $restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
            
           
            $aux3 = explode(" ", $restoCreateTrigger);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			

			
			
			
			
			
			
			
			
//FIN TRIGGER

//FUNCION

			//INICIO
			
			
			//FIN


           
            $encuentraFunction = 'FUNCTION';
            $posicionFunction = strpos($function, $encuentraFunction);

            $restoFunction = substr ( $function , $posicionFunction + 8  );
            
            $nombreFunction = explode(" ", $restoFunction);  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper14);
///			echo '<br>';


//FIN FUNCION





	//INICIO
		$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
		$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE

//COMPROBAMOS SI ESTA EL TRIGGER Y OPERADOR 
 	//echo 'OPERADOR: ', $oper; echo '<br>';
	$consulta = "select * from mutations where idtrigger = '".$triggerid."' and idoperator = '".$oper."'";
	$filasAfectadas = pg_query($consulta);
	$rows = pg_num_rows($filasAfectadas);

	//echo $rows . " row(s) returned.\n"; echo '<br>';
	
	
	
		if($rows == $mutantesConjunto)
		{
			////echo 'ESTE OPERADOR Y ESTE TRIGGER YA SE HA UTILIZADO';
			$existeOper14 = true ;
		}
		else{

	
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change) VALUES ('$nombreTriggerOriginal','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false', 'Replace + BY -');";
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerMutante','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');";
		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
	
		
			 //TABLA CRISTIAN
$res = pg_query("SELECT nextval('mutations_idmutation_seq') as id");
		$row = pg_fetch_array($res, 0);
		$mutationSecuencia = trim($row["id"]) + 1;
			
		echo '<TR>';
		echo '   <TD style="text-align:center">ARREP</TD>';
		echo '   <TD style="text-align:center">'.$mutationSecuencia.'</TD>';
		echo '	 <TD style="text-align:center">FUNCTION</TD>';
		echo '   <TD>'.$triggerMutanteActualizado.'<br>'.$functionMutante.'</TD>';
		echo '   <TD>Replace = BY <></TD>';
		echo '</TR>';
//FIN TABLA CRISTIAN
		
		
		}
		

		pg_close($conexion);
	
//FIN + --> -

  //aquiiiiiiiiiiii
    }//FIN DEL ELSE OPER1
 
}



//MAS POR MULTIPLICACION MILANIIIIIIIIIIII
//$mutantesMultiplicacion = substr_count($function, '*');


for ($contadorMutantes = 1; $contadorMutantes <= $numIgual; $contadorMutantes++){  
 
  if($contadorMutantes === 1){
///      echo '<br>';
     
      
      $encuentraIgual = '=';
      $posicionIgual = strpos($function, $encuentraIgual);
     
      
      $trozo = substr ( $copia , 0 , $posicionIgual + 1  );
      $resto = substr ( $copia , $posicionIgual + 1  );
	  
      
      
///	  echo '<br>';
	  $cambiado = str_replace("=", "<", $trozo);
  

	$mutanteOper14 = $cambiado .= $resto; 
	
	  $contador = $contador + 1;
///	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br>';

///	  echo $mutanteOper14, '<br>';
	  
///	  echo '</span>';
	  
	  //INICIO INSERT MUTANTE
	  
	$conexion = pg_connect($_SESSION['conexion']);


//Trigger
			$encuentraCreateTrigger = 'CREATE TRIGGER';
            //$posCreateTrigger = strpos($mutanteOper1, $encuentraCreateTrigger);
			$posCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
///            echo '<br>';
            

            $restoo = substr ( $trigger , $posCreateTrigger+14  );
            
           
            $auxiliar = explode(" ", $restoo);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
			
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
			
			
			
//FIN TRIGGER

//FUNCION
           
            $encuentraFunction = 'FUNCTION';
            $posicionFunction = strpos($function, $encuentraFunction);

            $restoFunction = substr ( $function , $posicionFunction + 8  );

            
            $nombreFunction = explode(" ", $restoFunction);  

			
            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			

			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper14);
			
			
///			echo '<br>';


			

//FIN FUNCION



	//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE
			

//COMPROBAMOS SI ESTA EL TRIGGER Y OPERADOR 
 	//echo 'OPERADOR: ', $oper; echo '<br>';
	$consulta = "select * from mutations where idtrigger = '".$triggerid."' and idoperator = '".$oper."'";
	$filasAfectadas = pg_query($consulta);
	$rows = pg_num_rows($filasAfectadas);

	//echo $rows . " row(s) returned.\n"; echo '<br>';
	
	
	
		if($rows == $mutantesConjunto)
		{
			////echo 'ESTE OPERADOR Y ESTE TRIGGER YA SE HA UTILIZADO';
			$existeOper14 = true ;
		}
		else{
	
	
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nomTrigger','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');"; 
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change) VALUES ('$nombreTriggerOriginal','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false', 'Replace + BY *');"; 
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerMutante','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');"; 
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}

		
 //TABLA CRISTIAN
$res = pg_query("SELECT nextval('mutations_idmutation_seq') as id");
		$row = pg_fetch_array($res, 0);
		$mutationSecuencia = trim($row["id"]) + 1;
			
		echo '<TR>';
		echo '   <TD style="text-align:center">CAO13</TD>';
		echo '   <TD style="text-align:center">'.$mutationSecuencia.'</TD>';
		echo '	 <TD style="text-align:center">FUNCTION</TD>';
		echo '   <TD>'.$triggerMutanteActualizado.'<br>'.$functionMutante.'</TD>';
		echo '   <TD>Replace + BY *</TD>';
		echo '</TR>';
//FIN TABLA CRISTIAN
		}
		
		pg_close($conexion);
	
	  
	  
	  //FIN INSERT MUTANTE
	  

  }
  else{
      
//INICIO + --> -
      $encuentraIgual = '=';
      $posicionIgual = strpos($mutanteOper14, $encuentraIgual, $posicionIgual);
      $function = substr ( $copia , 0 , $posicionIgual);
      
      
      $resto = substr ( $mutanteOper14 , $posicionIgual );    
      $mas = '+';
      $multiplicacion = '<';
      //$cambio1 = preg_replace('/+/', '/-/', $resto, 1);
	  $cambio1 = str_replace('=', '<', $resto);
      
      echo '<br>';
      $mutanteOper14 = $function.$cambio1; 
      if($contador == 0){
		$contador = 1;
	  }
	  $contador = $contador + 1;
///	  echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br>';

///	  echo $mutanteOper14, '<br>';

///	  echo '</span>';

		// Create connection

			$conexion = pg_connect($_SESSION['conexion']);

//Trigger
			$encuentraCreateTrigger = 'CREATE TRIGGER';
            $posicionCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
            echo '<br>';
            

            $restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
            
           
            $aux3 = explode(" ", $restoCreateTrigger);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			

			
			
			
			
			
			
			
			
//FIN TRIGGER

//FUNCION

			//INICIO
			
			
			//FIN


           
            $encuentraFunction = 'FUNCTION';
            $posicionFunction = strpos($function, $encuentraFunction);

            $restoFunction = substr ( $function , $posicionFunction + 8  );
            
            $nombreFunction = explode(" ", $restoFunction);  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper14);
///			echo '<br>';


//FIN FUNCION





	//INICIO
		$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
		$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE

	//COMPROBAMOS SI ESTA EL TRIGGER Y OPERADOR 
 	//echo 'OPERADOR: ', $oper; echo '<br>';
	$consulta = "select * from mutations where idtrigger = '".$triggerid."' and idoperator = '".$oper."'";
	$filasAfectadas = pg_query($consulta);
	$rows = pg_num_rows($filasAfectadas);

	//echo $rows . " row(s) returned.\n"; echo '<br>';
	
	
	
		if($rows == $mutantesConjunto)
		{
			////echo 'ESTE OPERADOR Y ESTE TRIGGER YA SE HA UTILIZADO';
			$existeOper14 = true ;
		}
		else{


	
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change) VALUES ('$nombreTriggerOriginal','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false','Replace + BY *');";
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerMutante','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');";
		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
		
		
		 //TABLA CRISTIAN
$res = pg_query("SELECT nextval('mutations_idmutation_seq') as id");
		$row = pg_fetch_array($res, 0);
		$mutationSecuencia = trim($row["id"]) + 1;
			
		echo '<TR>';
		echo '   <TD style="text-align:center">ARREP</TD>';
		echo '   <TD style="text-align:center">'.$mutationSecuencia.'</TD>';
		echo '	 <TD style="text-align:center">FUNCTION</TD>';
		echo '   <TD>'.$triggerMutanteActualizado.'<br>'.$functionMutante.'</TD>';
		echo '   <TD>Replace = BY <</TD>';
		echo '</TR>';
//FIN TABLA CRISTIAN
		
		}
		
	

		pg_close($conexion);
	
//FIN + --> -

  //aquiiiiiiiiiiii

    }//FIN DEL ELSE OPER1
 
}



//FIN MAS POR MULTIPLICACION MILANIII

//INICIO MAS POR DIVISION MILANIII



for ($contadorMutantes = 1; $contadorMutantes <= $numIgual; $contadorMutantes++){  
 
  if($contadorMutantes === 1){
///      echo '<br>';
     
      
      $encuentraIgual = '=';
      $posicionIgual = strpos($function, $encuentraIgual);
     
      
      $trozo = substr ( $copia , 0 , $posicionIgual + 1  );
      $resto = substr ( $copia , $posicionIgual + 1  );
	  
      
      
///	  echo '<br>';
	  $cambiado = str_replace("=", "<=", $trozo);
  

	$mutanteOper14 = $cambiado .= $resto; 
	
	  $contador = $contador + 1;
///	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br>';

///	  echo $mutanteOper14, '<br>';
	  
///	  echo '</span>';
	  
	  //INICIO INSERT MUTANTE
	  
	$conexion = pg_connect($_SESSION['conexion']);


//Trigger
			$encuentraCreateTrigger = 'CREATE TRIGGER';
            //$posCreateTrigger = strpos($mutanteOper1, $encuentraCreateTrigger);
			$posCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
            echo '<br>';
            

            $restoo = substr ( $trigger , $posCreateTrigger+14  );
            
           
            $auxiliar = explode(" ", $restoo);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
			
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
			
			
			
//FIN TRIGGER

//FUNCION
           
            $encuentraFunction = 'FUNCTION';
            $posicionFunction = strpos($function, $encuentraFunction);

            $restoFunction = substr ( $function , $posicionFunction + 8  );

            
            $nombreFunction = explode(" ", $restoFunction);  

			
            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			

			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper14);
			
			
///			echo '<br>';


			

//FIN FUNCION



	//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE
			
//COMPROBAMOS SI ESTA EL TRIGGER Y OPERADOR 
 	//echo 'OPERADOR: ', $oper; echo '<br>';
	$consulta = "select * from mutations where idtrigger = '".$triggerid."' and idoperator = '".$oper."'";
	$filasAfectadas = pg_query($consulta);
	$rows = pg_num_rows($filasAfectadas);

	//echo $rows . " row(s) returned.\n"; echo '<br>';
	
	
	
		if($rows == $mutantesConjunto)
		{
			////echo 'ESTE OPERADOR Y ESTE TRIGGER YA SE HA UTILIZADO';
			$existeOper14 = true ;
		}
		else{

	
	
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nomTrigger','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');"; 
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change) VALUES ('$nombreTriggerOriginal','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false','Replace + BY /');"; 
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerMutante','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');"; 
		
		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
		 //TABLA CRISTIAN
$res = pg_query("SELECT nextval('mutations_idmutation_seq') as id");
		$row = pg_fetch_array($res, 0);
		$mutationSecuencia = trim($row["id"]) + 1;
			
		echo '<TR>';
		echo '   <TD style="text-align:center">ARREP</TD>';
		echo '   <TD style="text-align:center">'.$mutationSecuencia.'</TD>';
		echo '	 <TD style="text-align:center">FUNCTION</TD>';
		echo '   <TD>'.$triggerMutanteActualizado.'<br>'.$functionMutante.'</TD>';
		echo '   <TD>Replace = BY <=</TD>';
		echo '</TR>';
//FIN TABLA CRISTIAN

		}
		

		pg_close($conexion);
	
	  
	  
	  //FIN INSERT MUTANTE
	  

  }
  else{
      
//INICIO + --> -
      $encuentraIgual = '=';
      $posicionIgual = strpos($mutanteOper14, $encuentraIgual, $posicionIgual);
      $function = substr ( $copia , 0 , $posicionIgual);
      
      
      $resto = substr ( $mutanteOper14 , $posicionIgual );    
      $igual = '=';
      $mayorIgual = '<>';
      //$cambio1 = preg_replace('/+/', '/-/', $resto, 1);
	  $cambio1 = str_replace('=', '<=', $resto);
      
      echo '<br>';
      $mutanteOper14 = $function.$cambio1; 
      if($contador == 0){
		$contador = 1;
	  }
	  else{
	  $contador = $contador + 1;
	  }
///	  echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br>';

///	  echo $mutanteOper14, '<br>';

///	  echo '</span>';

		// Create connection

			$conexion = pg_connect($_SESSION['conexion']);

//Trigger
			$encuentraCreateTrigger = 'CREATE TRIGGER';
            $posicionCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
///            echo '<br>';
            

            $restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
            
           
            $aux3 = explode(" ", $restoCreateTrigger);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			

			
			
			
			
			
			
			
			
//FIN TRIGGER

//FUNCION

			//INICIO
			
			
			//FIN


           
            $encuentraFunction = 'FUNCTION';
            $posicionFunction = strpos($function, $encuentraFunction);

            $restoFunction = substr ( $function , $posicionFunction + 8  );
            
            $nombreFunction = explode(" ", $restoFunction);  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper14);
///			echo '<br>';


//FIN FUNCION





	//INICIO
		$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
		$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE

//COMPROBAMOS SI ESTA EL TRIGGER Y OPERADOR 
 	//echo 'OPERADOR: ', $oper; echo '<br>';
	$consulta = "select * from mutations where idtrigger = '".$triggerid."' and idoperator = '".$oper."'";
	$filasAfectadas = pg_query($consulta);
	$rows = pg_num_rows($filasAfectadas);

	//echo $rows . " row(s) returned.\n"; echo '<br>';
	
	
	
		if($rows == $mutantesConjunto)
		{
			////echo 'ESTE OPERADOR Y ESTE TRIGGER YA SE HA UTILIZADO';
			$existeOper14 = true ;
		}
		else{

	
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change) VALUES ('$nombreTriggerOriginal','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false','Replace + BY /');";
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerMutante','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');";
		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
		
		
		 //TABLA CRISTIAN
$res = pg_query("SELECT nextval('mutations_idmutation_seq') as id");
		$row = pg_fetch_array($res, 0);
		$mutationSecuencia = trim($row["id"]) + 1;
			
		echo '<TR>';
		echo '   <TD style="text-align:center">ARREP</TD>';
		echo '   <TD style="text-align:center">'.$mutationSecuencia.'</TD>';
		echo '	 <TD style="text-align:center">FUNCTION</TD>';
		echo '   <TD>'.$triggerMutanteActualizado.'<br>'.$functionMutante.'</TD>';
		echo '   <TD>Replace = BY <=</TD>';
		echo '</TR>';
//FIN TABLA CRISTIAN
		
		
		}
		
	

		pg_close($conexion);
	
//FIN + --> -

  //aquiiiiiiiiiiii     
    }//FIN DEL ELSE OPER1
 
}

//FIN MAS POR DIVISION MILANII

//INICIO = POR >

for ($contadorMutantes = 1; $contadorMutantes <= $numIgual; $contadorMutantes++){  
 
  if($contadorMutantes === 1){
///      echo '<br>';
     
      
      $encuentraIgual = '=';
      $posicionIgual = strpos($function, $encuentraIgual);
     
      
      $trozo = substr ( $copia , 0 , $posicionIgual + 1  );
      $resto = substr ( $copia , $posicionIgual + 1  );
	  
      
      
///	  echo '<br>';
	  $cambiado = str_replace("=", ">", $trozo);
  

	$mutanteOper14 = $cambiado .= $resto; 
	
	  $contador = $contador + 1;
///	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br>';

///	  echo $mutanteOper14, '<br>';
	  
///	  echo '</span>';
	  
	  //INICIO INSERT MUTANTE
	  
	$conexion = pg_connect($_SESSION['conexion']);


//Trigger
			$encuentraCreateTrigger = 'CREATE TRIGGER';
            //$posCreateTrigger = strpos($mutanteOper1, $encuentraCreateTrigger);
			$posCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
            echo '<br>';
            

            $restoo = substr ( $trigger , $posCreateTrigger+14  );
            
           
            $auxiliar = explode(" ", $restoo);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
			
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
			
			
			
//FIN TRIGGER

//FUNCION
           
            $encuentraFunction = 'FUNCTION';
            $posicionFunction = strpos($function, $encuentraFunction);

            $restoFunction = substr ( $function , $posicionFunction + 8  );

            
            $nombreFunction = explode(" ", $restoFunction);  

			
            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			

			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper14);
			
			
///			echo '<br>';


			

//FIN FUNCION



	//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE
			
//COMPROBAMOS SI ESTA EL TRIGGER Y OPERADOR 
 	//echo 'OPERADOR: ', $oper; echo '<br>';
	$consulta = "select * from mutations where idtrigger = '".$triggerid."' and idoperator = '".$oper."'";
	$filasAfectadas = pg_query($consulta);
	$rows = pg_num_rows($filasAfectadas);

	//echo $rows . " row(s) returned.\n"; echo '<br>';
	
	
	
		if($rows == $mutantesConjunto)
		{
			////echo 'ESTE OPERADOR Y ESTE TRIGGER YA SE HA UTILIZADO';
			$existeOper14 = true ;
		}
		else{

	
	
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nomTrigger','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');"; 
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change) VALUES ('$nombreTriggerOriginal','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false','Replace + BY /');"; 
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerMutante','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');"; 
		
		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
		 //TABLA CRISTIAN
$res = pg_query("SELECT nextval('mutations_idmutation_seq') as id");
		$row = pg_fetch_array($res, 0);
		$mutationSecuencia = trim($row["id"]) + 1;
			
		echo '<TR>';
		echo '   <TD style="text-align:center">ARREP</TD>';
		echo '   <TD style="text-align:center">'.$mutationSecuencia.'</TD>';
		echo '	 <TD style="text-align:center">FUNCTION</TD>';
		echo '   <TD>'.$triggerMutanteActualizado.'<br>'.$functionMutante.'</TD>';
		echo '   <TD>Replace = BY ></TD>';
		echo '</TR>';
//FIN TABLA CRISTIAN

		}
		

		pg_close($conexion);
	
	  
	  
	  //FIN INSERT MUTANTE
	  

  }
  else{
      
//INICIO + --> -
      $encuentraIgual = '=';
      $posicionIgual = strpos($mutanteOper14, $encuentraIgual, $posicionIgual);
      $function = substr ( $copia , 0 , $posicionIgual);
      
      
      $resto = substr ( $mutanteOper14 , $posicionIgual );    
      $igual = '=';
      $mayorIgual = '<>';
      //$cambio1 = preg_replace('/+/', '/-/', $resto, 1);
	  $cambio1 = str_replace('=', '>', $resto);
      
      echo '<br>';
      $mutanteOper14 = $function.$cambio1; 
      if($contador == 0){
		$contador = 1;
	  }
	  else{
	  $contador = $contador + 1;
	  }
///	  echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br>';

///	  echo $mutanteOper14, '<br>';

///	  echo '</span>';

		// Create connection

			$conexion = pg_connect($_SESSION['conexion']);

//Trigger
			$encuentraCreateTrigger = 'CREATE TRIGGER';
            $posicionCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
///            echo '<br>';
            

            $restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
            
           
            $aux3 = explode(" ", $restoCreateTrigger);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			

			
			
			
			
			
			
			
			
//FIN TRIGGER

//FUNCION

			//INICIO
			
			
			//FIN


           
            $encuentraFunction = 'FUNCTION';
            $posicionFunction = strpos($function, $encuentraFunction);

            $restoFunction = substr ( $function , $posicionFunction + 8  );
            
            $nombreFunction = explode(" ", $restoFunction);  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper14);
///			echo '<br>';


//FIN FUNCION





	//INICIO
		$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
		$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE

//COMPROBAMOS SI ESTA EL TRIGGER Y OPERADOR 
 	//echo 'OPERADOR: ', $oper; echo '<br>';
	$consulta = "select * from mutations where idtrigger = '".$triggerid."' and idoperator = '".$oper."'";
	$filasAfectadas = pg_query($consulta);
	$rows = pg_num_rows($filasAfectadas);

	//echo $rows . " row(s) returned.\n"; echo '<br>';
	
	
	
		if($rows == $mutantesConjunto)
		{
			////echo 'ESTE OPERADOR Y ESTE TRIGGER YA SE HA UTILIZADO';
			$existeOper14 = true ;
		}
		else{

	
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change) VALUES ('$nombreTriggerOriginal','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false','Replace + BY /');";
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerMutante','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');";
		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
		
		
		 //TABLA CRISTIAN
$res = pg_query("SELECT nextval('mutations_idmutation_seq') as id");
		$row = pg_fetch_array($res, 0);
		$mutationSecuencia = trim($row["id"]) + 1;
			
		echo '<TR>';
		echo '   <TD style="text-align:center">ARREP</TD>';
		echo '   <TD style="text-align:center">'.$mutationSecuencia.'</TD>';
		echo '	 <TD style="text-align:center">FUNCTION</TD>';
		echo '   <TD>'.$triggerMutanteActualizado.'<br>'.$functionMutante.'</TD>';
		echo '   <TD>Replace = BY ></TD>';
		echo '</TR>';
//FIN TABLA CRISTIAN
		
		
		}
		
	

		pg_close($conexion);
	
//FIN + --> -

  //aquiiiiiiiiiiii     
    }//FIN DEL ELSE OPER1
 
}

//FIN = POR >

//INICIO = POR >= 

for ($contadorMutantes = 1; $contadorMutantes <= $numIgual; $contadorMutantes++){  
 
  if($contadorMutantes === 1){
///      echo '<br>';
     
      
      $encuentraIgual = '=';
      $posicionIgual = strpos($function, $encuentraIgual);
     
      
      $trozo = substr ( $copia , 0 , $posicionIgual + 1  );
      $resto = substr ( $copia , $posicionIgual + 1  );
	  
      
      
///	  echo '<br>';
	  $cambiado = str_replace("=", ">=", $trozo);
  

	$mutanteOper14 = $cambiado .= $resto; 
	
	  $contador = $contador + 1;
///	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br>';

///	  echo $mutanteOper14, '<br>';
	  
///	  echo '</span>';
	  
	  //INICIO INSERT MUTANTE
	  
	$conexion = pg_connect($_SESSION['conexion']);


//Trigger
			$encuentraCreateTrigger = 'CREATE TRIGGER';
            //$posCreateTrigger = strpos($mutanteOper1, $encuentraCreateTrigger);
			$posCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
            echo '<br>';
            

            $restoo = substr ( $trigger , $posCreateTrigger+14  );
            
           
            $auxiliar = explode(" ", $restoo);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
			
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
			
			
			
//FIN TRIGGER

//FUNCION
           
            $encuentraFunction = 'FUNCTION';
            $posicionFunction = strpos($function, $encuentraFunction);

            $restoFunction = substr ( $function , $posicionFunction + 8  );

            
            $nombreFunction = explode(" ", $restoFunction);  

			
            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			

			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper14);
			
			
///			echo '<br>';


			

//FIN FUNCION



	//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE
			
//COMPROBAMOS SI ESTA EL TRIGGER Y OPERADOR 
 	//echo 'OPERADOR: ', $oper; echo '<br>';
	$consulta = "select * from mutations where idtrigger = '".$triggerid."' and idoperator = '".$oper."'";
	$filasAfectadas = pg_query($consulta);
	$rows = pg_num_rows($filasAfectadas);

	//echo $rows . " row(s) returned.\n"; echo '<br>';
	
	
	
		if($rows == $mutantesConjunto)
		{
			////echo 'ESTE OPERADOR Y ESTE TRIGGER YA SE HA UTILIZADO';
			$existeOper14 = true ;
		}
		else{

	
	
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nomTrigger','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');"; 
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change) VALUES ('$nombreTriggerOriginal','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false','Replace + BY /');"; 
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerMutante','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');"; 
		
		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
		 //TABLA CRISTIAN
$res = pg_query("SELECT nextval('mutations_idmutation_seq') as id");
		$row = pg_fetch_array($res, 0);
		$mutationSecuencia = trim($row["id"]) + 1;
			
		echo '<TR>';
		echo '   <TD style="text-align:center">ARREP</TD>';
		echo '   <TD style="text-align:center">'.$mutationSecuencia.'</TD>';
		echo '	 <TD style="text-align:center">FUNCTION</TD>';
		echo '   <TD>'.$triggerMutanteActualizado.'<br>'.$functionMutante.'</TD>';
		echo '   <TD>Replace = BY >=</TD>';
		echo '</TR>';
//FIN TABLA CRISTIAN

		}
		

		pg_close($conexion);
	
	  
	  
	  //FIN INSERT MUTANTE
	  

  }
  else{
      
//INICIO + --> -
      $encuentraIgual = '=';
      $posicionIgual = strpos($mutanteOper14, $encuentraIgual, $posicionIgual);
      $function = substr ( $copia , 0 , $posicionIgual);
      
      
      $resto = substr ( $mutanteOper14 , $posicionIgual );    
      $igual = '=';
      $mayorIgual = '<>';
      //$cambio1 = preg_replace('/+/', '/-/', $resto, 1);
	  $cambio1 = str_replace('=', '>=', $resto);
      
      echo '<br>';
      $mutanteOper14 = $function.$cambio1; 
      if($contador == 0){
		$contador = 1;
	  }
	  else{
	  $contador = $contador + 1;
	  }
///	  echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br>';

///	  echo $mutanteOper14, '<br>';

///	  echo '</span>';

		// Create connection

			$conexion = pg_connect($_SESSION['conexion']);

//Trigger
			$encuentraCreateTrigger = 'CREATE TRIGGER';
            $posicionCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
///            echo '<br>';
            

            $restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
            
           
            $aux3 = explode(" ", $restoCreateTrigger);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			

			
			
			
			
			
			
			
			
//FIN TRIGGER

//FUNCION

			//INICIO
			
			
			//FIN


           
            $encuentraFunction = 'FUNCTION';
            $posicionFunction = strpos($function, $encuentraFunction);

            $restoFunction = substr ( $function , $posicionFunction + 8  );
            
            $nombreFunction = explode(" ", $restoFunction);  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper14);
///			echo '<br>';


//FIN FUNCION





	//INICIO
		$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
		$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE

//COMPROBAMOS SI ESTA EL TRIGGER Y OPERADOR 
 	//echo 'OPERADOR: ', $oper; echo '<br>';
	$consulta = "select * from mutations where idtrigger = '".$triggerid."' and idoperator = '".$oper."'";
	$filasAfectadas = pg_query($consulta);
	$rows = pg_num_rows($filasAfectadas);

	//echo $rows . " row(s) returned.\n"; echo '<br>';
	
	
	
		if($rows == $mutantesConjunto)
		{
			////echo 'ESTE OPERADOR Y ESTE TRIGGER YA SE HA UTILIZADO';
			$existeOper14 = true ;
		}
		else{

	
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change) VALUES ('$nombreTriggerOriginal','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false','Replace + BY /');";
		//$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerMutante','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');";
		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
		
		
		 //TABLA CRISTIAN
$res = pg_query("SELECT nextval('mutations_idmutation_seq') as id");
		$row = pg_fetch_array($res, 0);
		$mutationSecuencia = trim($row["id"]) + 1;
			
		echo '<TR>';
		echo '   <TD style="text-align:center">ARREP</TD>';
		echo '   <TD style="text-align:center">'.$mutationSecuencia.'</TD>';
		echo '	 <TD style="text-align:center">FUNCTION</TD>';
		echo '   <TD>'.$triggerMutanteActualizado.'<br>'.$functionMutante.'</TD>';
		echo '   <TD>Replace = BY >=</TD>';
		echo '</TR>';
//FIN TABLA CRISTIAN
		
		
		}
		
	

		pg_close($conexion);
	
//FIN + --> -

  //aquiiiiiiiiiiii     
    }//FIN DEL ELSE OPER1
 
}


//FIN = POR >=


}//fin si hay algun MAS

?>