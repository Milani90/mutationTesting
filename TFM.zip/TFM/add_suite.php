<?php
session_start(); //Iniciamos o Continuamos la sesion
if (isset($_SESSION['login'])) //Si llego un Nickname via el formulario lo grabamos en la Sesion
{
 
}
else{
	 header('location: login.php');
}




//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
$conexion = pg_connect($_SESSION['conexion']);


	$usuario = $_SESSION['login'];
	//echo 'USUARIO: ', $usuario ;
	
//$acronym = $_POST['id']; 
$description = pg_escape_string($_POST['description']); 

	$_SESSION['description'] = $description;
//echo 'DESCRIPCION: ', $description;
//$owner = $_POST['owner']; 
//$code = $_POST['code']; 
$databasename = pg_escape_string($_POST['databaseName']); 

$_SESSION['databasename'] = $databasename;

//echo 'NOMBRE DE BASE DE DATOS: ', $databasename;


///////$tests = pg_escape_string($_POST['newTest']); 
/////$test = explode(";", $tests);


//saco el numero de elementos
//$longitud = count($test);
 
 
$options =$_POST['options']; 
$milani = '';
$contador = 0;
if($options == 'Add new Test'){
	
	header('location: tests1.php');
}
else {
	echo 'ERROR';
	
	$consulta = "select * from suites where databasename like '$databasename'";
	$sql = pg_query($conexion, $consulta);
	$contador=pg_num_rows($sql);

	//echo 'IDSUITE: ', $milani;
	//echo 'CONSULTA: ', $consulta;
	//$contador = pg_query($consulta);
	//echo 'CONTADOR: ', $contador;
	if($contador > 0){
		//ECHO 'si hay suites';
		header('location: tests2.php');
	}
	else{
		//echo 'nO HAY SUITES';
		header('location: add_new_suite_error.php');
	}
}
 
 
 
 


//$sql = "insert into suites(description,login,databasename) values ('$description','$usuario', '$databasename')";


//Ejecutamos la consulta
//$res = pg_query($sql) or die('La consulta fallo: ' . pg_last_error());
 
//echo "Suite insertada correctamente";
 
//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
//pg_free_result($res);



//Recorro todos los elementos
/*
for($i=0; $i<$longitud-1; $i++)
      {
      //saco el valor de cada elemento	
	  $testInd = $test[$i];
	  $sqlTest = "insert into tests(test,databasename) values ('$testInd', '$databasename')";
	  $resTest = pg_query($sqlTest) or die('La consulta fallo: ' . pg_last_error());
	  pg_free_result($resTest);
}
*/



 
//Cerramos la conexión
//pg_close($conexion);
//header('location: suites.php');





?>