<script type="text/javascript" src="delete_suite.js"></script>
<?php
session_start(); //Iniciamos o Continuamos la sesion


	# conectare la base de datos
    //$con=@mysqli_connect('localhost', 'root', 'root', 'test');
	//$con = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
	$con = pg_connect($_SESSION['conexion']);
    if(!$con){
        die("imposible conectarse: ".pg_error($con));
    }
    if (@pg_last_error()) {
        die("Connect failed: ".pg_last_error()." : ". pg_last_error());
    }
	$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';
	if($action == 'ajax'){
		include 'pagination.php'; //incluir el archivo de paginación
		//las variables de paginación
		$page = (isset($_REQUEST['page']) && !empty($_REQUEST['page']))?$_REQUEST['page']:1;
		$per_page = 14; //la cantidad de registros que desea mostrar
		$adjacents  = 4; //brecha entre páginas después de varios adyacentes
		$offset = ($page - 1) * $per_page;
		//Cuenta el número total de filas de la tabla*/
		$count_query   = pg_query($con,"SELECT count(*) AS numrows FROM suites ");
		if ($reg= pg_fetch_array($count_query)){$numrows = $reg['numrows'];}
		$total_pages = ceil($numrows/$per_page);
		$reload = 'index.php';
		//consulta principal para recuperar los datos  
		
		
		//$query = pg_query($con,"SELECT * FROM triggers order by idtrigger LIMIT $offset,$per_page");
		//$query = pg_query($con,"SELECT * FROM suites order by idsuite OFFSET '$offset' LIMIT '$per_page';");
		$query = pg_query($con,"SELECT * FROM suites order by description OFFSET '$offset' LIMIT '$per_page';");
		
		if ($numrows>0){
			?>
		<table class="table table-bordered">
			  <thead>
				<tr>
				  <tr>
						<th>DESCRIPTION</th>
						<th>OWNER</th>
						<th>DATABASE NAME</th>
						<th>ACTIONS</th>
				</tr>
			</thead>
			<tbody>
			<?php
			while($reg=pg_fetch_array($query)){
				$idsuite= $reg['idsuite'];
				?>
				<tr  style="height: 43px;">
				
					<!--<td width="20%"><a href=""><span id="idsuite < ? php echo $reg['idsuite']; ? >">< ?php echo $reg['idsuite']; ?></span></a></td>-->
					<!--
					<td width="40%"><a href=""><span id="description< ?php echo $reg['idsuite']; ?>">< ?php echo $reg['description']; ?></span></a></td>
					<td width="20%"><a href=""><span id="login< ?php echo $reg['idsuite']; ?>">< ?php echo $reg['login']; ?></span></a></td>
					<td width="20%"><a href=""><span id="login< ?php echo $reg['idsuite']; ?>">< ?php echo $reg['databasename']; ?></span></a></td>
					-->
					
					<td width="50%" style="height: 43px;"><a href="show_suite_read.php?id=<?php echo $reg['idsuite'];  ?>"><span id="description<?php echo $reg['idsuite']; ?>"><?php echo $reg['description']; ?></span></td>
					<td width="20%" style="height: 43px;"><a href="show_suite_read.php?id=<?php echo $reg['idsuite'];  ?>"><span id="login<?php echo $reg['idsuite']; ?>"><?php echo $reg['login']; ?></span></td>
					<td width="20%" style="height: 43px;"><a href="show_suite_read.php?id=<?php echo $reg['idsuite'];  ?>"><span id="databasename<?php echo $reg['idsuite']; ?>"><?php echo $reg['databasename']; ?></span></td>
					<td style="display:none"><a><span type="hidden" id="idsuite<?php echo $reg['idsuite']; ?>"></span></a></td>
					
					

				<?php 

						if($reg['login'] == $_SESSION['login'])
						{
				?>
				<td width="10%" style="height:43px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:12px;">
					<!--<button type="button" class="btn btn-link edit" value="< ?php echo $reg['idsuite']; ?>"><span class="glyphicon glyphicon-edit"></span></button>-->
					<!--
					<a class="btn btn-link edit" data-emp-id="< ?php echo $reg["idsuite"]; ?>" href="edit_suite.php"><i class="glyphicon glyphicon-edit"></i>
					<a class="btn btn-link delete" data-emp-id="< ?php echo $reg["idsuite"]; ?>" href="javascript:void(0)"><i class="glyphicon glyphicon-trash"></i></a>-->
					
					<!--<button type="button" title="View" class="btn btn-link edit"  onclick="showTestSuite(this.value)" value="< ?php echo $reg['idsuite'];   ?>"><span class="glyphicon glyphicon-edit"></span></button>-->
				<!--<button type="button" title="View" class="btn btn-link"  onclick="location.href = show_suite.php" value="<?php echo $reg['idsuite'];   ?>"><span class="glyphicon glyphicon-edit"></span></button>-->
				
					<a class="btn btn-link"  style="padding:1px" title="Edit" data-emp-id="<?php echo $reg["idsuite"]; ?>" href="show_suite.php?id=<?php echo $reg['idsuite'];  ?>"><i class="glyphicon glyphicon-edit"></i></a>
					<a class="btn btn-link delete"  style="padding:1px" title="Delete" data-emp-id="<?php echo $reg["idsuite"]; ?>" data-nombreSuite-id="<?php echo $reg["description"]; ?>"  href="javascript:void(0)"><i class="glyphicon glyphicon-trash"></i></a>
					
				</td>
				<?php
						}
				?>
				<!--
				<td width="20%">
					<button type="button" class="btn btn-link edit" value="<?php echo $reg['idtrigger']; ?>"><span class="glyphicon glyphicon-edit"></span></button>
					<a class="btn btn-link delete" data-emp-id="<?php echo $reg["idtrigger"]; ?>" href="javascript:void(0)"><i class="glyphicon glyphicon-trash"></i>
					</a>
				</td>
				-->

				</tr>
				<?php
			}
			 
			//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
			pg_free_result($query);
			 
			//Cerramos la conexión
			//pg_close($con);
			?>
			</tbody>
		</table>
		<div class="table-pagination pull-right">
			<?php echo paginate($reload, $page, $total_pages, $adjacents);?>
		</div>
		
			<?php
			
		} else {
			?>
			<div class="alert alert-warning alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4>Aviso!!!</h4> No hay datos para mostrar
            </div>
			<?php
		}
	}
?>
