<?php
session_start(); //Iniciamos o Continuamos la sesion
if (isset($_SESSION['login'])) //Si llego un Nickname via el formulario lo grabamos en la Sesion
{
 
}
else{
	 header('location: login.php');
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Manage Triggers</title>
  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:500,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,800,800i" rel="stylesheet">
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/resume.min.css" rel="stylesheet">
  <!-- PROPIOS DE LOS LISTADOS -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!--nnuevos -->

	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/jquery.tablesorter.js"></script>
	
	<script type="text/javascript" src="bootbox.min.js"></script>
<!--<script type="text/javascript" src="delete_trigger.js"></script>-->

<!--PAGINACION -->
<!-- Latest compiled and minified CSS -->
	
<!--fin-->

	
<style type="text/css">
    body {
        color: #566787;
		background: #f5f5f5;
		font-family: 'Varela Round', sans-serif;
		font-size: 13px;
	}
	.table-wrapper {
        background: #fff;
        padding: 20px 25px;
        margin: 30px 0;
		border-radius: 3px;
        box-shadow: 0 1px 1px rgba(0,0,0,.05);
    }
	.table-title {        
		padding-bottom: 15px;
		background: #435d7d;
		color: #fff;
		padding: 16px 30px;
		margin: -20px -25px 10px;
		border-radius: 3px 3px 0 0;
    }
    .table-title h2 {
		margin: 5px 0 0;
		font-size: 24px;
	}
	.table-title .btn-group {
		float: right;
	}
	.table-title .btn {
		color: #fff;
		float: right;
		font-size: 13px;
		border: none;
		min-width: 50px;
		border-radius: 2px;
		border: none;
		outline: none !important;
		margin-left: 10px;
	}
	.table-title .btn i {
		float: left;
		font-size: 21px;
		margin-right: 5px;
	}
	.table-title .btn span {
		float: left;
		margin-top: 2px;
	}
    table.table tr th, table.table tr td {
        border-color: #e9e9e9;
		padding: 12px 15px;
		vertical-align: middle;
    }
	table.table tr th:first-child {
		width: 60px;
	}
	table.table tr th:last-child {
		width: 100px;
	}
    table.table-striped tbody tr:nth-of-type(odd) {
    	background-color: #fcfcfc;
	}
	table.table-striped.table-hover tbody tr:hover {
		background: #f5f5f5;
	}
    table.table th i {
        font-size: 13px;
        margin: 0 5px;
        cursor: pointer;
    }	
    table.table td:last-child i {
		opacity: 0.9;
		font-size: 22px;
        margin: 0 5px;
    }
	table.table td a {
		font-weight: bold;
		color: #566787;
		display: inline-block;
		text-decoration: none;
		outline: none !important;
	}
	table.table td a:hover {
		color: #2196F3;
	}
	table.table td a.edit {
        color: #FFC107;
    }
    table.table td a.delete {
        color: #F44336;
    }
    table.table td i {
        font-size: 19px;
    }
	table.table .avatar {
		border-radius: 50%;
		vertical-align: middle;
		margin-right: 10px;
	}
    .pagination {
        float: right;
        margin: 0 0 5px;
    }
    .pagination li a {
        border: none;
        font-size: 13px;
        min-width: 30px;
        min-height: 30px;
        color: #999;
        margin: 0 2px;
        line-height: 30px;
        border-radius: 2px !important;
        text-align: center;
        padding: 0 6px;
    }
    .pagination li a:hover {
        color: #666;
    }	
    .pagination li.active a, .pagination li.active a.page-link {
        background: #03A9F4;
    }
    .pagination li.active a:hover {        
        background: #0397d6;
    }
	.pagination li.disabled i {
        color: #ccc;
    }
    .pagination li i {
        font-size: 16px;
        padding-top: 6px
    }
    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }    
	/* Custom checkbox */
	.custom-checkbox {
		position: relative;
	}
	.custom-checkbox input[type="checkbox"] {    
		opacity: 0;
		position: absolute;
		margin: 5px 0 0 3px;
		z-index: 9;
	}
	.custom-checkbox label:before{
		width: 18px;
		height: 18px;
	}
	.custom-checkbox label:before {
		content: '';
		margin-right: 10px;
		display: inline-block;
		vertical-align: text-top;
		background: white;
		border: 1px solid #bbb;
		border-radius: 2px;
		box-sizing: border-box;
		z-index: 2;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		content: '';
		position: absolute;
		left: 6px;
		top: 3px;
		width: 6px;
		height: 11px;
		border: solid #000;
		border-width: 0 3px 3px 0;
		transform: inherit;
		z-index: 3;
		transform: rotateZ(45deg);
	}
	.custom-checkbox input[type="checkbox"]:checked + label:before {
		border-color: #03A9F4;
		background: #03A9F4;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		border-color: #fff;
	}
	.custom-checkbox input[type="checkbox"]:disabled + label:before {
		color: #b8b8b8;
		cursor: auto;
		box-shadow: none;
		background: #ddd;
	}
	/* Modal styles */
	.modal .modal-dialog {
		max-width: 900px;
		
	}
	.modal .modal-header, .modal .modal-body, .modal .modal-footer {
		padding: 20px 30px;
	}
	.modal .modal-content {
		border-radius: 3px;
		/*height: 600px;*/
	}
	.modal .modal-footer {
		background: #ecf0f1;
		border-radius: 0 0 3px 3px;
	}
    .modal .modal-title {
        display: inline-block;
    }
	.modal .form-control {
		border-radius: 2px;
		box-shadow: none;
		border-color: #dddddd;
	}
	.modal textarea.form-control {
		resize: vertical;
	}
	.modal .btn {
		border-radius: 2px;
		min-width: 100px;
	}	
	.modal form label {
		font-weight: normal;
	}	
</style>
<script type="text/javascript">
$(document).ready(function(){
	load(1);//PARA LA PAGINACION
	// Activate tooltip
	$('[data-toggle="tooltip"]').tooltip();
	
	// Select/Deselect checkboxes
	var checkbox = $('table tbody input[type="checkbox"]');
	$("#selectAll").click(function(){
		if(this.checked){
			checkbox.each(function(){
				this.checked = true;                        
			});
		} else{
			checkbox.each(function(){
				this.checked = false;                        
			});
		} 
	});
	checkbox.click(function(){
		if(!this.checked){
			$("#selectAll").prop("checked", false);
		}
	});
});

//INICIO FUNCION PAGINACION
	
	/*
	$(document).ready(function(){
		load(1);
	});
*/
	function load(page){
		var parametros = {"action":"ajax","page":page};
		$("#loader").fadeIn('slow');
		$.ajax({
			url:'listado.php',
			data: parametros,
			 beforeSend: function(objeto){
			//$("#loader").html("<img src='loader.gif'>");
			$("#loader").html("");
			},
			success:function(data){
				$(".outer_div").html(data).fadeIn('slow');
				$("#loader").html("");
			}
		})
	}
	
	
	//FIN FUNCION PAGINACION

</script>

<!--ordenar --> 
	<script>
	$(function() {
		$("#simple").tableSorter();
		
		$("#simple-init-sort").tableSorter({
			sortColumn: 'Nombre'	
		});

		$("#styling").tableSorter({
			sortColumn: 'nombre',					
			sortClassAsc: 'headerSortUp', 		
			sortClassDesc: 'headerSortDown',	
			headerClass: 'header' 				
		});
		
		$("#styling-cutom-striping").tableSorter({
			sortColumn: 'nombre',					
			sortClassAsc: 'headerSortUp', 		
			sortClassDesc: 'headerSortDown', 	
			headerClass: 'header', 				
			stripingRowClass: ['even','odd'],	
			stripeRowsOnStartUp: true
		});
		
		$("#styling-cutom-highlighting").tableSorter({
			sortColumn: 'nombre',					
			sortClassAsc: 'headerSortUp',		
			sortClassDesc: 'headerSortDown',	
			highlightClass: 'highlight', 		
			headerClass: 'header'				
			
		});
		
		$("#date-es").tableSorter({
			sortColumn: 'nombre',			
			sortClassAsc: 'headerSortUp',		
			sortClassDesc: 'headerSortDown',	
			headerClass: 'header',			
			dateFormat: 'dd/mm/yyyy' 		
		});
	});
	
	
	
	
	
	
	
	
	</script>
	
  
  <!-- FIN LISTADOS -->
  

</head>

<body id="page-top">

  <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
    <a class="navbar-brand js-scroll-trigger" href="#page-top">
      <span class="d-block d-lg-none">Clarence Taylor</span>
    </a>
	<span class="d-none d-lg-block">
        <img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="img/PL_PgSQL.png" alt="">
      </span>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav">	  
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="triggers.php">Triggers</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="suites.php">Test Suites</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="lista_operadores.php">Mutation Operators</a>
        </li>
		<li class="nav-item">
		<a class="nav-link js-scroll-trigger" href="./listbox/demo/index.php">Mutation Process</a>
        </li>
		<li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="perfil.php">Profile</a>
        </li>
		<li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="logout.php">Logout</a>
        </li>
      </ul>
    </div>
  </nav>





    <div class="container">
        <div class="table-wrapper" style="height: 800px;">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-6">
						<h2>Manage <b>Triggers</b></h2>
					</div>
					<div class="col-sm-6">
						<!--<a href="#addEmployeeModal" class="btn btn-link" data-toggle="modal"><i class="material-icons">&#xE147;</i> <span>Add New Trigger</span></a>-->
						<!--<a href="#deleteEmployeeModal" class="btn btn-danger" data-toggle="modal"><i class="material-icons">&#xE15C;</i> <span>Delete</span></a>						-->
						<a href="./add_new_trigger.php" class="btn btn-link" ><i class="material-icons">&#xE147;</i> <span>Add New Trigger</span></a>
					</div>
                </div>
            </div>
			
			
           <?php
                    
							# conectare la base de datos
    //$con=@mysqli_connect('localhost', 'root', 'root', 'test');
	//$con = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
	$con = pg_connect($_SESSION['conexion']);
    if(!$con){
        die("imposible conectarse: ".pg_error($con));
    }
    if (@pg_last_error()) {
        die("Connect failed: ".pg_last_error()." : ". pg_last_error());
    }
	$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';
	if($action == 'ajax'){
		include 'listado.php'; //incluir el archivo de paginación
		//las variables de paginación
		$page = (isset($_REQUEST['page']) && !empty($_REQUEST['page']))?$_REQUEST['page']:1;
		$per_page = 10; //la cantidad de registros que desea mostrar
		$adjacents  = 4; //brecha entre páginas después de varios adyacentes
		$offset = ($page - 1) * $per_page;
		//Cuenta el número total de filas de la tabla*/
		$count_query   = pg_query($con,"SELECT count(*) AS numrows FROM triggers ");
		if ($reg= pg_fetch_array($count_query)){$numrows = $reg['numrows'];}
		$total_pages = ceil($numrows/$per_page);
		$reload = 'index.php';
		//consulta principal para recuperar los datos  
		
		
		//$query = pg_query($con,"SELECT * FROM triggers order by idtrigger LIMIT $offset,$per_page");
		$query = pg_query($con,"SELECT * FROM triggers order by idtrigger OFFSET '$offset' LIMIT '$per_page';");
		
		if ($numrows>0){
			?>
		<table class="table table-bordered">
			  <thead>
				<tr>
				  <tr>
					<th>TRIGGER NAME</th>
					<th>DESCRIPTION</th>
					<th>ACTIONS</th>
				</tr>
			</thead>
			<tbody>
			<?php
			while($reg = pg_fetch_array($query)){
				?>
							
<!--				//INICIO  -->
				<tr>
									
					<td width="20%" ><a class="btn btn-link view" ><span id="nombre<?php echo $reg['idtrigger']; ?>"><?php echo $reg['name']; ?></span></a></td>
					<td width="65%"><a class="btn btn-link view" ><span id="descripcion<?php echo $reg['idtrigger']; ?>"><?php echo $reg['description']; ?></span></a></td>
					<td width="5%"  style="display:none"><a class="btn btn-link view"><span type="hidden" id="funcion_trigger<?php echo $reg['idtrigger']; ?>"><?php echo $reg['headertrigger']; ?></span></a></td>
					<td width="5%"  style="display:none"><a class="btn btn-link view"><span type="hidden" id="cuerpo_trigger<?php echo $reg['idtrigger']; ?>"><?php echo $reg['bodytrigger']; ?></span></a></td>

					<?php 
						if($reg['login'] == $_SESSION['login'])
						{
					?>
					<td width="5%">
						<!--<button type="button" class="btn btn-link edit" value="< ?php echo $reg['idtrigger']; ?>"><span class="glyphicon glyphicon-edit"></span></button>-->
						<!--<button type="button" class="btn btn-link delete" value="< ?php echo $reg['idtrigger']; ?>"><span class="glyphicon glyphicon-trash"></span></button>-->
						<!--<a class="btn btn-link delete" data-emp-id="< ?php echo $reg["idtrigger"]; ?>" href="javascript:void(0)"><i class="glyphicon glyphicon-trash"></i></a>-->
						
							
						
						<!--<button type="button" class="btn btn-danger delete" value="< ?php echo $reg['idtrigger']; ?>"> <span class="glyphicon glyphicon-remove"></span> Delete</button>-->
						<!--<a class="btn btn-link delete" data-emp-id="< ?php echo $reg["idtrigger"]; ?>" href="javascript:void(0)"><i class="glyphicon glyphicon-trash"></i>-->
				
						
					</td>
					<?php
						}
					?>
				</tr>
<!--				//FIN-->
				

				<?php
			}
				//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
				pg_free_result($query);
				 
				//Cerramos la conexión
				pg_close($con);
			?>
			</tbody>
		</table>
		<div class="table-pagination pull-right">
			<?php echo paginate($reload, $page, $total_pages, $adjacents);?>
		</div>
		
			<?php
			
		} else {
			?>
			<div class="alert alert-warning alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4>Aviso!!!</h4> No hay datos para mostrar
            </div>
			<?php
		}
	}
								
							?>	
							
		<div class="col-xs-12">
		<div id="loader" class="text-center"> <!--<img src="loader.gif">--></div>
		<div class="outer_div"></div><!-- Datos ajax Final -->
		</div>
	  
			
			
			<!--
			<div class="clearfix">
                <div class="hint-text">Showing <b>1</b> out of <b>1</b> entries</div>
                <ul class="pagination">
                    <li class="page-item disabled"><a href="#">Previous</a></li>
                    <li class="page-item"><a href="#" class="page-link">1</a></li>
                    <li class="page-item"><a href="#" class="page-link">Next</a></li>
                </ul>
            </div>
			-->
			</div>
			
        
		<!--< ?php include('edit_trigger_modal.php'); ?>-->
		<script src="edit_trigger.js"></script>  
		<script src="view_trigger.js"></script>  
		<!--<script src="update_trigger_modal.js"></script>-->
		
    </div>
	<!-- Add Modal HTML -->
	<div id="addEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content" style="width: 860px;   ">
				<form action="add_trigger.php" method="post">
					<div class="modal-header">						
						<h4 class="modal-title">Add Trigger</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">					
						<div class="form-group">
							<label>TRIGGER NAME</label>
							<input type="text" class="form-control" name="triggerName" required>
						</div>
						<div class="form-group">
							<label>DESCRIPTION</label>
							<input type="text" class="form-control" name="description" required>
						</div>
						<div class="form-group">
							<label>TRIGGER HEADER</label>
							<textarea class="form-control" rows="4" name="triggerHeader" required></textarea>
						</div>
						<div class="form-group">
							<label>TRIGGER FUNCTION</label>
							<textarea type="text" class="form-control" rows="10" name="triggerFunction" required></textarea>
						</div>	
						<div class="form-group">
							<label for="databaseName">DATABASE</label>
							<br>
<!--	
						<select id="database">
							  <option value="" selected>-Select-</option>
							  
							</select>
-->
							
							    <select id="databaseName" name="databaseName" title="databaseName" required>
									<option value="" selected>-Select-</option>
									<?php

								//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
								$conexion = pg_connect($_SESSION['conexion']);
								
								
								

								//$sql = 'SELECT distinct(databasename) FROM triggers where databasename is not null';
								$sql = "SELECT datname FROM pg_database where datname not like 'template0' and datname not like 'template1';";
								 
								//Ejecutamos la consulta
								$res = pg_query($sql) or die('La consulta fallo: ' . pg_last_error());
								 
								//Recorremos el array asociativo con los datos
								while ($reg = pg_fetch_array($res, null, PGSQL_ASSOC)) {
									//echo '<option value="'.$reg['databasename'].'">'.$reg['databasename'].'</option>';
									echo '<option value="'.$reg['datname'].'">'.$reg['datname'].'</option>';
									//echo '<option value="'.$valores[id].'">'.$valores[paises].'</option>';
									//echo $reg['idoper'] . ' ' . $reg['nombre'] . '<br />';
								}
								 
								//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
								pg_free_result($res);
								 
								//Cerramos la conexión
								pg_close($c);
								?>

								</select>






						</div>						
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<input type="submit" class="btn btn-success" value="Add">
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Edit Modal HTML -->
	<div id="edit" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content" style="width:1000px;    margin-left: -20%;">
				<form action="edit_trigger.php" method="POST">
					<div class="modal-header">						
						<h4 class="modal-title">Edit Trigger</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					
									<div class="modal-body">
									<div class="form-group">
										<label>TRIGGER NAME</label>
										<!-- $nombre = isset($reg[0]) ? $reg[0] : null ;-->
										<input type="text" class="form-control" name="enombre" id="enombre">
										 
									</div>
									
									<div class="form-group">
										<label>DESCRIPTION</label>
										<!--$descripcion = isset($reg[1]) ? $reg[1] : null ;									-->
										<input type="text" class="form-control" name="edescripcion" id="edescripcion">
										
										
									</div>
									<div class="form-group">
										<label>TRIGGER HEADER</label>
											<!--$cuerpo_trigger = isset($reg[2]) ? $reg[2] : null ;									-->
										<textarea class="form-control"  rows="10" name="ecuerpo_trigger" id="ecuerpo_trigger"></textarea>

									</div>
									<div class="form-group">
									<label>TRIGGER FUNCTION</label>
											<!--$funcion_trigger = isset($reg[3]) ? $reg[3] : null ;-->
									<textarea class="form-control" name="efuncion_trigger" id="efuncion_trigger" ></textarea>
									
									</div>
									<div class="form-group">
									<!--$idtrigger = isset($reg[4]) ? $reg[4] : null ; -->
									<input type="hidden" class="form-control" name="eidtrigger" id="eidtrigger"> 

									</div>						
								</div>
								<div class="modal-footer">
								<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">				
									<input type="submit" id="update" class="btn btn-info" value="Save">
								</div>	
									
								
								
					
				</form>
			</div>
		</div>
	</div>
	
	<!-- Fin Edit Modal HTML -->
	<!-- ver trigger -->
	<!--
	<div id="view" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form action="view_trigger.php" method="POST">
					<div class="modal-header">						
						<h4 class="modal-title">View Trigger222</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					
								<div class="modal-body">
									<div class="form-group">
										<label>TRIGGER NAME</label>
										
										<input type="text" class="form-control" name="vnombre" id="vnombre" readonly>
										 
									</div>
									
									<div class="form-group">
										<label>DESCRIPTION</label>
										
										<input type="text" class="form-control" name="vdescripcion" id="vdescripcion" readonly>
										
										
									</div>
									<div class="form-group">
										<label>TRIGGER HEADER</label>
										
										<textarea class="form-control"  rows="10" name="vcuerpo_trigger" id="vcuerpo_trigger" readonly></textarea>

									</div>
									<div class="form-group">
									<label>TRIGGER FUNCTION</label>
										
									<textarea class="form-control" name="vfuncion_trigger" id="vfuncion_trigger" readonly></textarea>
									
									</div>
									<div class="form-group">
									
									<input type="hidden" class="form-control" name="vidtrigger" id="vidtrigger" readonly> 

									</div>						
								</div>
								
									
								
								
					
				</form>
			</div>
		</div>
	</div>
	-->
	
	
	
	
	<!-- fin ver trigger -->
	
	<!--REVISAR OPCIONAL-->
	<?php include('edit_trigger_modal.php'); ?>
	
	<?php include('view_trigger_modal.php'); ?>

	<!-- Delete Modal HTML -->
	<div id="deleteEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form>
					<div class="modal-header">						
						<h4 class="modal-title">Delete Trigger</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">					
						<p>Are you sure you want to delete these Records?</p>
						<p class="text-warning"><small>This action cannot be undone.</small></p>
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<input type="submit" class="btn btn-danger" value="Delete">
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>                                		                            