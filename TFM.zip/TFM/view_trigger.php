<?php
	session_start();
	//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
	$conexion = pg_connect($_SESSION['conexion']);
	
	




	//Recuperamos el id modificado al hacer click 

/*
	$nombre=$_POST['nombre'];
	$descripcion=$_POST['descripcion'];
	$cuerpo_trigger = $_POST['cuerpo_trigger'];
	$funcion_trigger= $_POST['funcion_trigger'];

	$idtrigger =$_POST['idtrigger'];

*/
	$nombre=$_POST['vnombre'];
	
	$descripcion=$_POST['vdescripcion'];
	$cuerpo_trigger = $_POST['vcuerpo_trigger'];
	$funcion_trigger= $_POST['vfuncion_trigger'];

	$idtrigger =$_POST['vidtrigger'];



	//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
	//pg_free_result($res);

	//$sql = "update triggers set nombre='$nombre', descripcion='$descripcion', cuerpo_trigger='$cuerpo_trigger', funcion_trigger='$funcion_trigger' where idtrigger='$idtrigger'" ;
	//$sql = "update triggers set name='$nombre', description='$descripcion', headertrigger='$cuerpo_trigger', bodytrigger='$funcion_trigger' where idtrigger='$idtrigger'" ;


	//Ejecutamos la consulta
//	$res = pg_query($sql) or die('La consulta fallo: ' . pg_last_error());

//	echo "Registro actualizado correctamente";


	//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
//	pg_free_result($sql);
	 
	//Cerramos la conexión
//	pg_close($conexion);

	header('Location: triggers.php');
?>