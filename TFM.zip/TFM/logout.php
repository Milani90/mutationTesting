<?php 

// Terminar la sesión:
session_destroy();

header('location: login.php');

?>