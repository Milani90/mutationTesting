<?php 
session_start(); 

			$host = $_SESSION['host'];
			$port = $_SESSION['port'];
			$dbname = "dbname=" .$_SESSION['databaseElegida'];
			$user = $_SESSION['user'];
			$password = $_SESSION['passConf'];
			//$confConexion = $host ." ". $port ." ". $dbname ." " .$user ." ". $password;
			$confConexion =	"host=127.0.0.1 port=5432 dbname=bdpruebas user=postgres password=root";

			//HACEMOS EL BACKUP ANTES DE EJECUTAR LOS TRIGGERS
			
			
$conexionMutante = pg_connect($confConexion);
//$casoTest = "insert into execution_tests(idmutacion, idtest, veredicto) values ('50000', '900', true)";
 $casoTest = "insert into employees values (8, 'Angel', 'Lopez', 2000)";
$exectest=pg_query($conexionMutante, $casoTest);
if (!$exectest) {
	echo 'EEROR';
}
ELSE{
	ECHO 'insertado ok';
}


?>