
<?php

	$host = "host=127.0.0.1 ";
	$_SESSION['host'] = $host;
	$port = "port=5432 ";
	$_SESSION['port'] =	$port;
	$dbname = "dbname=tfm ";
	$_SESSION['dbname'] = $dbname;
	$user = " user=postgres ";
	$_SESSION['user'] = $user;
	$password = "password=root";
	$_SESSION['passConf'] = $password;
	$confConexion = $host . $port . $dbname .$user . $password;
	$_SESSION['conexion'] = $confConexion;
	

	$con = pg_connect($confConexion);
	
	// Check connection
	if (!$con) {
		die("Connection failed: " . pg_last_error());
	} 
	echo "Connected successfully";

	
?>