<?php
session_start();

 $host = "host=127.0.0.1 ";
$port = "port=5432 ";
$dbname = "dbname=pruebas " ;
$user = " user=postgres ";
$password = "password=root";
$confConexion = $host . $port . $dbname .$user . $password;
			$conexionTest =	pg_connect($confConexion);		
			$tablas = pg_query("select tablename as table from   pg_tables  where schemaname = 'public';");
			$numTablas = pg_num_rows($tablas);
			
			echo 'NUMERO DE TABLAS: ', $numTablas;
			$existeBackup = false;
			echo '<br>';	
			while ($listaTablas = pg_fetch_array($tablas, null, PGSQL_ASSOC)) {
				$nombreTabla = $listaTablas['table'];
				echo 'TABLA1: ', $listaTablas['table'];
				
				//Comprobamos si es la primera vez que hacemos el proceso y no hay tablas de backup
				if (strpos($nombreTabla, 'backup_') !== false) {
					echo ' - si hay backup';
					//pg_query("create table if not exists backup_".$nombreTabla." as (select * from ".$nombreTabla.");");
					$existeBackup = true;
					
				}
				//pg_query("create table if not exists backup_".$nombreTabla." as (select * from ".$nombreTabla.");");
				echo '<br>';
			}
			pg_close($conexionTest);
			echo '<br>';echo '<br>';echo '<br>';
			$conexionTest =	pg_connect($confConexion);
			if($existeBackup == true){
				echo 'YA SE HA HECHO BACKUP';
			}
			else{
				while ($listaTablas = pg_fetch_array($tablas, null, PGSQL_ASSOC)) {
				$nombreTabla = $listaTablas['table'];
				echo 'TABLA2: ', $listaTablas['table'];
				
				pg_query("create table if not exists backup_".$nombreTabla." as (select * from ".$nombreTabla.");");
				echo '<br>';
				}
			}
			pg_close($conexionTest);
?>