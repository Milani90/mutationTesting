<?php
session_start(); //Iniciamos o Continuamos la sesion
if (isset($_SESSION['login'])) //Si llego un Nickname via el formulario lo grabamos en la Sesion
{
 
}
else{
	 header('location: login.php');
}


  //Activamos todas las notificaciones de error posibles
  error_reporting (E_ALL);

  //Definimos el tratamiento de errores no controlados
  set_error_handler(function () 
  {
    throw new Exception("Error");
  });
   function LogDeErrores($numeroDeError, $descripcion, $fichero, $linea, $contexto){
	  echo '<br>';
   error_log("Error: [".$numeroDeError."] ".$descripcion." ".$fichero." ".$linea." ".json_encode($contexto)." \n\r", 3, "log_errores.txt");
  $errorSuite = explode ("ERROR:", $descripcion);
   //$_SESSION['descripcionErrorSuite'] = $errorSuite[1];
       $_SESSION['descripcionErrorAddNewTestsSuite'] = isset($errorSuite[1]) ? $errorSuite[1] : null ; 
	 //  echo $_SESSION['descripcionErrorSuite'];
  throw new Exception("Error");
  }
  set_error_handler("LogDeErrores");




try{
	
	//echo 'ERROR: ',$_SESSION['descripcionErrorSuite'];
//$host = "host=127.0.0.1 ";
$host = $_SESSION['host'];
//$port = "port=5432 ";
$port = $_SESSION['port'];
$dbname = "dbname=" . $_POST['databaseName'];
//$user = " user=postgres ";
$user = $_SESSION['user'];
//$password = "password=root";
$password = $_SESSION['passConf'];
$confConexion = $host ." ". $port ." ". $dbname ." ". $user ." ". $password;
//echo $confConexion;

$con = pg_connect($confConexion);

$testValidos = false;
$_SESSION['description'] = pg_escape_string($_POST['description']); 
$_SESSION['databaseName'] = pg_escape_string($_POST['databaseName']); 

$_SESSION['newTestAddAll'] = $_POST['newTestAdd'];



//$test = explode(";", $tests);
$test = explode(";", $_POST['newTestAdd']);


//saco el numero de elementos
$longitud = count($test);

$_SESSION['longitud'] = $longitud;

if($longitud < 2) 
{	
	try{
	
	$_SESSION["newTestAdd"] = $_POST['newTestAdd'];
	
	
	$contador = substr_count($_POST['newTestAdd'],";");
	
	
	
	if($contador == 0){
		$unico = $_POST['newTestAdd'].";";
		//$_SESSION['milani'] = $unico;
		$_SESSION['newTestAdd'] = $unico;
		
		
	}
	else{
		$unico = $_POST['newTestAdd'];
		//$_SESSION['milani2'] = $unico;
	
	
		
	}
	
	
	//$unico = pg_escape_string($unico); 
	//$unico = "'.$unico.'"; 
	//$unico = str_replace('\"','\'', $unico);
	//$unico = str_replace('\'','\'', $unico);
	
	$_SESSION["newTestAdd"] = $unico;
	
	pg_query("BEGIN");
	   pg_query($unico);
	pg_query("ROLLBACK;"); 
	   //ECHO 'el test ejecutado es: ', $unico;
	   //echo 'METE MAS TEST';
	   $testValidos = true;
	}
	
	catch(Exception $e){
		$testValidos = false;
		echo "catched: " . PHP_EOL;
		header('Location: error_add_new_tests.php');
	}
}
else{
	
	try{

	
	pg_query("BEGIN");

	//Recorro todos los elementos
	for($i=0; $i<$longitud-1; $i++)
	{
		
		echo 'TEST: ', $test[$i];
		echo '<br>';
		  //saco el valor de cada elemento	
		  $testInd = $test[$i];
		  
		//$_SESSION["test"] = $test[$i];
	
			//$testInd = pg_escape_string($testInd); 
			
			$_SESSION["newTestAdd"] = $testInd.'<br>';
			echo $_SESSION["newTestAdd"];
			//$testInd = str_replace('\"','\'', $testInd);
			//$testInd = str_replace('\'','\'', $testInd);

		   pg_query($testInd);
		   //pg_query("'.$testInd.'");
		   
	}
	$testValidos = true;
		}
		  catch(Exception $e){
			  $testValidos = false;
			  //mostramos el texto del error al usuario	  
			echo "Error al crear la suite." . PHP_EOL;
			echo "Revise el código." . PHP_EOL;
	
			  header('Location: error_add_new_tests.php');
		  }
		 
		  

	
	pg_query("ROLLBACK;");

}
	
	
	//$testValidos = true;
	//Cerramos la conexión
	pg_close($con);
	
if($testValidos){
	//echo "TODO OK";
	header('location: parte2_add_new_tests_suite.php');
}
/*
else
{
	header('location: error_suite.php');
}
*/
	
	
}
 catch(Exception $e) //capturamos un posible error
 {
	  //pg_query("ROLLBACK TO SAVEPOINT inicio;");
    //mostramos el texto del error al usuario	
	
    echo "El test: ".$_SESSION["newTestAdd"]. " introducido es erroneo." . PHP_EOL;
	echo '<br>';
	//die('El test es erroneo, revisalo: ' . $php_errormsg);
	  //mostramos el texto del error al usuario	  
    echo "Error al insertar el trigger." . PHP_EOL;
	echo "Revise el código." . PHP_EOL;
	
	//header('Location: error_add_tests.php');
	header('Location: error_add_new_tests.php');
  }

  //Restablecemos el tratamiento de errores
  restore_error_handler();
    









?>