	<?php
session_start(); //Iniciamos o Continuamos la sesion
if (isset($_POST['login'])) //Si llego un Nickname via el formulario lo grabamos en la Sesion
{
	$_SESSION['login'] = $_POST['login']; 
}
if ($_SESSION['login']) //Si hay un nickname en la sesion actual, creamos una variable que será mostrada
{
	
	
}


try{
$host = "host=127.0.0.1 ";
$port = "port=5432 ";
//$dbname = "dbname=" . $_POST['databaseName'];
$dbname = "dbname=pruebas";
$user = " user=postgres ";
$password = "password=root";
$confConexion = $host . $port . $dbname .$user . $password;
echo $confConexion;

$conexion = pg_connect($confConexion);

$testValidos = false;


//$tests = pg_escape_string($_POST['newTest']); 
//$tests = str_replace('"','\'', $tests);
//$test = explode(";", $tests);


//saco el numero de elementos
//$longitud = count($test);
 
//insert into employees values (1,'yo');
//insert into employees values (2,'tu');
//insert into employees values (3,'el');

	$sql = "insert into employees values (1,"yo");";
		  $resTest = pg_query($sql);
			pg_free_result($resTest);
			$testValidos = true;
		  
	
}
 catch(Exception $e) //capturamos un posible error
  {
    //mostramos el texto del error al usuario	  
    echo "El test introducido es erroneo." . PHP_EOL;
	//die('El test es erroneo, revisalo: ' . $php_errormsg);
    
	
	//header('Location: error.php');
  }



/*

if($testValidos = true){




$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");

	$usuario = $_SESSION['login'];
	//echo 'USUARIO: ', $usuario ;
	
//$acronym = $_POST['id']; 
$description = pg_escape_string($_POST['description']); 

  $description = $_SESSION['description'];

$databasename = pg_escape_string($_POST['databaseName']); 

$databasename = $_SESSION['databasename'] ;
//echo 'NOMBRE DE BASE DE DATOS: ', $databasename;


$tests = pg_escape_string($_POST['newTest']); 
$test = explode(";", $tests);


//saco el numero de elementos
$longitud = count($test);


$sql = "insert into suites(description,login,databasename) values ('$description','$usuario', '$databasename')";


//Ejecutamos la consulta
$res = pg_query($sql) or die('La consulta fallo: ' . pg_last_error());
 
//echo "Suite insertada correctamente";
 
//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
pg_free_result($res);



//Recorro todos los elementos
for($i=0; $i<$longitud-1; $i++)
      {
      //saco el valor de cada elemento	
	  $testInd = $test[$i];
	  $sqlTest = "insert into tests(test,databasename) values ('$testInd', '$databasename')";
	  $resTest = pg_query($sqlTest) or die('La consulta fallo: ' . pg_last_error());
	  pg_free_result($resTest);
	  
	  //TABLA TEST_SUITES
	  //$sqlTestSuites = "insert into test_suites(idsuite, idtest) values ('$testInd', '$databasename')";
	  
	  
}




 
//Cerramos la conexión
pg_close($conexion);
header('location: suites.php');
}
*/




?>