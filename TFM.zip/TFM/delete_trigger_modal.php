<?php
session_start(); //Iniciamos o Continuamos la sesion
//include_once("db_connect.php");
//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
$conexion = pg_connect($_SESSION['conexion']);

if($_REQUEST['triggerid']) {
	/*
	$sql = "DELETE FROM triggers WHERE idtrigger='".$_REQUEST['triggerid']."'";
	$resultset = pg_query($conexion, $sql) or die("database error:". pg_last_error($conexion));	
	if($resultset) {
		echo "Record Deleted";
	}
	
	pg_close($conexion);
	$conexion = pg_connect($_SESSION['conexion']);
	*/
	$consultaFuncion = "select * from triggers where idtrigger = '".$_REQUEST['triggerid']."'";
	//$consulta = pg_query($conexion, $consultaFuncion);

	$res = pg_query($conexion, $consultaFuncion);							 
	//Recorremos el array asociativo con los datos
	while ($reg = pg_fetch_array($res, null, PGSQL_ASSOC)) {
		$cuerpoFuncion = $reg['bodytrigger'];
		$databasename = $reg['databasename'];
	}


	$nombreFuncion = explode(" ", $cuerpoFuncion);
	//echo 'NOMBRE FUNCION: ', $nombreFuncion[2];
	
	$puntoNomFunc = substr_count($nombreFuncion[2],".");
	
	
	//CONSULTA DE BORRADO
	$sql = "DELETE FROM triggers WHERE idtrigger='".$_REQUEST['triggerid']."'";
	$resultset = pg_query($conexion, $sql) or die("database error:". pg_last_error($conexion));	
	if($resultset) {
		echo "Record Deleted";
	}
	//FIN CONSULTA DE BORRADO
	
	
	
	
	
	
	
	
	if($puntoNomFunc > 0)
	{
		$soloNombreFun = explode(".", $nombreFuncion[2]);
		$nomFuncion = $soloNombreFun[1];
	}
	else{
		$nomFuncion = $nombreFuncion[2];
	}
	
	pg_close($conexion);
	
	/*
	$host = "host=127.0.0.1 ";
	$port = "port=5432 ";
	$dbname = "dbname=" . $databasename;
	$user = " user=postgres ";
	$password = "password=root";
	$confConexion = $host . $port . $dbname .$user . $password;
	//echo 'CONEXION: ', $confConexion;
	
	 $conexion2 = pg_connect($confConexion);
            
	
	//$eliminaFunction = "DROP FUNCTION price_audit() CASCADE;";
	$eliminaFunction = "DROP FUNCTION $nomFuncion CASCADE;";
		
	//$eliminaFunction = "DROP FUNCTION ".$nombreFuncion[2]." CASCADE;";
	//$con = pg_query($confConexion, $eliminaFunction);
	pg_query($conexion2,$eliminaFunction);
	*/
	

}
?>
