--
-- PostgreSQL database dump
--

-- Dumped from database version 10.11
-- Dumped by pg_dump version 10.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: insert_triggergenerico_1(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_triggergenerico_1() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
IF extract(year FROM OLD.day) = 2018 THEN
EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;
END IF;

RETURN NULL;
END;
$_$;


ALTER FUNCTION public.insert_triggergenerico_1() OWNER TO postgres;

--
-- Name: nombrefuncioncristian(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.nombrefuncioncristian() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE 'INSERT INTO stock_2018_t' || date_part('quarter', OLD.day) || ' VALUES ($1.*)' USING NEW;
END IF;

RETURN NULL;
END;
$_$;


ALTER FUNCTION public.nombrefuncioncristian() OWNER TO postgres;

--
-- Name: price_audit66(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.price_audit66() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);
      RETURN NEW;
   END;
$$;


ALTER FUNCTION public.price_audit66() OWNER TO postgres;

--
-- Name: stock_insert_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.stock_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE 'INSERT INTO stock_2018_t' || date_part('quarter', NEW.day) || 'VALUES ($1.*)' USING NEW;
END IF;

RETURN NULL;
END;
$_$;


ALTER FUNCTION public.stock_insert_trigger() OWNER TO postgres;

--
-- Name: stock_insert_trigger454(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.stock_insert_trigger454() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
IF extract(year FROM NEW.day) = 2018 THEN
EXECUTE 'INSERT INTO stock_2018_t' || date_part('quarter', NEW.day) || 'VALUES ($1.*)' USING NEW;
END IF;

RETURN NULL;
END;
$_$;


ALTER FUNCTION public.stock_insert_trigger454() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: execution_tests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.execution_tests (
    idmutacion integer NOT NULL,
    idtest integer NOT NULL,
    veredicto boolean NOT NULL
);


ALTER TABLE public.execution_tests OWNER TO postgres;

--
-- Name: mutations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mutations (
    idmutation integer NOT NULL,
    triggername character varying(30),
    functionname character varying(30),
    triggerbody text,
    functionbody text,
    login character varying(30),
    idtrigger integer,
    idoperator integer,
    equivalent boolean
);


ALTER TABLE public.mutations OWNER TO postgres;

--
-- Name: mutations_idmutation_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mutations_idmutation_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mutations_idmutation_seq OWNER TO postgres;

--
-- Name: mutations_idmutation_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mutations_idmutation_seq OWNED BY public.mutations.idmutation;


--
-- Name: operators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.operators (
    idoper integer NOT NULL,
    name character varying(5) NOT NULL,
    description text NOT NULL,
    code text NOT NULL,
    owner character varying(30) NOT NULL
);


ALTER TABLE public.operators OWNER TO postgres;

--
-- Name: operators_idoper_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.operators_idoper_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.operators_idoper_seq OWNER TO postgres;

--
-- Name: operators_idoper_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.operators_idoper_seq OWNED BY public.operators.idoper;


--
-- Name: suites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suites (
    idsuite integer NOT NULL,
    description character varying(250) NOT NULL,
    login character varying(30) NOT NULL,
    databasename character varying(20) NOT NULL
);


ALTER TABLE public.suites OWNER TO postgres;

--
-- Name: suites_idsuite_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.suites_idsuite_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.suites_idsuite_seq OWNER TO postgres;

--
-- Name: suites_idsuite_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.suites_idsuite_seq OWNED BY public.suites.idsuite;


--
-- Name: test_suites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_suites (
    idsuite integer NOT NULL,
    idtest integer NOT NULL
);


ALTER TABLE public.test_suites OWNER TO postgres;

--
-- Name: tests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tests (
    idtest integer NOT NULL,
    test character varying(500) NOT NULL,
    databasename character varying(20) NOT NULL
);


ALTER TABLE public.tests OWNER TO postgres;

--
-- Name: tests_idtest_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tests_idtest_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tests_idtest_seq OWNER TO postgres;

--
-- Name: tests_idtest_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tests_idtest_seq OWNED BY public.tests.idtest;


--
-- Name: triggers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.triggers (
    idtrigger integer NOT NULL,
    name character varying(30) NOT NULL,
    headertrigger text NOT NULL,
    bodytrigger text NOT NULL,
    login character varying(30) NOT NULL,
    databasename character varying(20) NOT NULL,
    description character varying(250) NOT NULL
);


ALTER TABLE public.triggers OWNER TO postgres;

--
-- Name: triggers_idtrigger_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.triggers_idtrigger_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.triggers_idtrigger_seq OWNER TO postgres;

--
-- Name: triggers_idtrigger_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.triggers_idtrigger_seq OWNED BY public.triggers.idtrigger;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    login character varying(30) NOT NULL,
    password character varying(30) NOT NULL,
    compartirinfo boolean
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: mutations idmutation; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mutations ALTER COLUMN idmutation SET DEFAULT nextval('public.mutations_idmutation_seq'::regclass);


--
-- Name: operators idoper; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operators ALTER COLUMN idoper SET DEFAULT nextval('public.operators_idoper_seq'::regclass);


--
-- Name: suites idsuite; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suites ALTER COLUMN idsuite SET DEFAULT nextval('public.suites_idsuite_seq'::regclass);


--
-- Name: tests idtest; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tests ALTER COLUMN idtest SET DEFAULT nextval('public.tests_idtest_seq'::regclass);


--
-- Name: triggers idtrigger; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.triggers ALTER COLUMN idtrigger SET DEFAULT nextval('public.triggers_idtrigger_seq'::regclass);


--
-- Data for Name: execution_tests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.execution_tests (idmutacion, idtest, veredicto) FROM stdin;
--\.


--
-- Data for Name: mutations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mutations (idmutation, triggername, functionname, triggerbody, functionbody, login, idtrigger, idoperator, equivalent) FROM stdin;
2005	nombreTriggerRow	nombreFuncionRow_1()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_1();	CREATE FUNCTION nombreFuncionRow_1() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM OLD.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2009	nombreTriggerRow	nombreFuncionRow_2()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_2();	CREATE FUNCTION nombreFuncionRow_2() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2013	nombreTriggerRow	nombreFuncionRow_3()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_3();	CREATE FUNCTION nombreFuncionRow_3() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING OLD;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2017	nombreTriggerRow	nombreFuncionRow_1()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_1();	CREATE FUNCTION nombreFuncionRow_1() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM OLD.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2021	nombreTriggerRow	nombreFuncionRow_2()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_2();	CREATE FUNCTION nombreFuncionRow_2() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2025	nombreTriggerRow	nombreFuncionCristian_3()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_3();	CREATE FUNCTION nombreFuncionCristian_3() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	58	1	f
2028	nombreTriggerRow	nombreFuncionCristian_3()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_3();	CREATE FUNCTION nombreFuncionCristian_3() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	58	1	f
2032	trigg_insert_milani	stock_milani_1()	CREATE TRIGGER trigg_insert_milani BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_milani_1();	CREATE FUNCTION stock_milani_1() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM OLD.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2019_t"  || " VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	milani1991@hotmail.com	59	1	f
2036	nombreTriggerRow	nombreFuncionCristian_2()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_2();	CREATE FUNCTION nombreFuncionCristian_2() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING OLD;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	58	1	f
2006	nombreTriggerRow	nombreFuncionRow_2()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_2();	CREATE FUNCTION nombreFuncionRow_2() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2010	nombreTriggerRow	nombreFuncionRow_3()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_3();	CREATE FUNCTION nombreFuncionRow_3() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING OLD;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2014	nombreTriggerRow	nombreFuncionRow_1()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_1();	CREATE FUNCTION nombreFuncionRow_1() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM OLD.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2018	nombreTriggerRow	nombreFuncionRow_2()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_2();	CREATE FUNCTION nombreFuncionRow_2() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2022	nombreTriggerRow	nombreFuncionRow_3()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_3();	CREATE FUNCTION nombreFuncionRow_3() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING OLD;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2029	nombreTriggerRow	nombreFuncionCristian_1()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_1();	CREATE FUNCTION nombreFuncionCristian_1() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM OLD.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	58	1	f
2033	trigg_insert_milani	stock_milani_2()	CREATE TRIGGER trigg_insert_milani BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_milani_2();	CREATE FUNCTION stock_milani_2() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2019_t"  || " VALUES ($1.*)" USING OLD;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	milani1991@hotmail.com	59	1	f
2037	nombreTriggerRow	nombreFuncionCristian_3()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_3();	CREATE FUNCTION nombreFuncionCristian_3() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	58	1	f
2007	nombreTriggerRow	nombreFuncionRow_3()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_3();	CREATE FUNCTION nombreFuncionRow_3() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING OLD;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2011	nombreTriggerRow	nombreFuncionRow_1()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_1();	CREATE FUNCTION nombreFuncionRow_1() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM OLD.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2015	nombreTriggerRow	nombreFuncionRow_2()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_2();	CREATE FUNCTION nombreFuncionRow_2() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2019	nombreTriggerRow	nombreFuncionRow_3()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_3();	CREATE FUNCTION nombreFuncionRow_3() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING OLD;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2023	nombreTriggerRow	nombreFuncionCristian_1()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_1();	CREATE FUNCTION nombreFuncionCristian_1() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM OLD.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	58	1	f
2026	nombreTriggerRow	nombreFuncionCristian_1()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_1();	CREATE FUNCTION nombreFuncionCristian_1() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM OLD.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	58	1	f
2030	nombreTriggerRow	nombreFuncionCristian_2()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_2();	CREATE FUNCTION nombreFuncionCristian_2() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING OLD;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	58	1	f
2034	trigg_insert_milani	stock_milani_5()	CREATE TRIGGER trigg_insert_milani BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_milani_5();	CREATE FUNCTION stock_milani_5() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT OR DELETE INTO stock_2019_t"  || " VALUES ($1.*)" USING 	milani1991@hotmail.com	59	4	f
2038	price_trigger\r\n	public.price_audit()_1()	CREATE TRIGGER price_trigger\r\n    AFTER INSERT OR UPDATE\r\n    ON public.employees\r\n    FOR EACH ROW\r\n    EXECUTE PROCEDURE public.price_audit();\r\n	CREATE FUNCTION public.price_audit()_1()    RETURNS trigger\r\n    LANGUAGE "plpgsql"\r\nAS $BODY$\r\n   BEGIN\r\n      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);\r\n      RETURN OLD;\r\n   END;\r\n$BODY$;	cristian@hotmail.com	92	1	f
2039	price_trigger\r\n	public.price_audit()_1()	CREATE TRIGGER price_trigger\r\n    AFTER INSERT OR UPDATE\r\n    ON public.employees\r\n    FOR EACH ROW\r\n    EXECUTE PROCEDURE public.price_audit();	CREATE FUNCTION public.price_audit()_1()    RETURNS trigger\r\n    LANGUAGE "plpgsql"\r\nAS $BODY$\r\n   BEGIN\r\n      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);\r\n      RETURN OLD;\r\n   END;\r\n$BODY$;	cristian@hotmail.com	95	1	f
2008	nombreTriggerRow	nombreFuncionRow_1()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_1();	CREATE FUNCTION nombreFuncionRow_1() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM OLD.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2012	nombreTriggerRow	nombreFuncionRow_2()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_2();	CREATE FUNCTION nombreFuncionRow_2() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2016	nombreTriggerRow	nombreFuncionRow_3()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_3();	CREATE FUNCTION nombreFuncionRow_3() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING OLD;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2020	nombreTriggerRow	nombreFuncionRow_1()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_1();	CREATE FUNCTION nombreFuncionRow_1() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM OLD.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
1999	nombreTriggerRow	nombreFuncionRow_1()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_1();	CREATE FUNCTION nombreFuncionRow_1() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM OLD.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2000	nombreTriggerRow	nombreFuncionRow_2()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_2();	CREATE FUNCTION nombreFuncionRow_2() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2001	nombreTriggerRow	nombreFuncionRow_3()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_3();	CREATE FUNCTION nombreFuncionRow_3() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING OLD;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2002	nombreTriggerRow	nombreFuncionRow_1()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_1();	CREATE FUNCTION nombreFuncionRow_1() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM OLD.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2003	nombreTriggerRow	nombreFuncionRow_2()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_2();	CREATE FUNCTION nombreFuncionRow_2() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2004	nombreTriggerRow	nombreFuncionRow_3()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow_3();	CREATE FUNCTION nombreFuncionRow_3() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING OLD;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	57	1	f
2024	nombreTriggerRow	nombreFuncionCristian_2()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_2();	CREATE FUNCTION nombreFuncionCristian_2() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING OLD;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	58	1	f
2027	nombreTriggerRow	nombreFuncionCristian_2()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_2();	CREATE FUNCTION nombreFuncionCristian_2() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING OLD;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	58	1	f
2031	nombreTriggerRow	nombreFuncionCristian_3()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_3();	CREATE FUNCTION nombreFuncionCristian_3() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	58	1	f
2035	nombreTriggerRow	nombreFuncionCristian_1()	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian_1();	CREATE FUNCTION nombreFuncionCristian_1() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM OLD.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	58	1	f
--\.


--
-- Data for Name: operators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.operators (idoper, name, description, code, owner) FROM stdin;
6	CHU	Replace update statement	function CHU(){}	cristian
7	CHD	Replace delete statement	function CHD(){}	cristian
8	CAO	Replace arithmetic operator (+,-,*,/)	function CAO(){}	cristian
9	CLO	Replace logical operator (OR - AND)	function CLO(){}	cristian
10	CBT	Replace boolean operator (True - False)	function CBT(){}	cristian
11	CRO	Replace row operator	function CRO(){}	cristian
1	CNO	Replace NEW to OLD	function CNO(){}	cristian
2	ADI	Add insert statement	function(){}	cristian
3	ADU	Add update statement	function ADU(){}	cristian
4	ADD	Add delete statement	function ADD(){}	cristian
5	CHI	Replace insert statement	function CHI(){}	cristian
--\.


--
-- Data for Name: suites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suites (idsuite, description, login, databasename) FROM stdin;
226	pruebas domingo	hemilani@hotmail.com	pruebas
227	pruebas de 0	hemilani@hotmail.com	pruebas
216	prueba1 suite	cristian@hotmail.com	pruebas
217	prueba 2 suites con test existentes	cristian@hotmail.com	pruebas
225	pruebas suites	cristian@hotmail.com	tfm
233	prueba 18062020_v3	cristian@hotmail.com	pruebas
235	prueba 18062020_v4	cristian@hotmail.com	pruebas
237	prueba 18062020_pruebas	cristian@hotmail.com	pruebas
242	prueba 18062020	cristian@hotmail.com	pruebas
243	prueba 18062020	cristian@hotmail.com	pruebas
244	pruebas de 18/06/2020	cristian@hotmail.com	pruebas
245	pruebas de carga de los tests existentes	cristian@hotmail.com	pruebas
247	nueva suite	cristian@hotmail.com	pruebas
248	nueva suite_v2	cristian@hotmail.com	pruebas
249	nueva suite_v3	cristian@hotmail.com	pruebas
250	nueva suite_v4	cristian@hotmail.com	pruebas
252	nueva suite_v5	cristian@hotmail.com	pruebas
253	nueva suite_v6	cristian@hotmail.com	pruebas
254	nueva suite_v7	cristian@hotmail.com	pruebas
259	nueva suite_v72	cristian@hotmail.com	pruebas
263	SSSSSSSS	cristian@hotmail.com	pruebas
267	pruebas suitesas	milani1991@hotmail.com	pruebas
268	dsfasdfasdfa	milani1991@hotmail.com	pruebas
269	<xczc<zx<c	milani1991@hotmail.com	pruebas
219	1234567	cristian@hotmail.com	pruebas
270	pruebas de suites domingo	cristian@hotmail.com	pruebas
271	pruebas de domingo v2	cristian@hotmail.com	pruebas
272	asas	cristian@hotmail.com	pruebas
273	Laurel	cristian@hotmail.com	pruebas
274	pruebas de nueva suites	cristian@hotmail.com	pruebas
275	asdfasdf	cristian@hotmail.com	pruebas
276	prebas de suites	cristian@hotmail.com	pruebas
277	lunes	cristian@hotmail.com	pruebas
278	asfasdf	cristian@hotmail.com	tfm2
279	prueba	cristian@hotmail.com	pruebas
280	asfdasfd	cristian@hotmail.com	tfm2
281	asfdafd	cristian@hotmail.com	pruebas
282	ADSFASDF	cristian@hotmail.com	pruebas
--\.


--
-- Data for Name: test_suites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_suites (idsuite, idtest) FROM stdin;
259	381
259	382
259	383
259	384
259	385
259	386
259	387
259	388
259	389
259	390
259	391
259	392
259	393
259	394
259	395
259	396
259	397
259	398
259	399
217	315
217	316
227	325
227	326
263	419
263	420
263	421
233	334
233	335
263	422
235	337
235	338
263	423
263	424
263	425
263	426
263	427
263	428
263	429
242	346
242	347
243	348
244	349
244	350
244	351
245	349
245	350
263	430
263	431
247	355
247	356
247	357
248	358
248	359
248	360
249	361
249	362
249	363
250	364
250	365
250	366
263	432
263	433
263	434
252	370
252	371
252	372
253	373
253	374
253	375
254	376
254	377
254	378
263	435
263	436
263	437
263	438
263	439
263	440
263	441
263	442
267	443
267	444
268	346
268	347
270	349
270	350
271	447
271	448
271	449
271	450
272	451
272	452
272	453
272	454
273	455
273	456
273	457
273	458
273	459
273	460
274	461
274	462
274	463
274	464
274	465
274	466
276	374
276	375
277	468
280	469
281	470
--\.


--
-- Data for Name: tests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tests (idtest, test, databasename) FROM stdin;
315	insert into employees(name) values ('Jesus')	pruebas
316	insert into employees(name) values ('Mercedes')	pruebas
317	insert into employees (name) values ('Javier')	pruebas
318	insert into employees (name) values ('Carmen')	pruebas
325	insert into PRUEBAS22(prueba) values ('Messi')	pruebas
326	insert into PRUEBAS22('PRUEBAS') values ('cr')	pruebas
400	insert into employees(name) values ("PEPITO")	pruebas
334	insert into employees(name) values ('cr')	pruebas
335	insert into employees(name) values ('messi')	pruebas
337	insert into employees(name) values ('UDL')	pruebas
338	insert into employees(name) values ('Calahorra')	pruebas
346	insert into employees(name) values ('valencia2')	pruebas
347	 \r\ninsert into employees(name) values ('barcelona2')	pruebas
348	insert into employees(name) values ('valencia_')	pruebas
349	insert into employees(name) values ('Lama')	pruebas
350	insert into employees(name) values ('Paco')	pruebas
351	insert into employees(name) values ('Albelda')	pruebas
355	insert into employees(name) values ("valencia_")	pruebas
356	 \r\ninsert into employees(name) values ("valencia1_")	pruebas
357	 \r\ninsert into employees(name) values ("valencia2_")	pruebas
358	insert into employees(name) values ("valencia_987")	pruebas
359	  \r\ninsert into employees(name) values ("valencia1_987")	pruebas
360	  \r\ninsert into employees(name) values ("valencia2_987")	pruebas
361	insert into employees(name) values ("valencia_987")	pruebas
362	   \r\ninsert into employees(name768687) values ("valencia1_987")	pruebas
363	   \r\ninsert into employees(name) values ("valencia2_987")	pruebas
364	insert into employees(name) values ("valencia444")	pruebas
365	    \r\ninsert into employees(name768687) values ("valencia555")	pruebas
366	    \r\ninsert into employees(name) values ("valencia666")	pruebas
367	insert into employees(name) values ("log1")	pruebas
368	     \r\ninsert into employees(name) values ("log2")	pruebas
369	     \r\ninsert into employees(name) values ("log3")	pruebas
370	insert into employees(name) values ("log1")	pruebas
371	      \r\ninsert into employees(name) values ("log2")	pruebas
372	      \r\ninsert into employees(name) values ("log3")	pruebas
373	insert into employees(name) values ("log15")	pruebas
374	       \r\ninsert into employees(name) values ("log25")	pruebas
375	       \r\ninsert into employees(name) values ("log35")	pruebas
376	insert into employees(name) values ("po1")	pruebas
377	        \r\ninsert into employees(name) values ("po2")	pruebas
378	        \r\ninsert into employees(name) values ("po3")	pruebas
380	insert into employees(name) values ("PEPITO")	pruebas
381	insert into employees(name) values ("PEPITO")	pruebas
382	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
383	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
384	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
385	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
386	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
387	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
388	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
389	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
390	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
391	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
392	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
393	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
394	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
395	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
396	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
397	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
398	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
399	 \r\ninsert into employees(name) values ("PEPITO")	pruebas
401	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
402	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
403	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
404	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
405	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
406	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
407	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
408	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
409	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
410	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
411	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
412	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
413	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
414	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
415	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
416	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
417	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
418	  \r\ninsert into employees(name) values ("PEPITO")	pruebas
419	insert into employees(name) values ("valencia_987")	pruebas
420	    \r\ninsert into employees(name768687) values ("valencia1_987")	pruebas
421	    \r\ninsert into employees(name) values ("valencia2_987")	pruebas
422	 \r\ninsert into employees(name) values ("valencia_987")	pruebas
423	    \r\ninsert into employees(name768687) values ("valencia1_987")	pruebas
424	    \r\ninsert into employees(name) values ("valencia2_987")	pruebas
425	 \r\ninsert into employees(name) values ("valencia_987")	pruebas
426	    \r\ninsert into employees(name768687) values ("valencia1_987")	pruebas
427	    \r\ninsert into employees(name) values ("valencia2_987")	pruebas
428	 \r\ninsert into employees(name) values ("valencia_987")	pruebas
429	    \r\ninsert into employees(name768687) values ("valencia1_987")	pruebas
430	    \r\ninsert into employees(name) values ("valencia2_987")	pruebas
431	 \r\ninsert into employees(name) values ("valencia_987")	pruebas
432	    \r\ninsert into employees(name768687) values ("valencia1_987")	pruebas
433	    \r\ninsert into employees(name) values ("valencia2_987")	pruebas
434	 \r\ninsert into employees(name) values ("valencia_987")	pruebas
435	    \r\ninsert into employees(name768687) values ("valencia1_987")	pruebas
436	    \r\ninsert into employees(name) values ("valencia2_987")	pruebas
437	 \r\ninsert into employees(name) values ("valencia_987")	pruebas
438	    \r\ninsert into employees(name768687) values ("valencia1_987")	pruebas
439	    \r\ninsert into employees(name) values ("valencia2_987")	pruebas
440	 \r\ninsert into employees(name) values ("valencia_987")	pruebas
441	    \r\ninsert into employees(name768687) values ("valencia1_987")	pruebas
442	    \r\ninsert into employees(name) values ("valencia2_987")	pruebas
443	insert into employees(name) values ("messi")	pruebas
444	insert into employees(name) values ("cristiano")	pruebas
447	insert into employees(name) values ("UDL")	pruebas
448	\r\nINSERT INTO employees(name) values ("Castellon")	pruebas
449	\r\ninsert into employees(name) values ("BALEARES")	pruebas
450	\r\ninsert into employees(name) values ("Cartagena")	pruebas
451	insert into employees(name) values ("Leganes")	pruebas
452	\r\ninsert into employees(name) values ("Mallorca")	pruebas
453	\r\ninsert into employees(name) values ("Espanyol")	pruebas
454	\r\ninsert into employees(name) values ("Getafe")	pruebas
455	insert into employees(name) values ("Antonio")	pruebas
456	\r\ninsert into employees(name) values ("Zelu")	pruebas
457	\r\ninsert into employees(name) values ("Andy")	pruebas
458	\r\ninsert into employees(name) values ("Ander")	pruebas
459	\r\ninsert into employees(name) values ("Santos")	pruebas
460	\r\ninsert into employees(name) values ("Caneda")	pruebas
461	insert into employees(name) values ("lio10")	pruebas
462	\r\ninsert into employees(name) values ("Luis9")	pruebas
463	\r\ninsert into employees(name) values ("Arthur8")	pruebas
464	\r\ninsert into employees(name) values ("Jordi18")	pruebas
465	\r\ninsert into employees(name) values ("Antoine7")	pruebas
466	\r\ninsert into employees(name) values ("Ousmane11")	pruebas
468	insert into employees (name) values ('pepe')	pruebas
469	fdsadsfasdf	tfm2
470	asdfasdfad	pruebas
--\.


--
-- Data for Name: triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.triggers (idtrigger, name, headertrigger, bodytrigger, login, databasename, description) FROM stdin;
19	nombre de prueba	trigger header	trigger function	cristian	tfm	descripcion
29	prueba 99	asdfa	afasda	cristian	tfm	asdfa
38	nombre trigger grabar	CREATE TRIGGER grabar_operaciones AFTER INSERT OR UPDATE OR DELETE\r\n    ON numeros FOR EACH STATEMENT \r\n    EXECUTE PROCEDURE grabar_operaciones();	CREATE OR REPLACE FUNCTION grabar_operaciones() RETURNS TRIGGER AS $grabar_operaciones$\r\n  DECLARE\r\n  BEGIN\r\n    \r\n    INSERT INTO cambios (\r\n                nombre_disparador,\r\n                tipo_disparador,\r\n                nivel_disparador,\r\n                comando) \r\n        VALUES (               \r\n                TG_NAME,\r\n                TG_WHEN,\r\n                TG_LEVEL,\r\n                TG_OP\r\n               );\r\n\r\n    RETURN NULL;\r\n  END;\r\n$grabar_operaciones$ LANGUAGE plpgsql;	prueba	tfm	ejemplo de trigger 
39	MILANI	CREATE TRIGGER trigg_stock_insert000 BEFORE INSERT ON users FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger000();	CREATE FUNCTION stock_insert_trigger000() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || "VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian	tfm	DESC milani
40	trigger cristian	CREATE TRIGGER trigg_stock_insert0 BEFORE INSERT ON users FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger0();	CREATE FUNCTION stock_insert_trigger0() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian	tfm	esto es una prueba de trigger
41	prueba90	CREATE TRIGGER trigg_stock_insert90 BEFORE INSERT ON users FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger90();	CREATE FUNCTION stock_insert_trigger90() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || "VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql	cristian	tfm	prueba90
43	pruebas	CREATE TRIGGER trigg_stock_insert BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger();	CREATE FUNCTION stock_insert_trigger() RETURNS TRIGGER AS $$ BEGIN IF extract(year FROM NEW.day) = 2018 THEN EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || "VALUES ($1.*)" USING NEW; END IF; RETURN NULL; END; $$ LANGUAGE plpgsql;	cristian	pruebasInsert	Descripcion de insert
45	pruebas2	CREATE TRIGGER trigg_stock_insert BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger();	CREATE FUNCTION stock_insert_trigger() RETURNS TRIGGER AS $$ BEGIN IF extract(year FROM NEW.day) = 2018 THEN EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || "VALUES ($1.*)" USING NEW; END IF; RETURN NULL; END; $$ LANGUAGE plpgsql;	cristian	pruebasInsert	Descripcion de insert
46	pruebas domingo2	CREATE FUNCTION stock_insert_trigger() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || "VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	CREATE TRIGGER trigg_stock_insert BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger();	cristian	pruebas	desc domingo3
47	name pruebas	CREATE TRIGGER trigg_stock_insert BEFORE INSERT ON t FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger();	CREATE FUNCTION stock_insert_trigger() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || "VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql	cristian	tfm	desc name pruebas
48	pruebas de trigger	CREATE TRIGGER trigg_stock_insert999 BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger999();	CREATE FUNCTION stock_insert_trigger999() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || "VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql	hemilani@hotmail.com	pruebas	descripcion de trigger
49	generico	CREATE TRIGGER nombreTrigger BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncion();	CREATE FUNCTION nombreFuncion() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian	pruebas	Es el trigger generico para pruebas
51	generico_v2	CREATE TRIGGER genericoV2 BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE insert_triggerGenerico();	CREATE FUNCTION insert_triggerGenerico() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian	pruebas	desc generico_v2
52	trigger insert	CREATE TRIGGER generico_ins BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE pruebasIns();	CREATE FUNCTION pruebasIns() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "DELETE employees SET name = Logrones" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian	pruebas	desc insert
53	triggerSuma	CREATE TRIGGER nombreTriggerSuma BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionSuma();	CREATE FUNCTION nombreFuncionSuma() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day ++1) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian	pruebas	descripcion trigger con suma
54	trigger resta	CREATE TRIGGER nombreTriggerResta BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionResta();	CREATE FUNCTION nombreFuncionResta() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" ||2/1/0|| date_part("quarter", NEW.day) ||" VALUES ($1)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian	pruebas	descripcion trigger con resta
55	trigger and	CREATE TRIGGER nombreTriggerAnd BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionAnd();	CREATE FUNCTION nombreFuncionAnd() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || OR || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian	pruebas	descripcion de trigger con AND
56	trigger TRUE	CREATE TRIGGER nombreTriggerTrue BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionTrue();	CREATE FUNCTION nombreFuncionTrue() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || FALSE || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian	pruebas	descripcion del trigger con TRUE
57	trigger row	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionRow();	CREATE FUNCTION nombreFuncionRow() RETURNS TRIGGER AS $$\nBEGIN\nIF extract(year FROM NEW.day) = 2018 THEN\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || " VALUES ($1.*)" USING NEW;\nEND IF;\n\nRETURN NULL;\nEND;\n$$ LANGUAGE plpgsql;	cristian	pruebas	descripcion trigger row
59	pruebas sabado	CREATE TRIGGER trigg_insert_milani BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_milani();	CREATE FUNCTION stock_milani() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2019_t"  || " VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	milani1991@hotmail.com	pruebas	pruebas sabado
92	miercoles definitiva	CREATE TRIGGER price_trigger\r\n    AFTER INSERT OR UPDATE\r\n    ON public.employees\r\n    FOR EACH ROW\r\n    EXECUTE PROCEDURE public.price_audit();\r\n	CREATE FUNCTION public.price_audit()\r\n    RETURNS trigger\r\n    LANGUAGE "plpgsql"\r\nAS $BODY$\r\n   BEGIN\r\n      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);\r\n      RETURN NEW;\r\n   END;\r\n$BODY$;	cristian@hotmail.com	pruebas	miercoles definitiva
95	pruebas del martes 07072020	CREATE TRIGGER price_trigger\r\n    AFTER INSERT OR UPDATE\r\n    ON public.employees\r\n    FOR EACH ROW\r\n    EXECUTE PROCEDURE public.price_audit();	CREATE FUNCTION public.price_audit()\r\n    RETURNS trigger\r\n    LANGUAGE "plpgsql"\r\nAS $BODY$\r\n   BEGIN\r\n      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);\r\n      RETURN NEW;\r\n   END;\r\n$BODY$;	cristian@hotmail.com	pruebas	desc pruebas martes 070707
99	aa	CREATE TRIGGER price_trigger2\r\n    AFTER INSERT OR UPDATE\r\n    ON public.employees\r\n    FOR EACH ROW\r\n    EXECUTE PROCEDURE public.price_audit2();	CREATE FUNCTION public.price_audit2()\r\n    RETURNS trigger\r\n    LANGUAGE "plpgsql"\r\nAS $BODY$\r\n   BEGIN\r\n      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);\r\n      RETURN NEW;\r\n   END;\r\n$BODY$;	cristian@hotmail.com	pruebas	aa
100	pruebas miercoles	CREATE TRIGGER price_trigger\r\n    AFTER INSERT OR UPDATE\r\n    ON public.employees\r\n    FOR EACH ROW\r\n    EXECUTE PROCEDURE public.price_audit();\r\n	CREATE FUNCTION public.price_audit()\r\n    RETURNS trigger\r\n    LANGUAGE "plpgsql"\r\nAS $BODY$\r\n   BEGIN\r\n      INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp);\r\n      RETURN NEW;\r\n   END;\r\n$BODY$;	cristian@hotmail.com	pruebas	desc pruebas miercoes
58	papapap	CREATE TRIGGER nombreTriggerRow BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE nombreFuncionCristian();	CREATE FUNCTION nombreFuncionCristian() RETURNS TRIGGER AS $$\r\nBEGIN\r\nIF extract(year FROM NEW.day) = 2018 THEN\r\nEXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", OLD.day) || " VALUES ($1.*)" USING NEW;\r\nEND IF;\r\n\r\nRETURN NULL;\r\nEND;\r\n$$ LANGUAGE plpgsql;	cristian@hotmail.com	pruebas	popopo
--\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (login, password, compartirinfo) FROM stdin;
cristian	cristian	f
prueba@hotmail.com	prueba	\N
milani1990@hotmail.es	milani	\N
prueba	prueba	\N
messi@hotmail.com	messi	t
cr@hotmail.com	cr	f
hector@hotmail.com	hector	f
CARLOS@hotmail.com	carlos	f
mama@hotmail.com	mama	f
papa@hotmail.com	papa	f
papa@hotmailasdfasdf	asdfasdf	f
papa@hotmailasdfasdf222	asdfasfda	f
ASDFASDFASF@SADFASDF	AAAA	f
asdfasdfadsafd@asdfaf.com	asd	f
asdfasdfadsafd@asdfa2f.com	aaaa	f
audi@hotmail.com	audi	f
aaaaa@hotmail.com	aaa	f
messi2@hotmail.com	messi2	f
sergio@hotmail.com	sergio	t
pepito@hotmail.com	pepito	f
hemilani@hotmail.com	hemilani	f
jesus@hotmail.com	jesus	f
milani1991@hotmail.com	milani	f
cristian@hotmail.com	cristian	f
pepe@hotmail.com	pepe	t
pepe2@hotmail.com	pepe2	f
--\.


--
-- Name: mutations_idmutation_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mutations_idmutation_seq', 2039, true);


--
-- Name: operators_idoper_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.operators_idoper_seq', 40, true);


--
-- Name: suites_idsuite_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.suites_idsuite_seq', 282, true);


--
-- Name: tests_idtest_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tests_idtest_seq', 470, true);


--
-- Name: triggers_idtrigger_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.triggers_idtrigger_seq', 100, true);


--
-- Name: mutations mutations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mutations
    ADD CONSTRAINT mutations_pkey PRIMARY KEY (idmutation);


--
-- Name: operators operators_idoperator_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operators
    ADD CONSTRAINT operators_idoperator_unique UNIQUE (idoper);


--
-- Name: execution_tests pk_execution_tests; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.execution_tests
    ADD CONSTRAINT pk_execution_tests PRIMARY KEY (idmutacion, idtest);


--
-- Name: operators pk_operators; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operators
    ADD CONSTRAINT pk_operators PRIMARY KEY (name);


--
-- Name: suites pk_suites; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suites
    ADD CONSTRAINT pk_suites PRIMARY KEY (idsuite);


--
-- Name: test_suites pk_test_suites; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_suites
    ADD CONSTRAINT pk_test_suites PRIMARY KEY (idsuite, idtest);


--
-- Name: tests pk_tests; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tests
    ADD CONSTRAINT pk_tests PRIMARY KEY (idtest);


--
-- Name: triggers pk_triggers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.triggers
    ADD CONSTRAINT pk_triggers PRIMARY KEY (name, login);


--
-- Name: users pk_users; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT pk_users PRIMARY KEY (login);


--
-- Name: triggers uk_idtrigger; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.triggers
    ADD CONSTRAINT uk_idtrigger UNIQUE (idtrigger);


--
-- Name: triggers uk_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.triggers
    ADD CONSTRAINT uk_name UNIQUE (name);


--
-- Name: execution_tests execution_tests_idmutation_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.execution_tests
    ADD CONSTRAINT execution_tests_idmutation_fkey FOREIGN KEY (idmutacion) REFERENCES public.mutations(idmutation) NOT VALID;


--
-- Name: execution_tests execution_tests_idtest_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.execution_tests
    ADD CONSTRAINT execution_tests_idtest_fkey FOREIGN KEY (idtest) REFERENCES public.tests(idtest);


--
-- Name: mutations mutations_idoperator_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mutations
    ADD CONSTRAINT mutations_idoperator_fkey FOREIGN KEY (idoperator) REFERENCES public.operators(idoper) NOT VALID;


--
-- Name: mutations mutations_idtrigger_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mutations
    ADD CONSTRAINT mutations_idtrigger_fkey FOREIGN KEY (idtrigger) REFERENCES public.triggers(idtrigger) NOT VALID;


--
-- Name: mutations mutations_login_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mutations
    ADD CONSTRAINT mutations_login_fkey FOREIGN KEY (login) REFERENCES public.users(login) NOT VALID;


--
-- Name: operators operators_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operators
    ADD CONSTRAINT operators_owner_fkey FOREIGN KEY (owner) REFERENCES public.users(login) NOT VALID;


--
-- Name: suites suites_login_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suites
    ADD CONSTRAINT suites_login_fkey FOREIGN KEY (login) REFERENCES public.users(login);


--
-- Name: test_suites test_suites_idsuite_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_suites
    ADD CONSTRAINT test_suites_idsuite_fkey FOREIGN KEY (idsuite) REFERENCES public.suites(idsuite);


--
-- Name: test_suites test_suites_idtest_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_suites
    ADD CONSTRAINT test_suites_idtest_fkey FOREIGN KEY (idtest) REFERENCES public.tests(idtest);


--
-- Name: triggers triggers_login_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.triggers
    ADD CONSTRAINT triggers_login_fkey FOREIGN KEY (login) REFERENCES public.users(login);


--
-- PostgreSQL database dump complete
--

