	<?php
session_start(); //Iniciamos o Continuamos la sesion
if (isset($_POST['login'])) //Si llego un Nickname via el formulario lo grabamos en la Sesion
{
	$_SESSION['login'] = $_POST['login']; 
}
if ($_SESSION['login']) //Si hay un nickname en la sesion actual, creamos una variable que será mostrada
{
	
	
}


try{

$conexion = pg_connect($_SESSION['conexion']);


	$usuario = $_SESSION['login'];

	
$description = pg_escape_string($_SESSION['description']); 



$databasename = pg_escape_string($_SESSION['databaseName']); 






$tests = pg_escape_string($_SESSION['editTests']); 
$test = explode(";", $tests);


//saco el numero de elementos
$longitud = count($test);


//INICIO
			
			$res = pg_query("SELECT nextval('suites_idsuite_seq') as id");
			$row = pg_fetch_array($res, 0);
			$suiteSecuencia = trim($row["id"]);
						
			
//FIN




$sql = "insert into suites(idsuite, description,login,databasename) values ($suiteSecuencia,'$description','$usuario', '$databasename')";


//Ejecutamos la consulta
$res = pg_query($sql) or die('La consulta fallo: ' . pg_last_error());
 

 
//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
pg_free_result($res);


			
//Recorro todos los elementos
for($i=0; $i<$longitud-1; $i++)
{
		  
			
			
			//INICIO
			
			$secuenciaTest = pg_query("SELECT nextval('tests_idtest_seq') as id");
			$row = pg_fetch_array($secuenciaTest, 0);
			$testSecuencia = trim($row["id"]);
			
			
      //saco el valor de cada elemento	
	  $testInd = $test[$i];
	  $sqlTest = "insert into tests(idtest,test,databasename) values ( $testSecuencia,'$testInd', '$databasename')";
	  $resTest = pg_query($sqlTest) or die('La consulta fallo: ' . pg_last_error());
	  pg_free_result($resTest);
	  
	  //TABLA TEST_SUITES
	  
		$sqlTestSuite = "insert into test_suites values ($suiteSecuencia, $testSecuencia)";
		$testSuite = pg_query($sqlTestSuite);
	  
	  
}





 
//Cerramos la conexión
pg_close($conexion);
header('location: suites.php');
}

 catch(Exception $e) //capturamos un posible error
  {
    //mostramos el texto del error al usuario	  
    echo "error." . PHP_EOL;
	//die('El test es erroneo, revisalo: ' . $php_errormsg);
    
	
	//header('Location: error_add_tests.php');
  }




?>