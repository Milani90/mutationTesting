<?php
	session_start();
	//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
	$conexion = pg_connect($_SESSION['conexion']);
	

 //Activamos todas las notificaciones de error posibles
  error_reporting (E_ALL);

  //Definimos el tratamiento de errores no controlados
  set_error_handler(function () 
  {
    throw new Exception("Error");
  });
  
    function LogDeErrores($numeroDeError, $descripcion, $fichero, $linea, $contexto){
	  echo '<br>';
   error_log("Error: [".$numeroDeError."] ".$descripcion." ".$fichero." ".$linea." ".json_encode($contexto)." \n\r", 3, "log_errores.txt");
   $error = explode ("ERROR:", $descripcion);
   $_SESSION['descripcionErrorTrigger'] = $error[1];
   throw new Exception("Error");
  }
  set_error_handler("LogDeErrores");


	//Recuperamos el id modificado al hacer click 


	$nombre=$_POST['enombre'];
	echo $nombre;
	echo '<br>';echo '<br>';echo '<br>';
	$descripcion=$_POST['edescripcion'];
	echo $descripcion;
	echo '<br>';echo '<br>';echo '<br>';

	$cuerpo_trigger = $_POST['ecuerpo_trigger'];
	echo $cuerpo_trigger;
	echo '<br>';echo '<br>';echo '<br>';
	$funcion_trigger= $_POST['efuncion_trigger'];
	echo $funcion_trigger;
	echo '<br>';echo '<br>';echo '<br>';

	$idtrigger = $_SESSION['idTrigger'];
	
	
	//	BORRAR TRIGGER 
	//$deleteTrigger = "DROP TRIGGER on 
	//DROP TRIGGER if_dist_exists ON films;
	
	
	$triggerFunctionValido = false;
echo '<br>';echo '<br>';
//echo 'FUNCION:', $triggerFunction ;
echo '<br>';echo '<br>';
//$triggerFunctionEsc = addslashes($triggerFunctionEsc);
//$triggerFunctionEsc = str_replace('&quot;','&#39;', $triggerFunctionEsc);
$triggerFunctionEsc = pg_escape_string($funcion_trigger);
$triggerFunctionEsc = str_replace('"','\'', $triggerFunctionEsc);
echo 'TRIGGERFUNCTION: <br>', $triggerFunctionEsc;



//INICIO
try 
  {
//pg_query("SAVEPOINT inicio");
//pg_query("BEGIN");
$triggerFunctionIns = pg_query($triggerFunctionEsc);
//pg_query("ROLLBACK TO SAVEPOINT inicio;");
//pg_query("ROLLBACK;");
echo 'FUNCTIONNNNNN: ', $triggerFunctionIns;


if($triggerFunctionIns){
	//$triggerFunction = $triggerFunction;
	
	$triggerFunctionValido = true;
	echo " Correct inserting function";
}
else
{
	echo " Error inserting function";
}

  
echo '<br>';
echo '<br>';
echo '<br>';

$triggerHeaderValido = false;


$triggerHeaderEsc = pg_escape_string($cuerpo_trigger);
$triggerHeaderEsc = str_replace('"','\'',$triggerHeaderEsc);

echo '<br>';
echo '<br>';
echo '<br>';
//$triggerHeaderEsc = 'CREATE TRIGGER trigg_stock_insert454 BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger454();';
echo 'TRIGGER HEADER   : <br>', $triggerHeaderEsc;
//$triggerHeaderIns = pg_query($triggerHeaderEsc) or die('La consulta fallo: ' . pg_last_error()); //MENSAJE DE ERROR
$triggerHeaderIns = pg_query($triggerHeaderEsc);
echo 'TRIGGEREEEEE: ', $triggerHeaderIns;
if($triggerHeaderIns){
	
	
	$triggerHeaderValido = true;
	echo " Correct inserting trigger";
}
else
{
	echo " Error inserting trigger";
}



if($triggerFunctionValido == true && $triggerHeaderValido == true){
	echo 'ANTES';
	
	 //pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
	 pg_connect($_SESSION['conexion']);
//$sql = "insert into triggers(name,headertrigger,bodytrigger,login,databasename,description) values ('$triggerName', addslashes('$triggerHeader'), addslashes('$triggerFunction') ,'$usuario', '$databaseName', '{$description}')";
//$sql = "insert into triggers(name,headertrigger,bodytrigger,login,databasename,description) values ('$triggerName', '$triggerHeader', '$triggerFunction' ,'$usuario', '$databaseName', '{$description}')";
//$sql = "insert into triggers(name,headertrigger,bodytrigger,login,databasename,description) values ('$triggerName', $triggerHeaderEsc, $triggerFunctionEsc ,'$usuario', '$databaseName', '$description')";
$sql = "update triggers set name='$nombre', description='$descripcion', headertrigger='$triggerHeaderIns', bodytrigger='$triggerFunctionIns' where idtrigger='$idtrigger'" ;
	echo '<br>';
	echo 'DESPUES';
	
	echo 'CONSULTA UPDATE : ',  $sql;





 
//Ejecutamos la consulta

$res = pg_query($sql);


  
  if($res)
  {
	  //ELIMINAMOS EL TRIGGER CREADO
$host = "host=127.0.0.1 ";
$port = "port=5432 ";
$dbname = "dbname=" . $_POST['databaseName'];
//$dbname = "dbname=pruebas";
$user = " user=postgres ";
$password = "password=root";
$confConexion = $host . $port . $dbname .$user . $password;
echo $confConexion;

$nombreFunction= explode(" ", $triggerFunctionIns);
$nomFunction = $nombreFunction[2];
$deleteFunction = "drop function ".$nomFunction."cascade;";
echo 'DELETE FUNCTION: ', $deleteFunction;
//pg_query($confConexion,$deleteFunction);

	echo "Trigger insertado correctamente";
//	header('location: triggers.php');
  }
  else{
	echo "Error critico";
//	header('location: error_trigger.php'); 
	//echo die('La consulta fallo: ' . pg_last_error());
  }
  
 
//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
pg_free_result($res);
 
} 
  }
  catch(Exception $e) //capturamos un posible error
  {
    //mostramos el texto del error al usuario	  
    echo "Error al insertar el trigger." . PHP_EOL;
	echo "Revise el código." . PHP_EOL;
	
	
	header('location: error_trigger.php'); 
  }
  


  //Restablecemos el tratamiento de errores
  restore_error_handler();



//FIN




	//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
	//pg_free_result($res);

	//$sql = "update triggers set nombre='$nombre', descripcion='$descripcion', cuerpo_trigger='$cuerpo_trigger', funcion_trigger='$funcion_trigger' where idtrigger='$idtrigger'" ;
//	$sql = "update triggers set name='$nombre', description='$descripcion', headertrigger='$cuerpo_trigger', bodytrigger='$funcion_trigger' where idtrigger='$idtrigger'" ;
//	echo 'CONSULTA:',$sql;

	//Ejecutamos la consulta
//	$res = pg_query($sql) or die('La consulta fallo: ' . pg_last_error());

	echo "Registro actualizado correctamente";


	//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
	pg_free_result($sql);
	 
	//Cerramos la conexión
	pg_close($conexion);

//	header('Location: triggers.php');
?>