<!--<script type="text/javascript" src="delete_suite.js"></script>-->
<?php
session_start(); //Iniciamos o Continuamos la sesion

//$id = intval($_GET['id']);
//$q = intval($_GET['q']);
//$idSuite = intval($_GET['idSuite']);
//$id = intval($_GET['id']);
$id = intval($_GET['idSuite']);

	# conectare la base de datos
    //$con=@mysqli_connect('localhost', 'root', 'root', 'test');
	//$con = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
	$con = pg_connect($_SESSION['conexion']);
    if(!$con){
        die("imposible conectarse: ".pg_error($con));
    }
    if (@pg_last_error()) {
        die("Connect failed: ".pg_last_error()." : ". pg_last_error());
    }
	$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';
	if($action == 'ajax'){
		include 'paginationTestSuite.php'; //incluir el archivo de paginación
		//las variables de paginación
		$pageTest = (isset($_REQUEST['pageTest']) && !empty($_REQUEST['pageTest']))?$_REQUEST['pageTest']:1;
		$per_pageTest = 8; //la cantidad de registros que desea mostrar
		$adjacentsTest  = 4; //brecha entre páginas después de varios adyacentes
		$offsetTest = ($pageTest - 1) * $per_pageTest;
		//Cuenta el número total de filas de la tabla*/
		$count_queryTest   = pg_query($con,"SELECT count(*) AS numrows FROM tests ");
		if ($reg= pg_fetch_array($count_queryTest)){$numrows = $reg['numrows'];}
		$total_pagesTest = ceil($numrows/$per_pageTest);
		$reloadTest = 'index.php';
		//consulta principal para recuperar los datos  
		
		//$q = intval($_GET['q']);
		//$query = pg_query($con,"SELECT * FROM triggers order by idtrigger LIMIT $offset,$per_page");
		//$query = pg_query($con,"SELECT * FROM suites order by idsuite OFFSET '$offset' LIMIT '$per_page';");
		//$id=$_POST['id'];
		//$id=$_GET['id'];
		
		//$id=$_SESSION['id'];
		//$id = $_SESSION['idSuiteElegida'];
		//$id = $_SESSION['idListadoSuite'];
		//$id = $_POST['id'];
		//$q = intval($_GET['q']);

		//$sql = 'SELECT test FROM tests where idtest in (select ts.idtest from test_suites ts where ts.idsuite  = '.$id.')';
		
		//$query = pg_query($con,"SELECT * FROM testt order by idtest OFFSET '$offset' LIMIT '$per_page';");
		$query = pg_query($con,"SELECT * FROM tests where idtest in (select ts.idtest from test_suites ts where ts.idsuite  = '.$id.') OFFSET '$offsetTest' LIMIT '$per_pageTest';");
		
		if ($numrows>0){
			?>
		<table class="table table-bordered">
			  <thead>
				<tr>
				  <tr>
						<th>TEST22222</th>
						<th>DATABASENAME</th>
						<!--
						<th>DATABASENAME</th>
						<th>ACTIONS</th>-->
				</tr>
			</thead>
			<tbody>
			<?php
			while($reg=pg_fetch_array($query)){
				?>
				<tr>
				
	
					
					<td width="40%"><span id="description<?php echo $reg['idtest']; ?>"><?php echo $reg['test']; ?></span></td>
					
					<td width="20%"><span id="login<?php echo $reg['idtest']; ?>"><?php echo $reg['databasename']; ?></span></td>
					<!--
					<td width="20%"><span id="databasename<?php echo $reg['idsuite']; ?>"><?php echo $reg['databasename']; ?></span></td>
					<td style="display:none"><a><span type="hidden" id="idsuite<?php echo $reg['idsuite']; ?>"></span></a></td>
					
					-->
					
				<!--<input type="checkbox" id="loaderTest" name="testsTabla[]" value="< ?php echo $reg['idtest']; ?>"> <label for="testListado">< ?php echo $reg['test'] ?></label>-->
				
			
			
				</tr>
				<?php
			}
			 
			//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
			pg_free_result($query);
			 
			//Cerramos la conexión
			//pg_close($con);
			?>
			</tbody>
		</table>
		<div class="table-pagination pull-right">
			<?php echo paginateTestSuite($reloadTest, $pageTest, $total_pagesTest, $adjacentsTest);?>
		</div>
		
			<?php
			
		} else {
			?>
			<div class="alert alert-warning alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4>Aviso!!!</h4> No hay datos para mostrar
            </div>
			<?php
		}
	}
?>
