<script src="view_trigger.js"></script>
<!-- Edit Modal HTML -->
	<div id="view" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<!--<form action="edit_trigger.php" method="POST">-->
					<div class="modal-header">						
						<h4 class="modal-title">View Trigger</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					
									<div class="modal-body">
									<div class="form-group">
										<label>TRIGGER NAME22</label>
										<!-- $nombre = isset($reg[0]) ? $reg[0] : null ;-->
										<input type="text" class="form-control"  id="vnombre" name="vnombre" readonly>
										 
									</div>
									
									<div class="form-group">
										<label>DESCRIPTION</label>
										<!--$descripcion = isset($reg[1]) ? $reg[1] : null ;									-->
										<input type="text" class="form-control" id="vdescripcion" name="vdescripcion" readonly>
										
									</div>
									<div class="form-group">
										<label>TRIGGER HEADER</label>
											<!--$cuerpo_trigger = isset($reg[2]) ? $reg[2] : null ;									-->
										<textarea class="form-control"  rows="5" id="vcuerpo_trigger" readonly></textarea>

									</div>
									<div class="form-group">
									<label>TRIGGER FUNCTION</label>
											<!--$funcion_trigger = isset($reg[3]) ? $reg[3] : null ;-->
									<textarea class="form-control"  rows="10" id="vfuncion_trigger" readonly></textarea>
									
									</div>
									<!--$idtrigger = isset($reg[4]) ? $reg[4] : null ; -->
									<input type="hidden" class="form-control"  id="vidtrigger" readonly>

															
								</div>
								<!--
								<div class="modal-footer">
								<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">				
									<input type="submit" id="update" class="btn btn-info" value="Save">
								</div>	
								-->	
									<!--break;--
								}
								-->
								
								 <!--
								//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
								pg_free_result($res);
								 
								//Cerramos la conexión
								pg_close($conexion);
								?>
								-->
								
					
				<!--</form>-->
			</div>
		</div>
	</div>