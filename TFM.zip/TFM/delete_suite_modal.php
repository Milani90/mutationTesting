<?php
session_start(); //Iniciamos o Continuamos la sesion
$conexion = pg_connect($_SESSION['conexion']);

if($_REQUEST['suiteid']) {
	
	$deleteTestSuite = 'delete from test_suites where idsuite = '.$_REQUEST['suiteid'].'';
	pg_query($deleteTestSuite);
	
	$deleteTest = 'delete from tests where idtest in ('.$_REQUEST['suiteid'].')';
	
	
	$sql = "DELETE FROM suites WHERE idsuite='".$_REQUEST['suiteid']."'";
	$resultset = pg_query($conexion, $sql) or die("database error:". pg_last_error($conn));	
	if($resultset) {
		echo "Record Deleted";
	}
}
?>
