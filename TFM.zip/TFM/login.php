<?php
session_start();
?>
<?php include('conexion.php');?>
<?php

//Guarda los valores de los campos en variables, siempre y cuando se haya enviado el formulario, sino se guardará null.
$login = isset($_POST['login']) ? $_POST['login'] : null;
$pass = isset($_POST['password']) ? $_POST['password'] : null;
$_SESSION['login'] = $login;
$_SESSION['password'] = $pass;

//Este array guardará los errores de validación que surjan.
$errores = array();

function validaLogin($login,$pass){
	
    
$query=("SELECT * FROM users WHERE login='$login' and password='$pass'");

	//echo $query;

  
  $result = pg_query($query);
  //echo $result;
  $rows = pg_num_rows($result);
  //echo 'NUMERO DE FILAS: ', $rows;

	if($rows != 1){
		return false;
	}
	else{
		return true;
	}
}

//Pregunta si está llegando una petición por POST, lo que significa que el usuario envió el formulario.
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    //Valida que el campo email sea correcto.
    if (!validaLogin($login,$pass)) {
        $errores[] = 'Usuario y/o contraseña incorrectos.';
    }
	else{
		header("location: index.php");
	}
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
<!-- Custom styles for this template -->
  <link href="css/login.css" rel="stylesheet">


<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<script>
$(document).ready(function () {
  $('#mostrar_contrasena').click(function () {
    if ($('#mostrar_contrasena').is(':checked')) {
      $('#password').attr('type', 'text');
    } else {
      $('#password').attr('type', 'password');
    }
  });
});
</script>
</head>
<body>
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

    <!-- Icon -->
    <div class="fadeIn first">
      <!--<img src="img/icon_user_v2.png" id="icon" alt="User Icon" width="6%" height="6%" />-->
    </div>

    <!-- Login Form -->
    <!--<form  action="tramitar_login.php" method="post">-->
	<form  action="login.php" method="post">
      <!--<input type="text" id="login" class="fadeIn second" name="login" placeholder="login">  -->
      <!--<input type="text" id="password" class="fadeIn third" name="password" placeholder="password"/><br>-->
	 <div class="modal-body">					
		<div class="form-group">
			<label>User</label>
			<input id="email" type="email" name="login" class="form-control" autocomplete="nope" required>
		</div>
		<div class="form-group">
			<label>Password</label>
			<input type="password" name="password" class="form-control" id="password" autocomplete="nope" required>
		<div>
			<input style="margin-left:20px;" type="checkbox" id="mostrar_contrasena" title="Click to show password"/>
			&nbsp;&nbsp;Show Password
			</div>
		</div>
		<?php if ($errores): ?>
            <ul style="color: #f00;">
                <?php foreach ($errores as $error): ?>
                    <?php echo $error ?>
					<?php echo '<br>' ?>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>		
		
	</div>
      <input type="submit" class="fadeIn fourth" value="Log In">
    </form>
	
	<!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="reset_password.php">Forgot Password?</a>
	  <span class="izquierda">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>
	  <span href="#" class="derecha">Create a new account <a class="underlineHover" href="create_user.php"><u>here</u></a></span>
    </div>




  </div>
</div>



</body>

</html>
