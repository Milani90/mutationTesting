<script type="text/javascript" src="delete_trigger.js"></script>
<?php
session_start(); //Iniciamos o Continuamos la sesion


	# conectare la base de datos
	$con = pg_connect($_SESSION['conexion']);
    if(!$con){
        die("imposible conectarse: ".pg_error($con));
    }
    if (@pg_last_error()) {
        die("Connect failed: ".pg_last_error()." : ". pg_last_error());
    }
	$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';
	if($action == 'ajax'){
		include 'pagination.php'; //incluir el archivo de paginación
		//las variables de paginación
		$page = (isset($_REQUEST['page']) && !empty($_REQUEST['page']))?$_REQUEST['page']:1;
		$per_page = 14; //la cantidad de registros que desea mostrar
		$adjacents  = 4; //brecha entre páginas después de varios adyacentes
		$offset = ($page - 1) * $per_page;
		//Cuenta el número total de filas de la tabla*/
		$count_query   = pg_query($con,"SELECT count(*) AS numrows FROM triggers ");
		if ($reg= pg_fetch_array($count_query)){$numrows = $reg['numrows'];}
		$total_pages = ceil($numrows/$per_page);
		$reload = 'index.php';
		//consulta principal para recuperar los datos  
		
		
		$query = pg_query($con,"SELECT * FROM triggers order by name OFFSET '$offset' LIMIT '$per_page';");
		
		if ($numrows>0){
			?>
		<table class="table table-bordered">
			  <thead>
				<tr>
				  <tr>
					<th>TRIGGER NAME</th>
					<th>DESCRIPTION</th>
					<th>ACTIONS</th>
				</tr>
			</thead>
			<tbody>
			<?php
			while($reg = pg_fetch_array($query)){
				?>
							
<!--				//INICIO  -->
				<tr style="height: 43px;">
									
					<td width="20%" style="height: 43px;"><a href="show_trigger_read.php?id=<?php echo $reg['idtrigger'];  ?>"><span id="nombre<?php echo $reg['idtrigger']; ?>"><?php echo $reg['name']; ?></span></a></td>
					<td width="70%" style="height: 43px;"><a href="show_trigger_read.php?id=<?php echo $reg['idtrigger'];  ?>"><span id="descripcion<?php echo $reg['idtrigger']; ?>"><?php echo $reg['description']; ?></span></a></td>
					<td   style="display:none; "><span type="hidden" id="funcion_trigger<?php echo $reg['idtrigger']; ?>"><?php echo $reg['headertrigger']; ?></span></td>
					<td   style="display:none"><span type="hidden" id="cuerpo_trigger<?php echo $reg['idtrigger']; ?>"><?php echo $reg['bodytrigger']; ?></span></td>
					<td   style="display:none"><span type="hidden" id="databasename<?php echo $reg['idtrigger']; ?>"><?php echo $reg['databasename']; ?></span></td>

					<?php 
						if($reg['login'] == $_SESSION['login'])
						{
							$result = pg_query("select distinct(idtrigger) as idtrigger from mutations"); 
							$array = array();
							while($row = pg_fetch_array($result, null, PGSQL_ASSOC))
							{
								$array[] = $row['idtrigger'];
							}
							
							
					?>
					<td width="10%" style="height: 43px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:12px;">
						<!--<button type="button" class="btn btn-link edit" value="< ?php echo $reg['idtrigger']; ?>"><span class="glyphicon glyphicon-edit"></span></button>-->
						
						
						
						<a class="btn btn-link"  style="padding:1px" title="Edit" data-emp-id="<?php echo $reg["idtrigger"]; ?>" href="show_trigger.php?id=<?php echo $reg['idtrigger'];  ?>"><i class="glyphicon glyphicon-edit"></i></a>
						
						<?php 
						if (in_array($reg["idtrigger"], $array)) {
										
										
						}
						else{
							?>
						<a class="btn btn-link delete" style="padding:1px" data-emp-id="<?php echo $reg["idtrigger"]; ?>" data-nombre-id="<?php echo $reg["name"]; ?>" href="javascript:void(0)"><i class="glyphicon glyphicon-trash"></i></a>
						
						<?php
						
						}
						?>
					</td>
					<?php
						}
					?>
				</tr>
<!--				//FIN-->
				

				<?php
			}
			?>
			</tbody>
		</table>
		<div class="table-pagination pull-right">
			<?php echo paginate($reload, $page, $total_pages, $adjacents);?>
		</div>
		
			<?php
			
		} else {
			?>
			<div class="alert alert-warning alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4>Aviso!!!</h4> No hay datos para mostrar
            </div>
			<?php
		}
	}
?>
