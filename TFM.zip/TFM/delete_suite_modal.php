<?php
session_start(); //Iniciamos o Continuamos la sesion
//include_once("db_connect.php");
//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
$conexion = pg_connect($_SESSION['conexion']);

if($_REQUEST['suiteid']) {
	
	$deleteTestSuite = 'delete from test_suites where idsuite = '.$_REQUEST['suiteid'].'';
	//echo $deleteTestSuite;
	pg_query($deleteTestSuite);
	echo '<br>';
	$deleteTest = 'delete from tests where idtest in ('.$_REQUEST['suiteid'].')';
	//echo $deleteTest;
	//pg_query($deleteTest);

	//$deleteSuite = 'delete from suites where idsuite = '.$_REQUEST['suiteid'].'';
	//pg_query($deleteSuite);

	
	
	
	
	$sql = "DELETE FROM suites WHERE idsuite='".$_REQUEST['suiteid']."'";
	$resultset = pg_query($conexion, $sql) or die("database error:". pg_last_error($conn));	
	if($resultset) {
		echo "Record Deleted";
	}
}
?>
