<?php
session_start();
	//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
	$conexion = pg_connect($_SESSION['conexion']);
	
	echo $_SESSION['login'];
	$compartirinfo = 'true';
	$compartirinfoNO = 'false';
	
	if (isset($_POST["info"])) {
   //echo $_POST["info"];
   $sql = "update users set compartirinfo = '$compartirinfo' where login='".$_SESSION['login']."'; ";
	//$query=pg_query($con,"select * from triggers");
	
	} else {
		$sql = "update users set compartirinfo = '$compartirinfoNO' where login='".$_SESSION['login']."'; ";
	}
	pg_query($conexion,$sql);
	
	//echo $sql;
	
	header('location: perfil.php');	
	
	
?>