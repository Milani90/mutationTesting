<?php
$mutantes = substr_count($copia, 'OR');
//echo "Nº mutantes posibles333: ", substr_count($copia, 'OLD'); 


for ($cont = 1; $cont <= $mutantes; $cont++){  
  if($cont === 1){
///      echo '<br>';
     
      
      $encuentraOR = 'OR';
      $posicion = strpos($copia, $encuentraOR);
     
     

      
      $trozo = substr ( $copia , 0 , $posicion + 3  );
      $resto = substr ( $copia , $posicion + 3  );
      
      
     

///  echo '<br>';
  $cambiado = str_replace("OR", "AND", $trozo);
  

  $mutanteOper9 = $cambiado .= $resto; 
  if($contador == 0){
		$contador = 1;
	  }
///	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br>';
      //echo 'MUTANTE: ',$contador,'<br>', $mutanteOper1, '<br><br><br><br>';
///	  echo $mutanteOper1, '<br>';
///	  echo '</span>';
	  //INICIO INSERT MUTANTE

      
      
      		// Create connection

$conexion = pg_connect($_SESSION['conexion']);
// Check connection

//Trigger
			$encuentraCreateTrigger = 'CREATE TRIGGER';
            $posCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
///            echo '<br>';
            

            $restoo = substr ( $trigger , $posCreateTrigger+14  );
            
           
            $auxiliar = explode(" ", $restoo);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
	
	
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			

			
//FIN TRIGGER

//FUNCION

           
            $encuentraFunction = 'FUNCTION';
            $posicionFunction = strpos($copia, $encuentraFunction);

            $restoFunction = substr ( $copia , $posicionFunction + 8  );
            //echo $resto2;
            
            $nombreFunction = explode(" ", $restoFunction);  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			$search = $nombreTrigger;
			
			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			
			
			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper9);
			
			ECHO '<br>';
			ECHO '<br>';
			
           echo 'FUNCTION MUTANTE: ', $functionMutante;
             ECHO '<br>';
			 ECHO '<br>';
            //fin funcion

//FIN FUNCION

			

//FIN CUERPOS

	//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE

	   $mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerOriginal','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');";
	   //$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerMutante','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');";
	   
//pg_query($conexion,$mutante);


$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}

//TABLA CRISTIAN
$res = pg_query("SELECT nextval('mutations_idmutation_seq') as id");
		$row = pg_fetch_array($res, 0);
		$mutationSecuencia = trim($row["id"]) + 1;
			
	//	echo 'SECUENCIA BUCLE ELSE: ', $mutationSecuencia;
		echo '<TR>';
		echo '   <TD style="text-align: center">CNO</TD>';
		echo '   <TD style="text-align: center">'.$mutationSecuencia.'</TD>';
		echo '	 <TD style="text-align: center">FUNCTION</TD>';
		echo '   <TD>'.$triggerMutanteActualizado.'<br>'.$functionMutante.'</TD>';
		echo '   <TD>Replace OR BY AND</TD>';
		echo '</TR>';
//FIN TABLA CRISTIAN



pg_close($conexion);
	
	  
	  
	  //FIN INSERT MUTANTE

 }
  else{
      
      
      $encuentraOR = 'OR';
      $posicion = strpos($mutanteOper1, $encuentraOR, $posicion);
            $contenidoarchivo = substr ( $copia , 0 , $posicion);
      
      
      
      $resto = substr ( $mutanteOper9 , $posicion );    
      $or = 'OR';
      $and = 'AND';
      $cambio1 = preg_replace('/OR/', $and, $resto, 1);
      
///      echo '<br>';
      $mutanteOper9 = $contenidoarchivo.$cambio1; 
      if($contador == 0){
		$contador = 1;
	  }
///	  	echo '<span style="font-weight: bold;">MUTANTE:',$contador,'</span><br>';
//	  echo $mutanteOper1, '<br>';
///	  echo '</span>';

	  
        		// Create connection

$conexion = pg_connect($_SESSION['conexion']);

//Trigger
			$encuentraCreateTrigger = 'CREATE TRIGGER';
            $posicionCreateTrigger = strpos($mutanteOper9, $encuentraCreateTrigger);
///            echo '<br>';
            

            $restoCreateTrigger = substr ( $mutanteOper9 , $posicionCreateTrigger+14  );
            
           
            $aux3 = explode(" ", $restoCreateTrigger);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			

		
			
			
//FIN TRIGGER

//FUNCION
 //funcion
           
            $encuentraFunction = 'FUNCTION';
            $posicionFunction = strpos($contenidoarchivo, $encuentraFunction);

            $restoFunction = substr ( $contenidoarchivo , $posicionFunction + 8  );

            
            $nombreFunction = explode(" ", $restoFunction);  
		
            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
	
			
			$search = $nombreTrigger;
			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper9);
			
ECHO '<br>';
			ECHO '<br>';
			
           echo 'FUNCTION MUTANTE: ', $functionMutante;
             ECHO '<br>';
			 ECHO '<br>';

//FIN FUNCION

	//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE
 
	      $mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerOriginal','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');";
		  //$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent) VALUES ('$nombreTriggerMutante','$nomFunctionActualizado', '$triggerMutanteActualizado', '$functionMutante','$login','$triggerid','$oper','false');";
		  
	   
$result = pg_query($conexion, $mutante);
if (!$result) {
  echo "Ocurrió un error.\n";
  exit;
}

//TABLA CRISTIAN
$res = pg_query("SELECT nextval('mutations_idmutation_seq') as id");
		$row = pg_fetch_array($res, 0);
		$mutationSecuencia = trim($row["id"]) + 1;
			
	//	echo 'SECUENCIA BUCLE ELSE: ', $mutationSecuencia;
		echo '<TR>';
		echo '   <TD style="text-align: center">CLO</TD>';
		echo '   <TD style="text-align: center">'.$mutationSecuencia.'</TD>';
		echo '	 <TD style="text-align: center">FUNCTION</TD>';
		echo '   <TD>'.$trigger.'<br>'.$functionMutante.'</TD>';
		echo '   <TD>Replace OR BY AND</TD>';
		echo '</TR>';
//FIN TABLA CRISTIAN

pg_close($conexion);
//fin conexion
      

      

    }
}//FIN ALGORITMO
?>