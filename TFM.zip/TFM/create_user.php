<?php
session_start(); //Iniciamos o Continuamos la sesion
//Definimos la codificación de la cabecera.
header('Content-Type: text/html; charset=utf-8');
//Importamos el archivo con las validaciones.
//require_once 'funciones/validaciones.php';

//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
$conexion = pg_connect($_SESSION['conexion']);


//Guarda los valores de los campos en variables, siempre y cuando se haya enviado el formulario, sino se guardará null.
$login = isset($_POST['email']) ? $_POST['email'] : null;
//$login = isset($_POST['login']) ? $_POST['login'] : null;
$password = isset($_POST['password']) ? $_POST['password'] : null;
$password2 = isset($_POST['password2']) ? $_POST['password2'] : null;

//Este array guardará los errores de validación que surjan.
$errores = array();

//$usuarios = array();

//$sqlUsuarios = "select login from users";
//$usuarios= pg_query($sql);

//echo $usuarios;


	$res = pg_query("SELECT * from users");
	while ($reg = pg_fetch_array($res, null, PGSQL_ASSOC)) {
		
		$usu = trim($reg["login"]);
		//echo $suiteSecuencia;
		//echo '<br>';
		$usuarios[] = $usu;
		
	}
	$_SESSION['usuarios'] = $usuarios; 

function validaEmail($valor){
        if(filter_var($valor, FILTER_VALIDATE_EMAIL) === FALSE){
            return false;
        }else{
            return true;
        }
    }

function validaUsuario($valor){
	$usuarios = array();
    $res = pg_query("SELECT * from users");
	while ($reg = pg_fetch_array($res, null, PGSQL_ASSOC)) {
		
		$usu = trim($reg["login"]);
		//echo $suiteSecuencia;
		//echo '<br>';
		$usuarios[] = $usu;
		
	}
	
	//$resultado = in_array($valor, $usuarios);
	if(in_array($valor, $usuarios))
	//if($resultado == 1)
	{
		return false;
	}
	else
	{
		return true;
	}
	
	
	
}
	
	
	
	
	
	


function validaPassword($valor1,$valor2){
		if($valor1 == $valor2)
		{
            return true;
        }else{
			return false;
        }
}



//Pregunta si está llegando una petición por POST, lo que significa que el usuario envió el formulario.
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    //Valida que el campo email sea correcto.
    if (!validaEmail($login)) {
        $errores[] = 'Email is incorrect.';
    }
	//Valida que el campo email sea correcto.
    if (!validaPassword($password,$password2)) {
		$errores[] = 'Passwords do not match.';
	}
	//Comprueba que no exista el usuario en la base de datos.
    if (!validaUsuario($login)) {
		$errores[] = 'User already registered';
	}
	
	
    //Verifica si ha encontrado errores y de no haber redirige a la página con el mensaje de que pasó la validación.
    if(!$errores){
		
		//INICIO
		




//$login = $_POST['email']; 
//$password = $_POST['password']; 

 if(isset($_POST['shareInfo']))
 {
	$shareInfo = $_POST['shareInfo']; 	 
 }
 else{
	$shareInfo = "";
 }


if ($shareInfo == 'yes')
{
	$shareInfo = 'true';
}
else
{
	$shareInfo = 'false';
}




$sql = "insert into users(login,password,compartirinfo) values ('$login', '$password','$shareInfo')";
 
//Ejecutamos la consulta
$res = pg_query($sql) or die('Query failed: ' . pg_last_error());
 
//echo "Usuario insertado correctamente";
 
//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
pg_free_result($res);
 
//Cerramos la conexión
pg_close($conexion);
		
		
		
		//FIN
		
        header('Location: login.php');
        
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<!-- Custom styles for this template -->
  <link href="css/create_user.css" rel="stylesheet">


<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

</head>
<body>
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

    <!-- Icon -->
  

    <!-- Login Form -->
    <!--<form action="add_user.php" method="post">-->
	<form action="create_user.php" method="post">
					<div class="modal-header">						
						<h4 class="modal-title">Create New User</h4>
					</div>
					
					<div class="modal-body">					
						<div class="form-group">
							<label>Email</label>
							<input type="email" name="email" class="form-control" value="<?php echo $login ?>"  required>
						</div>
						<div class="form-group">
							<label>Password</label>
							<input type="password" name="password" class="form-control"   required>
						</div>
						<div class="form-group">
							<label>Repeat Password</label>
							<input type="password" name="password2" class="form-control"   required>
						</div>
						<div>
						Share information<br>
						<input type="checkbox" name="shareInfo" value="yes">
						</div>
						
					</div>
			<?php if ($errores): ?>
            <ul style="color: #f00;">
                <?php foreach ($errores as $error): ?>
                    <?php echo $error ?>
					<?php echo '<br>' ?>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
					<div class="modal-footer">
						<input type="button" class="btn izquierda" data-dismiss="modal" value="Cancel" onClick="location.href='login.php'" >
						<input type="submit" class="btn derecha" style="margin-right:1px" value="Create" >
					</div>
	</form>

  </div>
</div>



</body>

</html>
