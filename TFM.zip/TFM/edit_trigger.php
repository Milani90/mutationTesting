<?php
	session_start();
	$conexion = pg_connect($_SESSION['conexion']);
	

 //Activamos todas las notificaciones de error posibles
  error_reporting (E_ALL);

  //Definimos el tratamiento de errores no controlados
  set_error_handler(function () 
  {
    throw new Exception("Error");
  });
  
    function LogDeErrores($numeroDeError, $descripcion, $fichero, $linea, $contexto){
	  echo '<br>';
   error_log("Error: [".$numeroDeError."] ".$descripcion." ".$fichero." ".$linea." ".json_encode($contexto)." \n\r", 3, "log_errores.txt");
   $error = explode ("ERROR:", $descripcion);
   $_SESSION['descripcionErrorTrigger'] = $error[1];
   throw new Exception("Error");
  }
  set_error_handler("LogDeErrores");


	//Recuperamos el id modificado al hacer click 


	$nombre=$_POST['enombre'];
	
	$descripcion=$_POST['edescripcion'];
	

	$cuerpo_trigger = $_POST['ecuerpo_trigger'];
	
	$funcion_trigger= $_POST['efuncion_trigger'];
	

	$idtrigger = $_SESSION['idTrigger'];
	
	
	
	$triggerFunctionValido = false;

	$triggerFunctionEsc = pg_escape_string($funcion_trigger);
	$triggerFunctionEsc = str_replace('"','\'', $triggerFunctionEsc);
	



//INICIO
try 
  {


$triggerFunctionIns = pg_query($triggerFunctionEsc);





if($triggerFunctionIns){
	
	$triggerFunctionValido = true;
	echo " Correct inserting function";
}
else
{
	echo " Error inserting function";
}

  
$triggerHeaderValido = false;


$triggerHeaderEsc = pg_escape_string($cuerpo_trigger);
$triggerHeaderEsc = str_replace('"','\'',$triggerHeaderEsc);



$triggerHeaderIns = pg_query($triggerHeaderEsc);

if($triggerHeaderIns){
	
	
	$triggerHeaderValido = true;
	echo " Correct inserting trigger";
}
else
{
	echo " Error inserting trigger";
}



if($triggerFunctionValido == true && $triggerHeaderValido == true){

	 pg_connect($_SESSION['conexion']);


	$sql = "update triggers set name='$nombre', description='$descripcion', headertrigger='$triggerHeaderIns', bodytrigger='$triggerFunctionIns' where idtrigger='$idtrigger'" ;
	
//Ejecutamos la consulta

$res = pg_query($sql);


  
  if($res)
  {
	  //ELIMINAMOS EL TRIGGER CREADO
	$host = "host=127.0.0.1 ";
	$port = "port=5432 ";
	$dbname = "dbname=" . $_POST['databaseName'];
	$user = " user=postgres ";
	$password = "password=root";
	$confConexion = $host . $port . $dbname .$user . $password;
	

$nombreFunction= explode(" ", $triggerFunctionIns);
$nomFunction = $nombreFunction[2];
$deleteFunction = "drop function ".$nomFunction."cascade;";

	echo "Trigger insertado correctamente";
//	header('location: triggers.php');
  }
  else{
	echo "Error critico";
//	header('location: error_trigger.php'); 
	//echo die('La consulta fallo: ' . pg_last_error());
  }
  
 
//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
pg_free_result($res);
 
} 
  }
  catch(Exception $e) //capturamos un posible error
  {
    //mostramos el texto del error al usuario	  
    echo "Error al insertar el trigger." . PHP_EOL;
	echo "Revise el código." . PHP_EOL;
	
	
	header('location: error_trigger.php'); 
  }
  


  //Restablecemos el tratamiento de errores
  restore_error_handler();



//FIN

	//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
	pg_free_result($sql);
	 
	//Cerramos la conexión
	pg_close($conexion);

//	header('Location: triggers.php');
?>