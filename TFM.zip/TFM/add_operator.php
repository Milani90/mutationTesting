<?php
session_start(); //Iniciamos o Continuamos la sesion
if (isset($_SESSION['login'])) //Si llego un Nickname via el formulario lo grabamos en la Sesion
{
 
}
else{
	 header('location: login.php');
}


//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
$conexion = pg_connect($_SESSION['conexion']);



//$nombre = $_POST['nombre_operador']; 
//$cuerpo_operador = $_POST['cuerpo_operador']; 
$nombre = $_POST['name']; 
$description = $_POST['description']; 
$code = $_POST['code']; 
$owner = $_SESSION['login'];

									//nombre,descripcion,cuerpo_trigger,funcion_trigger,idtrigger,usuario
//$sql = "insert into operadores(nombre,descripcion,cuerpo_trigger,funcion_trigger,usuario) values ('$triggerName', '$description','$triggerHeader', '$triggerFunction' ,'$usuario')";
//$sql = "insert into operadores(nombre,cuerpo) values ('$nombre', '$cuerpo_operador')";
$sql = "insert into operators(name,description,code,owner) values ('$nombre','$description', '$code', '$owner')";

 
//Ejecutamos la consulta
$res = pg_query($sql) or die('La consulta fallo: ' . pg_last_error());
 
echo "Operador insertado correctamente";
 
//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
pg_free_result($res);
 
//Cerramos la conexión
pg_close($conexion);
header('location: lista_operadores.php');
?>