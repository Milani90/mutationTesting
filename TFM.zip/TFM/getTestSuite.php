<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Manage Tests</title>
  <script src="https://code.jquery.com/jquery-1.9.1.js"></script>
  <!-- Bootstrap core CSS -->


  <!-- Custom fonts for this template -->


  <!-- Custom styles for this template -->
  
  <!-- PROPIOS DE LOS LISTADOS -->




		<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>-->



    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>-->


<!--nnuevos -->



</head>
<style>
table {
  width: 100%;
  border-collapse: collapse;
}

table, td, th {
  border: 1px solid black;
  padding: 5px;
}

th {text-align: left;}
</style>
</head>
<body>

<?php
//$_SESSION['idListadoSuite'] = intval($_SESSION['idListadoSuite']);
$id = intval($_GET['idSuite']);

//$con = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
$con = pg_connect($_SESSION['conexion']);

if (!$con) {
  die('Could not connect: ' . pg_last_error($con));
}

//$sql="select * from tests where idtest in (select distinct(ts.idtest) from test_suites ts where ts.idsuite = '".$q."')" ;
$sql="select * from tests where idtest in (select distinct(ts.idtest) from test_suites ts where ts.idsuite = '".$id."')" ;
//echo 'CONSULTAAAAAAAAA: ', $sql;
$result = pg_query($con,$sql);
?>
<table>
<tr>
<th><input type="checkbox" id="MarcarTodos" /> TEST</th>


</tr>
<?php
while($row = pg_fetch_array($result)) {

?>
  <tr>
	<td>
  <!--<input type='checkbox' name='test' id='test' value="< ?php echo $row["test"] ?>" /> -->
 
  <!--<input type="checkbox" name="test" value="< ?php echo $row['idtest']; ?>"><span>< ?php echo $row['test'] ?></span>-->
  <input type="checkbox" id="testListado" name="testsTabla[]" value="<?php echo $row['idtest']; ?>"> <label for="testListado"><?php echo $row['test'] ?></label>
    
  </td>
  </tr>
<?php  
}
?>
</table>
<?php
pg_close($con);
?>
<script >
      $('document').ready(function () {
   $("#MarcarTodos").change(function () {
      //$("input:checkbox").prop('checked', $(this).prop("checked"));
	  alert("esto es una prueba");
   });
});
</script>  
<script src="dist/js/bootstrap.min.js"></script> 
</body>
</html>