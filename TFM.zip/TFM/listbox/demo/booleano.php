<?php
session_start(); 
$mutanteKill = false;

$aux = true;
/*
if($mutanteKill)
{
echo 'ES FALSO';

}
ELSE{
echo 'ES TRUE';

}

$bool = true;
if (!$bool) {
    $hi = 'Hello to all people!';
	echo $hi;	
}
else
{
	echo 'BUCLE ELSE';
}
*/
	$host = $_SESSION['host'];
			$port = $_SESSION['port'];
			$dbname = "dbname=bdpruebas";
			$user = $_SESSION['user'];
			$password = $_SESSION['passConf'];
$confConexion = $host ." ". $port ." ". $dbname ." " .$user ." ". $password;
		$conexionTablas =	pg_connect($confConexion);		
$conexionMutante = pg_connect($confConexion);
$tablas = pg_query($conexionMutante,"select tablename as table from pg_tables where schemaname = 'public' and tablename not like 'backup_%' and tablename not like 'bdtrigger_%';");
//while ($listaTablas = pg_fetch_array($tablas, null, PGSQL_ASSOC) and !$mutanteKill) {
	while ($listaTablas = pg_fetch_array($tablas, null, PGSQL_ASSOC)) {
	$nombreTabla = $listaTablas['table'];
									echo '<br>';
									echo '<br>';
									echo $nombreTabla;
									/*
									if($nombreTabla == 'employees')
									{
										echo 'TABLA EMPLOYEES';
										
										$datos2 ="select * from ".$nombreTabla."";
										$tablaEmp2 = pg_query($conexionMutante, $datos2);
										while ($tab2 = pg_fetch_array($tablaEmp2, null, PGSQL_ASSOC))
										{
											$salario = $tab2['salary'];
											echo '<BR>';
											echo 'SALARIO000000: ', $salario;
											
										}		
										
										
									}
									*/
									
									
}

?>