	<?php
session_start(); //Iniciamos o Continuamos la sesion
if (isset($_POST['login'])) //Si llego un Nickname via el formulario lo grabamos en la Sesion
{
	$_SESSION['login'] = $_POST['login']; 
}
if ($_SESSION['login']) //Si hay un nickname en la sesion actual, creamos una variable que será mostrada
{
	
	
}
/*
  //Activamos todas las notificaciones de error posibles
  error_reporting (E_ALL);

  //Definimos el tratamiento de errores no controlados
  set_error_handler(function () 
  {
    throw new Exception("Error");
  });
*/


//try{

//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
$conexion = pg_connect($_SESSION['conexion']);


	$usuario = $_SESSION['login'];
	//echo 'USUARIO: ', $usuario ;
	
//$acronym = $_POST['id']; 
$description = pg_escape_string($_SESSION['description']); 
echo 'DESCRIPTION', $description;

echo '<br>';

 // $description = $_SESSION['description'];

$databasename = pg_escape_string($_SESSION['databaseName']); 
echo 'DATABASENAME: ',$databasename;

echo '<br>';

//$databasename = $_SESSION['databasename'] ;
//echo 'NOMBRE DE BASE DE DATOS: ', $databasename;

echo "TEST: ", $_SESSION['newTest'];

echo '<br>';

$tests = pg_escape_string($_SESSION['newTest']); 
$test = explode(";", $tests);


//saco el numero de elementos
$longitud = count($test);


//INICIO
			
			$res = pg_query("SELECT nextval('suites_idsuite_seq') as id");
			$row = pg_fetch_array($res, 0);
			$suiteSecuencia = trim($row["id"]);
			
			echo 'SECUENCIA SUITE: ', $suiteSecuencia;
			echo '<br>';
			
			
//FIN




$sql = "insert into suites(idsuite, description,login,databasename) values ($suiteSecuencia,'$description','$usuario', '$databasename')";


//Ejecutamos la consulta
$res = pg_query($sql) or die('La consulta fallo: ' . pg_last_error());
 
//echo "Suite insertada correctamente";
 
//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
pg_free_result($res);


			






//Recorro todos los elementos
for($i=0; $i<$longitud-1; $i++)
{
		  
			
			
			//INICIO
			
			$secuenciaTest = pg_query("SELECT nextval('tests_idtest_seq') as id");
			$row = pg_fetch_array($secuenciaTest, 0);
			$testSecuencia = trim($row["id"]);
			
			echo 'SECUENCIA TEST: ', $testSecuencia;
			echo '<br>';
		
		  
		  
      //saco el valor de cada elemento	
	  $testInd = $test[$i];
	  	$testInd = rtrim($testInd);
		
	//	$testInd = pg_escape_string($testInd); 
	//	$testInd = str_replace('"','\'', $testInd);
		
		
	  $sqlTest = "insert into tests(idtest,test,databasename) values ( $testSecuencia,'$testInd', '$databasename')";
	  echo 'INSERT INTO TESTS: ', $sqlTest;
	  //$resTest = pg_query($sqlTest); or die('La consulta fallo: ' . pg_last_error());
	  $resTest = pg_query($sqlTest);
	  pg_free_result($resTest);
	  
	  //TABLA TEST_SUITES
	  
		$sqlTestSuite = "insert into test_suites values ($suiteSecuencia, $testSecuencia)";
		$testSuite = pg_query($sqlTestSuite);
	  
	  
}





 
//Cerramos la conexión
pg_close($conexion);
header('location: suites.php');
//}
/*
 catch(Exception $e) //capturamos un posible error
  {
    //mostramos el texto del error al usuario	  
    echo "errorrrrr." . PHP_EOL;
	//die('El test es erroneo, revisalo: ' . $php_errormsg);
    
	
	//header('Location: error_add_tests.php');
  }
*/




?>