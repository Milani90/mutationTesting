<?php
session_start();
								//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
								$conexion = pg_connect($_SESSION['conexion']);
								
								
								
								//Recuperamos el id modificado al hacer click 
								$idoper =$_POST['idoper'];
    
								$nombre=$_POST['nombre'];
								$descripcion=$_POST['descripcion'];
								$codigo = $_POST['codigo'];
								
								/*
								$contador = "select max(idoper) from operadores";
								$numContador = pg_query ($conexion, $contador;
								$numContador = $numContador + 1;
								*/
								
								//$consulta = "select idtrigger from triggers where nombre='$nombre' and descripcion = '$descripcion'";
								//pg_query ($conexion, $consulta);
								
								
								//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
								//pg_free_result($res);
								
								$sql = "update operadores set nombre='$nombre', descripcion='$descripcion', codigo='$codigo' where idoper='$idoper'" ;
								//$sql = "update triggers set nombre='$nombre', descripcion='$descripcion', cuerpo_trigger='$cuerpo_trigger', funcion_trigger='$cuerpo_trigger' where idtrigger='$idtrigger'" ;
								pg_query ($conexion, $sql);

								//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
								pg_free_result($res);
								 
								//Cerramos la conexión
								pg_close($conexion);
								
								header('Location: lista_operadores.php');
								?>