<?php

session_start(); //Iniciamos o Continuamos la sesion
$conexion = pg_connect($_SESSION['conexion']);
$id=$_POST['id'];
$_SESSION['idListadoSuite'] = $id;


$array = array();

$sql = 'SELECT test FROM tests where idtest in (select ts.idtest from test_suites ts where ts.idsuite  = '.$id.')';
//$sql="select * from cliente where status!=2";
//$result=pg_query($conexion, $sql);
$result = pg_query($sql);

while($fila=pg_fetch_array($result,null, PGSQL_ASSOC)){ 	
	$array[] = array(
        "id" => $fila['test']
        
    );
}


$resultado=json_encode($array);

echo $resultado;

	
						
									//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
							//	pg_free_result($result);
								 
								//Cerramos la conexión
							//	pg_close($conexion);
						
								
?>