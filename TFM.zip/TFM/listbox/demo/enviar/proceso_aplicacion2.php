<TABLE BORDER="1" style="width:100%">
<TR>
   <TH style="text-align:center">IDMUTANTE</TH>
   <TH style="text-align:center">FUNCTION/TRIGGER</TH>
   <TH style="text-align:center">OPERADOR</TH>
   <!--<TH style="text-align:center">MUTANT TRIGGER</TH>-->
   <TH style="text-align:center">CHANGE</TH>
</TR>
<!--
<TR>
   <TD>Dato 1</TD>
   <TD>Dato 2</TD>
   <TD>Dato 3</TD>
   <TD>Dato 4</TD>
</TR>
-->



<?php
  //set_time_limit(30);
  
//session_start();
echo '<div style="margin-left: 30px;">';
$conexion = pg_connect($_SESSION['conexion']);

pg_set_client_encoding($conexion, "UNICODE");



$login = $_SESSION['login'];

$triggerid = $_POST['trigger'];
$_SESSION['triggerElegido'] =  $_POST['trigger'];
$contador = 1; 

//echo 'TRIGGER: ', $triggerid;
//echo '<br>';
$consulta = "select * from triggers where idtrigger = '".$triggerid."'";
//echo 'CONSULTA:', $consulta;
//echo '<br>';

$consultaTriggerId = pg_query($conexion,$consulta)  or die('La consulta fallo: ' . pg_last_error());

while ($reg = pg_fetch_array($consultaTriggerId, null, PGSQL_ASSOC)) {
	$function = $reg['bodytrigger'];

	$trigger = $reg['headertrigger'];
	  
    $trigger = preg_replace("[\n|\r|\n\r|\t]", " ", $trigger);
	
	$array = explode(' ',$trigger);  // convierte en array separa por espacios;
    $salida ='';
    // quita los campos vacios y pone un solo espacio
    for ($i=0; $i < count($array); $i++) { 
        if(strlen($array[$i])>0) {
            $salida.= ' ' . $array[$i];
        }
    }
  $trigger=trim($salida);
}

echo '<hr style=" border-top: 1px solid blue; width: 750px;">';

		echo $trigger; 
		echo '<br>';
		echo '<br>';
		echo $function;	
		$original=$function;	

		echo '<hr style=" border-top: 1px solid blue; width: 750px;">';


$copia = $function;


//$valor = $_POST['operador'];  
//$operadores = $_POST['duallistbox_demo2'];  
$operadores = $_POST['to'];  
$_SESSION['operadoresElegidos'] = $_POST['to'];  

//comprobamos si estan esos triggers antes de crearlos

///echo 'COMPROBAMOS MUTANTES ANTES DE CREARLOS: ';
///echo '<br>';
$consultaOperadores = "select * from mutations where idtrigger = '".$triggerid."';";
$listaOperadores = pg_query($consultaOperadores);
$arrayoper = array();

	
$existeOperador1 = false;
	$sqlOperadores = "";	

while ($compruebaOper = pg_fetch_array($listaOperadores, null, PGSQL_ASSOC)) {
//$arrayoper = $compruebaOper['idoperator'];
array_push($arrayoper, $compruebaOper['idoperator']);

}
foreach($operadores as $oper){
	
	if($sqlOperadores == "")
	{
			$sqlOperadores = $oper;
	}	
	else	
	{
			$sqlOperadores = $sqlOperadores.','.$oper;
	}
	//abrimos conexion
	$conexion = pg_connect($_SESSION['conexion']);
	
	$consulta = "select * from mutations where idtrigger = '".$triggerid."' and idoperator = '".$oper."'";
	
	$filasAfectadas = pg_query($consulta);
	$rows = pg_num_rows($filasAfectadas);
	
	
	if($rows == 0)
	{

		if($oper == 1  ) //Para cada operador 
		{
	
			
			$hayInsert = substr_count(strtolower($trigger), strtolower('INSERT'));
			$hayUpdate = substr_count(strtolower($trigger), strtolower('UPDATE'));
			$hayDelete = substr_count(strtolower($trigger), strtolower('DELETE'));
			//SI HAY UPDATE Y NO INSERT Y UPDATE NO SE APLICA
			if($hayUpdate > 0 && $hayInsert == 0 && $hayDelete == 0 )
			{


					//INICIO ALGORITMO
					
				$mutantesNEW = substr_count(strtolower($copia), strtolower('NEW.'));

				$mutanteOper1 = "";
				$mutaciones = $function;
				

				for ($cont = 1; $cont <= $mutantesNEW; $cont++){  
				  
				  
				 
					  $encuentraNew = strtolower('NEW.');
					  $posicion = strpos(strtolower($mutaciones), $encuentraNew);
					
					  $contenidoarchivo = substr ( strtolower($copia) , 0 , $posicion);
					  
					
					 
					  $resto = substr ( $mutaciones , $posicion );    
			

					  $old = strtolower('OLD.');
					  $cambio1 = preg_replace(strtolower('/NEW./'), $old, strtolower($resto), 1);
					  $mutaciones = preg_replace(strtolower('/NEW./'), $old, strtolower($mutaciones), 1);
					  

					  $mutanteOper1 = $contenidoarchivo.$cambio1; 
					

        		// Create connection

				///	$conexion = pg_connect($_SESSION['conexion']);

	

				//Trigger

					$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
					$posicionCreateTrigger = strpos(strtolower($trigger), strtolower($encuentraCreateTrigger));

					$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
           
					$aux3 = explode(" ", $restoCreateTrigger);  
            
					$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);	
					$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
				//FIN TRIGGER

				//FUNCION
				 //CAMBIO OR REPLACE

				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos(strtolower($copia), strtolower($encuentra));

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
				 
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos(strtolower($copia), strtolower($encuentraFunction));
						$restoFunction = substr (strtolower($copia) , $posicionFunction + 19  );
				} else {
				 
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos(strtolower($copia), strtolower($encuentraFunction));
					 $restoFunction = substr ( strtolower($copia) , $posicionFunction + 8  );
					
				}
				//FIN CAMBIO OR REPLACE
			
					
					$nFunction = explode(" ", $restoFunction);  

					$nombreFuncion = str_replace('$', '' ,$nFunction[1]);
					
					
					$search = $nombreFuncion;
					
					$tamNombre = strlen($search);
					$nomFuncion = substr ( $nombreFuncion , 0, $tamNombre - 2);
					$nomFunctionActualizado = $nomFuncion . '_' .$contador . '()';
					
					$functionMutante = str_ireplace($nombreFuncion , $nomFunctionActualizado, $mutanteOper1);
			
			//FIN FUNCION

			//INICIO
					$triggerActualizado = str_ireplace($nombreFuncion , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
			//FIN NOMBRE
 		

				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change,type ) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper1','$login','$triggerid','$oper','false', 'Replace NEW BY OLD', 'FUNCTION');";
		  
		  
	   
					$result = pg_query($conexion, $mutante);
					if (!$result) {
					  echo "Ocurrió un error.\n";
					  exit;
					}
							

				//	pg_close($conexion);
					//fin conexion
				
				  //}
				  //fin else del new__
				  
				  
				}
				
				
				
			//inicio old
			$mutanteOper1 = "";
			$mutaciones = $function;

			//INICIO ALGORITMO
			$mutantesOLD = substr_count(strtolower($copia), strtolower('OLD.'));
			

			for ($cont = 1; $cont <= $mutantesOLD; $cont++){  
			 
	
		  $encuentraOld = strtolower('OLD.');
		  $posicion = strpos(strtolower($mutaciones), $encuentraOld);
		  
		  
		  $contenidoarchivo = substr ( strtolower($copia) , 0 , $posicion);
		
      
		  $resto = substr ( strtolower($mutaciones) , $posicion );    
		  $new = strtolower('NEW.');
		  $old = strtolower('OLD.');
		  $cambio1 = preg_replace(strtolower('/OLD./'), $new, strtolower($resto), 1);
		  $mutaciones = preg_replace(strtolower('/OLD./'), $new, strtolower($mutaciones), 1);
		  
			$mutanteOper1 = $contenidoarchivo.$cambio1; 
			

       		// Create connection

		///	$conexion = pg_connect($_SESSION['conexion']);

			//Trigger
		
			$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
            $posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

            $restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
           
            $aux3 = explode(" ", $restoCreateTrigger);  
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			
			//FIN TRIGGER

			//FUNCION
			 //CAMBIO OR REPLACE

			$restoFunction = "";
			$encuentra = 'OR REPLACE FUNCTION';
			$pos = strpos(strtolower($copia), strtolower($encuentra));

			// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
			if ($pos === false) {
				$encuentraFunction = 'OR REPLACE FUNCTION';
				
				$posicionFunction = strpos(strtolower($copia), strtolower($encuentraFunction));
					$restoFunction = substr ( strtolower($copia) , $posicionFunction + 19  );
			} else {
				$encuentraFunction = 'FUNCTION';
				
				$posicionFunction = strpos(strtolower($copia), strtolower($encuentraFunction));
				 $restoFunction = substr ( strtolower($copia) , $posicionFunction + 8  );
				
			}
			//FIN CAMBIO OR REPLACE
		
            $nFunction = explode(" ", $restoFunction);  
            $nombreFuncion = str_replace('$', '' ,$nFunction[1]);

			
			$search = $nombreFuncion;
			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreFuncion , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			$functionMutante = str_ireplace($nombreFuncion , $nomFunctionActualizado, $mutanteOper1);
			


			//FIN FUNCION

			//INICIO
					$triggerActualizado = str_ireplace($nombreFuncion , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
			//FIN NOMBRE
					

	      $mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$trigger', '$mutanteOper1','$login','$triggerid','$oper','false', 'Replace OLD BY NEW', 'FUNCTION');";
		  
	   
			$result = pg_query($conexion, $mutante);
			if (!$result) {
			  echo "Ocurrió un error.\n";
			  exit;
			}
		


		///	pg_close($conexion);
			//fin conexion
			//}
		}//fin bucle reemplazo old
				}//FIN UPDATE Y NO INSERT Y UPDATE NO SE APLICA
				
			}//fin operador1
			//INICIO OPERADOR2
			//INICIO OPERADOR 2 - ADD OPERACION
			if($oper == 2)
			{
				
				//nombres de triggers y funciones 
				//Trigger
			
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				$posicionCreateTrigger = strpos(strtolower($trigger), strtolower($encuentraCreateTrigger));

				$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
							   
				$aux3 = explode(" ", $restoCreateTrigger);  
								
				$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			
				//FIN TRIGGER

				//FUNCION
				//CAMBIO OR REPLACE

				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {				
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					 $restoFunction = substr ( $copia , $posicionFunction + 8  );
				}
				//FIN CAMBIO OR REPLACE

            
				$nFunction = explode(" ", $restoFunction);  
			
				$nombreFuncion = str_replace('$', '' ,$nFunction[1]);
			
				//fin funcion
				//fin nombres triggers y funciones
				
				
				
				//inicio 
				
				$mutantesINSERT = substr_count(strtolower($trigger), strtolower(' INSERT '));
				$mutantesUPDATE = substr_count(strtolower($trigger), strtolower(' UPDATE '));
				$mutantesDELETE = substr_count(strtolower($trigger), strtolower(' DELETE '));
								
				$posicionON = strpos(strtolower($trigger), strtolower(" ON "));
				$cabecera = substr(strtolower($trigger), 0, $posicionON );
				$resto = substr(strtolower($trigger), $posicionON+1);
				
				if($mutantesINSERT + $mutantesUPDATE + $mutantesDELETE < 3)
				{
					
					
					if($mutantesINSERT == 0){
						$mutanteOper2 = $cabecera." or insert ".$resto;
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper2', '$function','$login','$triggerid','$oper','false', 'ADD INSERT clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
					}
					if($mutantesDELETE == 0){
						$mutanteOper2 = $cabecera." or delete ".$resto;
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper2', '$function','$login','$triggerid','$oper','false', 'ADD DELETE clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
					}
					if($mutantesUPDATE == 0)
					{
						$mutanteOper2 = $cabecera." or update ".$resto;
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper2', '$function','$login','$triggerid','$oper','false', 'ADD UPDATE clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
					}
					
				}		
					
				
			
				
				
				//fin
	
			}//FIN OPERADOR2 -ADD OPERATION
			
			//INICIO OPERADOR3
			//INICIO OPERADOR 3
			if($oper == 3)
			{
				//nombres de triggers y funciones 
				//Trigger
			
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				$posicionCreateTrigger = strpos(strtolower($trigger), strtolower($encuentraCreateTrigger));

				$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
							   
				$aux3 = explode(" ", $restoCreateTrigger);  
								
				$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			
				//FIN TRIGGER

				//FUNCION
				//CAMBIO OR REPLACE

				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {				
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					 $restoFunction = substr ( $copia , $posicionFunction + 8  );
				}
				//FIN CAMBIO OR REPLACE

            
				$nFunction = explode(" ", $restoFunction);  
			
				$nombreFuncion = str_replace('$', '' ,$nFunction[1]);
			
				//fin funcion
				//fin nombres triggers y funciones
				
				$mutantesINSERT = substr_count(strtolower($trigger), strtolower(' INSERT '));
				$mutantesUPDATE = substr_count(strtolower($trigger), strtolower(' UPDATE '));
				$mutantesDELETE = substr_count(strtolower($trigger), strtolower(' DELETE '));
				
				$posicionON = strpos(strtolower($trigger), strtolower(' ON '));
				$posicionOR = strpos(strtolower(substr($trigger,0,$posicionON)), strtolower(" OR "));
				
				
				
				if($mutantesINSERT + $mutantesUPDATE + $mutantesDELETE > 1)
				{
					$posicionTimeAfter = strpos(strtolower($trigger), strtolower(" AFTER "));
					$posicionTimeBefore = strpos(strtolower($trigger), strtolower(" BEFORE "));
					
					
					
					if($posicionTimeAfter == false)
					{
						$mutanteOper3 = substr_replace ( $trigger ," " , $posicionTimeBefore+ 7,  $posicionOR + 3 - ($posicionTimeBefore+7));
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper3', '$function','$login','$triggerid','$oper','false', 'Delete event clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
					}
					else{
						$mutanteOper3 = substr_replace ( $trigger ," " , $posicionTimeAfter +6,  $posicionOR + 3 - ($posicionTimeAfter+6));
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper3', '$function','$login','$triggerid','$oper','false', 'Delete event clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
					}
					
					
					if($mutantesINSERT + $mutantesUPDATE + $mutantesDELETE == 2)
					{
						$posicionFinal = strpos(strtolower($trigger), strtolower(" ON "), $posicionOR + 4);
						$mutanteOper3 = substr_replace ( $trigger ," " , $posicionOR,  $posicionFinal - $posicionOR);
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper3', '$function','$login','$triggerid','$oper','false', 'Delete event clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
					}
					else{
						$posicionOR2 = strpos(substr(strtolower($trigger), 0, $posicionON), strtolower(" OR "), $posicionOR+4);
						$mutanteOper3 = substr_replace ( $trigger ," " , $posicionOR,  $posicionOR2 - $posicionOR);
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper3', '$function','$login','$triggerid','$oper','false', 'Delete event clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
						
						$posicionFinal = strpos(strtolower($trigger), strtolower(" ON "), $posicionOR2 + 4 );
						$mutanteOper3 = substr_replace ( $trigger ," " , $posicionOR2,  $posicionFinal - $posicionOR2);
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper3', '$function','$login','$triggerid','$oper','false', 'Delete event clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
					}
							
					}
					
				}
			
			
			}//INICIO OPERADOR4
			
			if($oper == 4)
			{
				
				//nombres de triggers y funciones 
				//Trigger
			
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				$posicionCreateTrigger = strpos(strtolower($trigger), strtolower($encuentraCreateTrigger));

				$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
							   
				$aux3 = explode(" ", $restoCreateTrigger);  
								
				$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			
				//FIN TRIGGER

				//FUNCION
				//CAMBIO OR REPLACE

				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {				
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					 $restoFunction = substr ( $copia , $posicionFunction + 8  );
				}
				//FIN CAMBIO OR REPLACE

            
				$nFunction = explode(" ", $restoFunction);  
			
				$nombreFuncion = str_replace('$', '' ,$nFunction[1]);
			
				//fin funcion
				//fin nombres triggers y funciones
				
				//inicio 
				$mutantesINSERT = substr_count(strtolower($trigger), strtolower(' INSERT '));
				$mutantesUPDATE = substr_count(strtolower($trigger), strtolower(' UPDATE '));
				$mutantesDELETE = substr_count(strtolower($trigger), strtolower(' DELETE '));
				
				$posicionON = strpos(strtolower($trigger), strtolower(" ON "));
				$posicionOR = strpos(strtolower(substr($trigger,0,$posicionON)), strtolower(" OR "));
				
				
				if($mutantesINSERT + $mutantesUPDATE + $mutantesDELETE < 3)
				{
					$posicionTimeAfter = strpos(strtolower($trigger), strtolower("AFTER"));
					$posicionTimeBefore = strpos(strtolower($trigger), strtolower("BEFORE"));
					
					
					if($posicionOR == false)
					{
						
						if($posicionTimeAfter == true){
							$posicionInicio = $posicionTimeAfter+6;
							$posicionFinal = strpos(strtolower($trigger), strtolower(" ON "), $posicionInicio);
							
						}
						else{
							$posicionInicio = $posicionTimeBefore+7;
							$posicionFinal = strpos(strtolower($trigger), strtolower(" ON "), $posicionInicio);
						}
						$cadena = substr (strtolower($trigger) , $posicionInicio , $posicionFinal- $posicionInicio ) ;
						
						if(strncmp($cadena, strtolower("INSERT"), strlen("INSERT")) === 0) {
							$oper1 = "DELETE";
							$oper2 = "UPDATE";
						}
						else if(strncmp($cadena, strtolower("DELETE"), strlen("DELETE")) === 0){
							$oper1 = "INSERT";
							$oper2 = "UPDATE";
						}
						else
						{
							$oper1 = "INSERT";
							$oper2 = "DELETE";
						}
						
						
						$mutanteOper4 = substr_replace ( $trigger ,$oper1 , $posicionInicio,  $posicionFinal - $posicionInicio);
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper4', '$function','$login','$triggerid','$oper','false', 'REPLACE clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
						$mutanteOper4 = substr_replace ( $trigger ,$oper2 , $posicionInicio,  $posicionFinal - $posicionInicio);
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper4', '$function','$login','$triggerid','$oper','false', 'REPLACE clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
					}
					else{
						
						//INICIO
						$posicion = 0;
						if($posicionTimeAfter == true){
							$posicionInicio = $posicionTimeAfter+5;
							
							$posicionFinal1 = strpos(substr(strtolower($trigger),0,$posicionON), strtolower(" OR "), $posicionInicio);
							$posicionAccion1 = strpos(substr(strtolower($trigger),0,$posicionON), strtolower(" "), $posicionInicio+1);
							
						}
						else{
							$posicionInicio = $posicionTimeBefore+6;
							$posicionFinal1 = strpos(substr(strtolower($trigger),0,$posicionON), strtolower(" OR "), $posicionInicio);
							$posicionAccion1 = strpos(substr(strtolower($trigger),0,$posicionON), strtolower(" "), $posicionInicio+1);
						}
						
						$cadena1 = substr ( strtolower($trigger) , $posicionInicio+1 , $posicionFinal1 - $posicionInicio-1 ) ;
						$accion1 = substr ( strtolower($trigger) , $posicionInicio+1 , $posicionAccion1 - $posicionInicio-1 ) ;
						
						
						$posicionON = strpos(strtolower($trigger), strtolower(" ON "), $posicionFinal1);
						$posicionAccion2 = strpos(strtolower($trigger), strtolower(" "), $posicionFinal1+4);
						
						
						$cadena2 = substr ( strtolower($trigger) , $posicionFinal1+4 , $posicionON - $posicionFinal1-4 ) ;
						$accion2 = substr ( strtolower($trigger) , $posicionFinal1+4 , $posicionAccion2 - $posicionFinal1-4 ) ;
						
						$oper1 = "";
						
						
						
						if((strncmp($accion1, "insert", strlen("INSERT")) === 0)  and (strncmp($accion2, "delete", strlen("DELETE")) === 0 )) 
						{
							$oper1 = "UPDATE";
						}
						
						if ((strncmp($accion1, "delete", strlen("DELETE")) === 0)  and (strncmp($accion2, "insert", strlen("INSERT")) === 0 ))   {
							$oper1 = "UPDATE";
						}
						
						
						if((strncmp($accion1, "insert", strlen("INSERT")) === 0 ) and (strncmp($accion2, "update", strlen("UPDATE")) === 0 )) {
							$oper1 = "DELETE";
						}
						
						
						if ((strncmp($accion1, "update", strlen("UPDATE")) === 0)  and (strncmp($accion2, "insert", strlen("INSERT")) === 0 ))   {
					
							$oper1 = "DELETE";
						}
						
						
						if((strncmp($accion1, "update", strlen("UPDATE")) === 0)  and (strncmp($accion2, "delete", strlen("DELETE")) === 0 )) {
							$oper1 = "INSERT";
							
						}
						
						
						if((strncmp($accion1, "delete", strlen("delete")) === 0)  and (strncmp($accion2, "update", strlen("UPDATE")) === 0 ))  {
						
							$oper1 = "INSERT";
						}
						
						
						
						
						$mutanteOper4 = substr_replace ( $trigger ,$oper1 , $posicionInicio+1,  $posicionFinal1 - $posicionInicio-1);
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper4', '$function','$login','$triggerid','$oper','false', 'REPLACE clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
						$mutanteOper4 = substr_replace ( $trigger ,$oper1 , $posicionFinal1+4,  $posicionON - $posicionFinal1-4);
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper4', '$function','$login','$triggerid','$oper','false', 'REPLACE clause', 'TRIGGER');";		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
					
						//FIN
						
						
						
					}
				}
					
			}//FIN OPERADOR4
			
			//INICIO OPERADOR8
			
			
			if($oper == 8 )
			{
				$contadorOper8 = $contador;
				
				$existeOper8 = false;
				$existeOperador8 = true; //Variable que indica si es posible aplicar dicho operador
				$mutantesSuma = substr_count(strtolower($copia), '+');
				$mutantesResta = substr_count(strtolower($copia), '-');
				$mutantesMultiplicacion = 0;
				if(substr_count(strtolower($copia), '*')>0){
				if(substr_count(strtolower($copia), '*.')>0){
				
				}
				else{
					$mutantesMultiplicacion = substr_count(strtolower($copia), '*');
				}
				}
				$mutantesDivision = substr_count(strtolower($copia), '/');
			  
				$mutantesConjunto = ($mutantesSuma*3) + ($mutantesResta*3) + ($mutantesMultiplicacion*3) + ($mutantesDivision*3);
			
				if($mutantesConjunto == 0)
				{		
					$_SESSION['errorOper'] = 'RLREP';
					$operator8 = false;
					$existeOperador8 = false;
		
				}
				$reemplazos = substr_count($copia, '+');
		
				$original=$function;	
	
				//nombres de triggers y funciones 
				//Trigger
			
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

           
				$restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
				$aux3 = explode(" ", $restoCreateTrigger);  
            
            
				$nombreTriggerOriginalOper8 = str_replace('$', '' ,$aux3[1]);
			
				//FIN TRIGGER

				//FUNCION
				//CAMBIO OR REPLACE

				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					$restoFunction = substr ( $copia , $posicionFunction + 8  );
					
				}
				//FIN CAMBIO OR REPLACE
			
				$nFunction = explode(" ", $restoFunction);  
				$nombreFuncionOper8 = str_replace('$', '' ,$nFunction[1]);
				
				//fin funcion
  
  
				//fin nombres triggers y funciones
				//INICIO ALGORITMO
	
	
				$numSuma = substr_count($copia, '+');

				if($numSuma > 0)
				{

					for ($contadorMutantes = 1; $contadorMutantes <= $numSuma; $contadorMutantes++)
					{  
					 
						if($contadorMutantes === 1)
						{

							   
							$encuentraMas = '+';
							$posicionMas = strpos($copia, $encuentraMas);
							 
							  
							$trozo = substr ( $copia , 0 , $posicionMas + 1  );
							$resto = substr ( $copia , $posicionMas + 1  );
							  
							$cambiado = str_replace("+", "-", $trozo);
						  

							$mutanteOper8 = $cambiado .= $resto; 
							if($contador == 0){
								$contador = 1;
							  }
							  
							//INICIO INSERT MUTANTE
							  
							$conexion = pg_connect($_SESSION['conexion']);


							//Trigger
							$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				
							$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
				
							$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
						   
							$auxiliar = explode(" ", $restoo);  
							
							$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
							
							$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
					
							//FIN TRIGGER

							//FUNCION
							//CAMBIO OR REPLACE

							$restoFunction = "";
							$encuentra = 'OR REPLACE FUNCTION';
							$pos = strpos($copia, $encuentra);

							// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
							if ($pos === false) {
								$encuentraFunction = 'OR REPLACE FUNCTION';
								
								$posicionFunction = strpos($copia, $encuentraFunction);
									$restoFunction = substr ( $copia , $posicionFunction + 19  );
							} else {
								$encuentraFunction = 'FUNCTION';
								
								$posicionFunction = strpos($copia, $encuentraFunction);
								 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							}
							//FIN CAMBIO OR REPLACE			

					
							$nombreFunction = explode(" ", $restoFunction);  
							
							$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
							
							$search = $nombreTrigger;

							$tamNombre = strlen($search);
							$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
							$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';			

							$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);			
							//FIN FUNCION

							//INICIO
									$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
									$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
							//FIN NOMBRE
					
						//COMPROBAMOS SI ESTA EL TRIGGER Y OPERADOR 
							//echo 'OPERADOR: ', $oper; echo '<br>';
							$consulta = "select * from mutations where idtrigger = '".$triggerid."' and idoperator = '".$oper."'";
							$filasAfectadas = pg_query($consulta);
							$rows = pg_num_rows($filasAfectadas);

							//echo $rows . " row(s) returned.\n"; echo '<br>';
							
							
							
								if($rows == $mutantesConjunto)
								{
									////echo 'ESTE OPERADOR Y ESTE TRIGGER YA SE HA UTILIZADO';
									$existeOper8 = true ;
								}
								else{

									$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$functionMutante','$login','$triggerid','$oper','false','Replace + BY -', 'FUNCTION');"; 
								
									$result = pg_query($conexion, $mutante);
									if (!$result) {
									  echo "Ocurrió un error.\n";
									  exit;
									}

								}
								pg_close($conexion);
							  //FIN INSERT MUTANTE
			  
						}
						else
						{
		  
						//INICIO + --> -
							$encuentraMas = '+';
							$posicionMas = strpos($mutanteOper8, $encuentraMas, $posicionMas);
							$function = substr ( $copia , 0 , $posicionMas);
							  
							  
							$resto = substr ( $mutanteOper8 , $posicionMas );    
							$mas = '+';
							$multiplicacion = '-';
							$cambio1 = preg_replace('/\+/', '-', $resto, 1);
							  
						
							$mutanteOper8 = $function.$cambio1; 
							  

							if($contador == 0){
								$contador = 1;
							}
							$contador = $contador + 1;
						

							// Create connection

							$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
							$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
							$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
							
							

							$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
							
						   
							$aux3 = explode(" ", $restoCreateTrigger);  
							
							
							$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
							$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
				

						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							
						}
						//FIN CAMBIO OR REPLACE
						
						$nombreFunction = explode(" ", $restoFunction);  
						
						$nombreTrigger = str_replace('$', '' ,isset($nombreFunction[1]) ? $nombreFunction[1] : null);
				
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
							
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);

						//FIN FUNCION


						//INICIO
							$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
							$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE
						
							$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$functionMutante','$login','$triggerid','$oper','false', 'Replace + BY -', 'FUNCTION');";
							
							$result = pg_query($conexion, $mutante);
							if (!$result) {
							  echo "Ocurrió un error.\n";
							  exit;
							}
			

							pg_close($conexion);
		
						//FIN + --> -

	  
						}//FIN DEL ELSE OPER1
	 
					}

					//MAS POR MULTIPLICACION 
					for ($contadorMutantes = 1; $contadorMutantes <= $numSuma; $contadorMutantes++)
					{  
					  if($contadorMutantes === 1)
					  {
					
						$encuentraMas = '+';
						$posicionMas = strpos($function, $encuentraMas);
						 
						  
						$trozo = substr ( $copia , 0 , $posicionMas + 1  );
						$resto = substr ( $copia , $posicionMas + 1  );
						  
						$cambiado = str_replace("+", "*", $trozo);
					  

						$mutanteOper8 = $cambiado .= $resto; 
						
						$contador = $contador + 1;
						  
						//INICIO INSERT MUTANTE
						  
						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
							$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
							$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
						
							$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
				
							$auxiliar = explode(" ", $restoo);  
							$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
							$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
				
						//FIN TRIGGER
		
						//FUNCION           
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
						}
						//FIN CAMBIO OR REPLACE
				
						$nombreFunction = explode(" ", $restoFunction);  

						
						$nombreTrigger = str_replace('$', '' ,isset($nombreFunction[1]) ? $nombreFunction[1] : null);
						
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
				
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);
				
						//FIN FUNCION

						//INICIO
								$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
								$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE
								
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$functionMutante','$login','$triggerid','$oper','false', 'Replace + BY *', 'FUNCTION');"; 
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
						pg_close($conexion);	
		  
						//FIN INSERT MUTANTE
					}
					else
					{
						//INICIO + --> -
						$encuentraMas = '+';
						$posicionMas = strpos($mutanteOper8, $encuentraMas, $posicionMas);
						$function = substr ( $copia , 0 , $posicionMas);
						  
						  
						$resto = substr ( $mutanteOper8 , $posicionMas );    
						$mas = '+';
						$multiplicacion = '*';
						 
						$cambio1 = preg_replace('/\+/', '*', $resto, 1);
						  
						$mutanteOper8 = $function.$cambio1; 
						if($contador == 0){
							$contador = 1;
						}
						$contador = $contador + 1;

						// Create connection

						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
						$encuentraCreateTrigger = 'CREATE TRIGGER';
						$posicionCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
			
						$restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
				
						$aux3 = explode(" ", $restoCreateTrigger);  
				
						$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
				
						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							
						}
						//FIN CAMBIO OR REPLACE
				
						$nombreFunction = explode(" ", $restoFunction);  
						$nombreTrigger = str_replace('$', '' ,isset($nombreFunction[1]) ? $nombreFunction[1] : null);
				
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';

						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);

						//FIN FUNCION

						//INICIO
							$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
							$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE

						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$functionMutante','$login','$triggerid','$oper','false','Replace + BY *', 'FUNCTION');";
											
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}

						pg_close($conexion);
		
						//FIN + --> -

					}//FIN DEL ELSE 
 
					}
//FIN MAS POR MULTIPLICACION

//INICIO MAS POR DIVISION 

				for ($contadorMutantes = 1; $contadorMutantes <= $numSuma; $contadorMutantes++)
				{   
					if($contadorMutantes === 1){
					 
						$encuentraMas = '+';
						$posicionMas = strpos($function, $encuentraMas);
					 
						$trozo = substr ( $copia , 0 , $posicionMas + 1  );
						$resto = substr ( $copia , $posicionMas + 1  );
					  
						$cambiado = str_replace("+", "/", $trozo);
				  
						$mutanteOper8 = $cambiado .= $resto; 
					
						$contador = $contador + 1;
	  
						//INICIO INSERT MUTANTE
	  
						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
							$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
							$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
							
							$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
						   
							$auxiliar = explode(" ", $restoo);  
							
							$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
							
							$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
														
						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							
						}
						//FIN CAMBIO OR REPLACE
			            
						$nombreFunction = explode(" ", $restoFunction);  

						$nombreTrigger = str_replace('$', '' ,isset($nombreFunction[1]) ? $nombreFunction[1] : null);
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);
			

						//FIN FUNCION

						//INICIO
								$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
								$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE
			

						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$functionMutante','$login','$triggerid','$oper','false','Replace + BY /', 'FUNCTION');"; 
		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}

						pg_close($conexion);
		 	 
						//FIN INSERT MUTANTE
	 
					}
					else{
      
						//INICIO + --> -
						$encuentraMas = '+';
						$posicionMas = strpos($mutanteOper8, $encuentraMas, $posicionMas);
						$function = substr ( $copia , 0 , $posicionMas);
						  
						  
						$resto = substr ( $mutanteOper8 , $posicionMas );    
						$mas = '+';
						$multiplicacion = '/';
						
						$cambio1 = preg_replace('/\+/', '/', $resto, 1);
						  
						$mutanteOper8 = $function.$cambio1; 
						if($contador == 0){
							$contador = 1;
						}
						else{
						$contador = $contador + 1;
						}

						// Create connection

						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
						$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

						$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
						$aux3 = explode(" ", $restoCreateTrigger);  
            
						$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							
						}
						//FIN CAMBIO OR REPLACE
            
						$nombreFunction = explode(" ", strtolower($restoFunction));  

						$nombreTrigger = str_replace('$', '' ,isset($nombreFunction[1]) ? $nombreFunction[1] : null);
						
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);

						//FIN FUNCION

						//INICIO
							$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
							$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE
	
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$functionMutante','$login','$triggerid','$oper','false','Replace + BY /', 'FUNCTION');";
		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}

						pg_close($conexion);
	
						//FIN + --> -
						}//FIN DEL ELSE
				}
				//FIN MAS POR DIVISION
				}//fin si hay algun MAS


				//OPERADOR MENOS 

				$numMenos = substr_count($function, '-');
				if($numMenos > 0){

				for ($contadorMutantes = 1; $contadorMutantes <= $numMenos; $contadorMutantes++)
				{  
					if($contadorMutantes === 1)
					{
					 					  
						$encuentraMenos = '-';
						$posicionMenos = strpos($function, $encuentraMenos);
					 
						$trozo = substr ( $function , 0 , $posicionMenos + 1  );
						$resto = substr ( $function , $posicionMenos + 1  );
					 					  
						$cambiado = str_replace("-", "+", $trozo);
				  
						$mutanteOper8 = $cambiado .= $resto; 
						if($contador == 0){
							$contador = 1;
						  }

	  
						//INICIO INSERT MUTANTE
	  
						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');

						$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

						$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );							
					   
						$auxiliar = explode(" ", strtolower($restoo));  
						
						$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
							
						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							
						}
						//FIN CAMBIO OR REPLACE
								
						$nombreFunction = explode(" ", strtolower($restoFunction));  
						
						$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
						
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
						
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);

						//FIN FUNCION

						//INICIO
							$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
							$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE
					
				
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$functionMutante','$login','$triggerid','$oper','false', 'Replace - BY +', 'FUNCTION');"; 
				
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
				
						pg_close($conexion);
			
						//FIN INSERT MUTANTE
					}
					else{
      
					//INICIO - --> +
						$encuentraMenos = '-';
						$posicionMenos = strpos($mutanteOper8, $encuentraMenos, $posicionMenos);
						$function = substr ( $copia , 0 , $posicionMenos);
						  
						  
						$resto = substr ( $mutanteOper8 , $posicionMenos );    
						$mas = '+';
						$menos = '-';
						$cambio1 = preg_replace('/-/', '+', $resto, 1);
      
						$mutanteOper8 = $function.$cambio1; 
  					    if($contador == 0){
							$contador = 1;
						}
						$contador = $contador + 1;

						// Create connection

						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
						$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
        
						$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
						$aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
						$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							
						}
						//FIN CAMBIO OR REPLACE
			            
						$nombreFunction = explode(" ", strtolower($restoFunction));  

						$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
						
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);

						//FIN FUNCION

						//INICIO
							$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
							$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE

						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$functionMutante','$login','$triggerid','$oper','false','Replace - BY +', 'FUNCTION');";
						
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
		 	
						pg_close($conexion);
	
						//FIN + --> -
						}//FIN DEL ELSE
				}
				//MENOS POR MULTIPLICACION
				for ($contadorMutantes = 1; $contadorMutantes <= $numMenos; $contadorMutantes++)
				{  
				 
					if($contadorMutantes === 1)
					{
				
						$encuentraMenos = '-';
						$posicionMenos = strpos($copia, $encuentraMenos);
					 
						$trozo = substr ( $copia , 0 , $posicionMenos + 1  );
						$resto = substr ( $copia , $posicionMenos + 1  );
					  
						$cambiado = str_replace("-", "*", $trozo);
				  
						$mutanteOper8 = $cambiado .= $resto; 
					
						$contador = $contador + 1;
				
					  //INICIO INSERT MUTANTE
					  
						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
						$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
						
						$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );

						$auxiliar = explode(" ", strtolower($restoo));  

						$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);

						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;

						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							
						}
						//FIN CAMBIO OR REPLACE
			
						$nombreFunction = explode(" ", $restoFunction);  
						$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);
			
						//FIN FUNCION

						//INICIO
								$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
								$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE
			
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$functionMutante','$login','$triggerid','$oper','false','Replace - BY *', 'FUNCTION');"; 
						
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
						pg_close($conexion);
						  
						//FIN INSERT MUTANTE
	 
					}
					else
					{
      
						//INICIO + --> -
						$encuentraMenos = '-';
						$posicionMenos = strpos($mutanteOper8, $encuentraMenos, $posicionMenos);
						$function = substr ( $copia , 0 , $posicionMenos);
					  
					  
						$resto = substr ( $mutanteOper8 , $posicionMenos );    
						$menos = '-';
						$multiplicacion = '*';
					  
						$cambio1 = preg_replace('/-/', '*', $resto, 1);
					  
						$mutanteOper8 = $function.$cambio1; 
						if($contador == 0){
							$contador = 1;
						}
						$contador = $contador + 1;
			
						// Create connection

						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
						$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

						$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
						   
						$aux3 = explode(" ", strtolower($restoCreateTrigger));  
							
						$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
						
						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
						}
						//FIN CAMBIO OR REPLACE
									
				
						$nombreFunction = explode(" ", $restoFunction);  

						$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
				
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
						
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);

						//FIN FUNCION

						//INICIO
						$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
						$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE
		
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8','$trigger', '$functionMutante','$login','$triggerid','$oper','false','Replace - BY *', 'FUNCTION');";
						
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						pg_close($conexion);
		
						//FIN + --> -
					}//FIN DEL ELSE
 
				}
				//FIN MAS POR MULTIPLICACION

				//INICIO MENOS POR DIVISION
				for ($contadorMutantes = 1; $contadorMutantes <= $numMenos; $contadorMutantes++)
				{  
					if($contadorMutantes === 1)
					{
					 
						$encuentraMenos = '-';
						$posicionMenos = strpos($copia, $encuentraMenos);
		 
		  
						$trozo = substr ( strtolower($copia) , 0 , $posicionMenos + 1  );
						$resto = substr ( strtolower($copia) , $posicionMenos + 1  );
		  
						$cambiado = str_replace("-", "/", $trozo);
	  
						$mutanteOper8 = $cambiado .= $resto; 
		
						$contador = $contador + 1;
			  
						//INICIO INSERT MUTANTE
		  
						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');            
						$posCreateTrigger = strpos($trigger, $encuentraCreateTrigger);

						$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
				
						$auxiliar = explode(" ", $restoo);  
					
						$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
				
						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
				
						//FIN TRIGGER

						//FUNCION           
						//CAMBIO OR REPLACE
						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
						}
						//FIN CAMBIO OR REPLACE

						$nombreFunction = explode(" ",strtolower($restoFunction));  
						
						$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';

						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);
									
						//FIN FUNCION

						//INICIO
								$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
								$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE
				
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$functionMutante','$login','$triggerid','$oper','false','Replace - BY /', 'FUNCTION');"; 
					
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
			
						pg_close($conexion);
						//FIN INSERT MUTANTE
	  
					}
					else{
      
						//INICIO + --> -
						$encuentraMenos = '-';
						$posicionMenos = strpos($mutanteOper8, $encuentraMenos, $posicionMenos);
						$function = substr ( $copia , 0 , $posicionMenos);
						  
						  
						$resto = substr ( $mutanteOper8 , $posicionMenos );    
						$menos = '-';
						$multiplicacion = '/';
						$cambio1 = preg_replace('/-/', '/', $resto, 1);
						  
					
						$mutanteOper8 = $function.$cambio1; 
						if($contador == 0){
							$contador = 1;
						}
						$contador = $contador + 1;
				

						// Create connection

						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
						$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

						$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
						
					   
						$aux3 = explode(" ", $restoCreateTrigger);  
						
						$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
							
						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE
						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							
						}
						//FIN CAMBIO OR REPLACE
						
						$nombreFunction = explode(" ", strtolower($restoFunction));  

						$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
						

						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
						
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);

						//FIN FUNCION

						//INICIO
							$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
							$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE

	
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$functionMutante','$login','$triggerid','$oper','false','Replace - BY /', 'FUNCTION');";
						
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}

						pg_close($conexion);
	
						//FIN + --> -
						}//FIN DEL ELSE
				}
				//FIN MENOS POR DIVISION
				}//fin si hay algun MENOS
		//FIN OPERADOR MENOS 

		//INICIO OPERADOR MULTIPLICACION 

		$numMultiplicacion = substr_count($function, '*');
		if($numMultiplicacion > 0)
		{

		for ($contadorMutantes = 1; $contadorMutantes <= $numMultiplicacion; $contadorMutantes++)
		{  
			if($contadorMutantes === 1)
			{
			 
			  $encuentraMultiplicacion = '*';
			  $posicionMultiplicacion = strpos($function, $encuentraMultiplicacion);
			 
			  
			  $trozo = substr ( $function , 0 , $posicionMultiplicacion + 1  );
			  $resto = substr ( $function , $posicionMultiplicacion + 1  );
			  
			  $cambiado = str_replace("*", "+", $trozo);
		  

			$mutanteOper8 = $cambiado .= $resto; 
			if($contador == 0){
				$contador = 1;
			}
		
		    //INICIO INSERT MUTANTE
			  
			$conexion = pg_connect($_SESSION['conexion']);

			//Trigger
			$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
			$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
            
            $restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
            
            $auxiliar = explode(" ", strtolower($restoo));  
            
            $nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
			
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
			//FIN TRIGGER

			//FUNCION
            //CAMBIO OR REPLACE
			$restoFunction = "";
			$encuentra = 'OR REPLACE FUNCTION';
			$pos = strpos($copia, $encuentra);

			// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
			if ($pos === false) {
				$encuentraFunction = 'OR REPLACE FUNCTION';
				
				$posicionFunction = strpos($copia, $encuentraFunction);
					$restoFunction = substr ( $copia , $posicionFunction + 19  );
			} else {
				$encuentraFunction = 'FUNCTION';
				
				$posicionFunction = strpos($copia, $encuentraFunction);
				 $restoFunction = substr ( $copia , $posicionFunction + 8  );
			}
			//FIN CAMBIO OR REPLACE


            $nombreFunction = explode(" ", strtolower($restoFunction));  
			
            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);
			
			//FIN FUNCION
			
			//INICIO	
				$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
				$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
			//FIN NOMBRE
			
			$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$functionMutante','$login','$triggerid','$oper','false','Replace * BY +', 'FUNCTION');"; 
				
			$result = pg_query($conexion, $mutante);
			if (!$result) {
			  echo "Ocurrió un error.\n";
			  exit;
			}
		
			pg_close($conexion);
	
			//FIN INSERT MUTANTE
			}
			else
			{
      
			//INICIO * --> +
				$encuentraMultiplicacion = '*';
				$posicionMultiplicacion = strpos($mutanteOper8, $encuentraMultiplicacion, $posicionMultiplicacion);
				$function = substr ( $copia , 0 , $posicionMultiplicacion);
				  
				  
				$resto = substr ( $mutanteOper8 , $posicionMultiplicacion );    
				$multiplicacion = '*';
				$menos = '-';
				$cambio1 = preg_replace('/\*/', '+', $resto, 1);
				  
				$mutanteOper8 = $function.$cambio1; 
				if($contador == 0){
					$contador = 1;
				}
				$contador = $contador + 1;
			
				// Create connection

					$conexion = pg_connect($_SESSION['conexion']);

				//Trigger
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
	
				$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
				$aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
				$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
				$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
				
				//FIN TRIGGER

				//FUNCION

				//CAMBIO OR REPLACE
				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					 $restoFunction = substr ( $copia , $posicionFunction + 8  );
					
				}
				//FIN CAMBIO OR REPLACE
			
            
				$nombreFunction = explode(" ", strtolower($restoFunction));  

				$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
				$search = $nombreTrigger;

				$tamNombre = strlen($search);
				$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
				$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
				
				

				$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);

				//FIN FUNCION

				//INICIO
					$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
				//FIN NOMBRE
	
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false','Replace * BY +', 'FUNCTION');";
	
				$result = pg_query($conexion, $mutante);
				if (!$result) {
					echo "Ocurrió un error.\n";
					exit;
				}

				pg_close($conexion);
	
				//FIN + --> -
			}//FIN DEL ELSE
		}

		//MULTIPLICACION POR MENOS
		for ($contadorMutantes = 1; $contadorMutantes <= $numMultiplicacion; $contadorMutantes++)
		{  
			if($contadorMutantes === 1)
			{  
				$encuentraMultiplicacion = '*';
				$posicionMultiplicacion = strpos($function, $encuentraMultiplicacion);
			 			  
				$trozo = substr ( $copia , 0 , $posicionMultiplicacion + 1  );
				$resto = substr ( $copia , $posicionMultiplicacion + 1  );
			  
				$cambiado = str_replace("*", "-", $trozo);
		  
				$mutanteOper8 = $cambiado .= $resto; 
			
				$contador = $contador + 1;
	
	  
				//INICIO INSERT MUTANTE
	  
				$conexion = pg_connect($_SESSION['conexion']);


				//Trigger
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');

				$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

				$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
				
				$auxiliar = explode(" ", strtolower($restoo));  
				
				$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
				
				$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
				
				//FIN TRIGGER
			
				//FUNCION           
				//CAMBIO OR REPLACE
				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
					$encuentraFunction = 'OR REPLACE FUNCTION';
	
					$posicionFunction = strpos($copia, $encuentraFunction);
					$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
    
					$encuentraFunction = 'FUNCTION';
					$posicionFunction = strpos($copia, $encuentraFunction);
					$restoFunction = substr ( $copia , $posicionFunction + 8  );    
				}			
				//FIN CAMBIO OR REPLACE

				$nombreFunction = explode(" ", strtolower($restoFunction));  

			
				$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
				$search = $nombreTrigger;

				$tamNombre = strlen($search);
				$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
				$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
				$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);
			
				//FIN FUNCION

				//INICIO
						$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
						$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
				//FIN NOMBRE
						
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace * BY -','FUNCTION');"; 

				$result = pg_query($conexion, $mutante);
				if (!$result) {
				  echo "Ocurrió un error.\n";
				  exit;
				}

				pg_close($conexion);
				//FIN INSERT MUTANTE	 
			}
		else{
      
				//INICIO * --> -
				$encuentraMultiplicacion = '*';
				$posicionMultiplicacion = strpos($mutanteOper8, $encuentraMultiplicacion, $posicionMultiplicacion);
				$function = substr ( $copia , 0 , $posicionMultiplicacion);
				  
				  
				$resto = substr ( $mutanteOper8 , $posicionMultiplicacion );    
				$menos = '-';
				$multiplicacion = '*';
				$cambio1 = preg_replace('/\*/', '-', $resto, 1);
				  
				$mutanteOper8 = $function.$cambio1; 
				if($contador == 0){
					$contador = 1;
				}
				  $contador = $contador + 1;

				// Create connection
				$conexion = pg_connect($_SESSION['conexion']);

				//Trigger
				$encuentraCreateTrigger = 'CREATE TRIGGER';
				$posicionCreateTrigger = strpos($trigger, $encuentraCreateTrigger);

				$restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
            
				$aux3 = explode(" ", $restoCreateTrigger);  
            
				$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
				$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
				//FIN TRIGGER

				//FUNCION
				//CAMBIO OR REPLACE
				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {					
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					 $restoFunction = substr ( $copia , $posicionFunction + 8  );
					
				}
				//FIN CAMBIO OR REPLACE
			
            
				$nombreFunction = explode(" ", strtolower($restoFunction));  

				$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
				
				
				$search = $nombreTrigger;

				$tamNombre = strlen($search);
				$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
				$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
				
				$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);

				//FIN FUNCION
				
				//INICIO
					$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
				//FIN NOMBRE

				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false','Replace * BY -','FUNCTION');";
			
				$result = pg_query($conexion, $mutante);
				if (!$result) {
				  echo "Ocurrió un error.\n";
				  exit;
				}
				pg_close($conexion);
				//FIN + --> -
			}//FIN DEL ELSE
		}
		//FIN MAS POR MULTIPLICACION

		//INICIO MULTIPLICACION POR DIVISION
		for ($contadorMutantes = 1; $contadorMutantes <= $numMultiplicacion; $contadorMutantes++)
		{  
			if($contadorMutantes === 1)
			{
			 
				$encuentraMultiplicacion = '*';
				$posicionMultiplicacion = strpos(strtolower($copia), $encuentraMultiplicacion);
			  
				$trozo = substr ( strtolower($copia) , 0 , $posicionMultiplicacion + 1  );
				$resto = substr ( strtolower($copia) , $posicionMultiplicacion + 1  );
			  
				$cambiado = str_replace("*", "/", $trozo);
		  
				$mutanteOper8 = $cambiado .= $resto; 
			
				$contador = $contador + 1;
			  
				//INICIO INSERT MUTANTE
			  
				$conexion = pg_connect($_SESSION['conexion']);

				//Trigger
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

				$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
            
				$auxiliar = explode(" ", strtolower($restoo));  
                        
				$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
			
				$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
				//FIN TRIGGER

				//FUNCION
				//CAMBIO OR REPLACE
				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					 $restoFunction = substr ( $copia , $posicionFunction + 8  );
				}
				//FIN CAMBIO OR REPLACE

				$nombreFunction = explode(" ", strtolower($restoFunction));  

				
				$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
				
				$search = $nombreTrigger;

				$tamNombre = strlen($search);
				$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
				$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
				$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);
			

				//FIN FUNCION

				//INICIO
					$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
				//FIN NOMBRE
				
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace * BY /','FUNCTION');"; 
				
				$result = pg_query($conexion, $mutante);
				if (!$result) {
				  echo "Ocurrió un error.\n";
				  exit;
				}
				
				pg_close($conexion);
			}
			else{
      
					//INICIO * --> /
					$encuentraMultiplicacion = '*';
					$posicionMultiplicacion = strpos($mutanteOper8, $encuentraMultiplicacion, $posicionMultiplicacion);
					$function = substr ( $copia , 0 , $posicionMultiplicacion);
					  
					  
					$resto = substr ( $mutanteOper8 , $posicionMultiplicacion );    
					$menos = '-';
					$multiplicacion = '/';
					$cambio1 = preg_replace('/\*/', '/', $resto, 1);
					  
					$mutanteOper8 = $function.$cambio1; 
					if($contador == 0){
						$contador = 1;
					}
					$contador = $contador + 1;

					// Create connection

					$conexion = pg_connect($_SESSION['conexion']);
					//Trigger
					$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
					$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

					$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
					$aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
					$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
					$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
					
			
					//FIN TRIGGER

					//FUNCION
					//CAMBIO OR REPLACE	
					$restoFunction = "";
					$encuentra = 'OR REPLACE FUNCTION';
					$pos = strpos($copia, $encuentra);

					// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
					if ($pos === false) {
						$encuentraFunction = 'OR REPLACE FUNCTION';
						
						$posicionFunction = strpos($copia, $encuentraFunction);
							$restoFunction = substr ( $copia , $posicionFunction + 19  );
					} else {
						$encuentraFunction = 'FUNCTION';
						
						$posicionFunction = strpos($copia, $encuentraFunction);
						 $restoFunction = substr ( $copia , $posicionFunction + 8  );
						
					}
					//FIN CAMBIO OR REPLACE           
            
					$nombreFunction = explode(" ", strtolower($restoFunction));  

					$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
		
					$search = $nombreTrigger;
		
					$tamNombre = strlen($search);
					$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
					$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
					$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);

					//FIN FUNCION

					//INICIO
						$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
						$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
					//FIN NOMBRE


					$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace * BY /', 'FUNCTION');";
		
					$result = pg_query($conexion, $mutante);
					if (!$result) {
					  echo "Ocurrió un error.\n";
					  exit;
					}
					
					pg_close($conexion);
	
					//FIN + --> -
				}//FIN DEL ELSE 
		}
		//FIN MULTIPLICACION POR DIVISION
		}//fin si hay algun MULTIPLICACION

		//FIN OPERADOR MULTIPLICACION

		//INICIO OPERADOR DIVISION
		$numDivision = substr_count($function, '/');
		if($numDivision > 0)
		{

			for ($contadorMutantes = 1; $contadorMutantes <= $numDivision; $contadorMutantes++)
			{  
 
				if($contadorMutantes === 1){

					$encuentraDivision = '/';
					$posicionDivision = strpos($copia, $encuentraDivision);
     
					$trozo = substr ( $copia , 0 , $posicionDivision + 1  );
					$resto = substr ( $copia , $posicionDivision + 1  );
      
					$cambiado = str_replace("/", "+", $trozo);
 
					$mutanteOper8 = $cambiado .= $resto; 
	
					if($contador == 0){
						$contador = 1;
					}
	  
		$conexion = pg_connect($_SESSION['conexion']);

		//Trigger
		$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
		$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

        $restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
            
        $auxiliar = explode(" ", strtolower($restoo));  
            
        $nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
			
		$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			

		//FIN TRIGGER

		//FUNCION
        //CAMBIO OR REPLACE

		$restoFunction = "";
		$encuentra = 'OR REPLACE FUNCTION';
		$pos = strpos($copia, $encuentra);

		// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
		if ($pos === false) {
			$encuentraFunction = 'OR REPLACE FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
				$restoFunction = substr ( $copia , $posicionFunction + 19  );
		} else {
			$encuentraFunction = 'FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
			 $restoFunction = substr ( $copia , $posicionFunction + 8  );
			
		}
		//FIN CAMBIO OR REPLACE
			
            
            $nombreFunction = explode(" ", strtolower($restoFunction));  
			
            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);
			
		//FIN FUNCION

		//INICIO
				$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
				$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
		//FIN NOMBRE
			



		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace / BY +', 'FUNCTION');"; 

		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
		pg_close($conexion);
	  //FIN INSERT MUTANTE
	}
	else
	{
      
		//INICIO / --> +
		$encuentraDivision = '/';
		$posicionDivision = strpos($mutanteOper8, $encuentraDivision, $posicionDivision);
		$function = substr ( $copia , 0 , $posicionDivision);
      
      
		$resto = substr ( $mutanteOper8 , $posicionDivision );    
		$division = '/';
		$mas = '+';
		$cambio1 = preg_replace('/\//', '+', $resto, 1);
      
		$mutanteOper8 = $function.$cambio1; 
		if($contador == 0){
			$contador = 1;
		}
		$contador = $contador + 1;

		// Create connection

			$conexion = pg_connect($_SESSION['conexion']);

		//Trigger
			$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
            $posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

            $restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
           
            $aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
		
		//FIN TRIGGER

		//FUNCION
		//CAMBIO OR REPLACE

		$restoFunction = "";
		$encuentra = 'OR REPLACE FUNCTION';
		$pos = strpos($copia, $encuentra);

		// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
		if ($pos === false) {
			$encuentraFunction = 'OR REPLACE FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
				$restoFunction = substr ( $copia , $posicionFunction + 19  );
		} else {
			$encuentraFunction = 'FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
			 $restoFunction = substr ( $copia , $posicionFunction + 8  );
			
		}
		//FIN CAMBIO OR REPLACE
			
            
            $nombreFunction = explode(" ", strtolower($restoFunction));  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
		
			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);

		//FIN FUNCION

		//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
		//FIN NOMBRE

	
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace / BY +', 'FUNCTION');";

		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
	
		pg_close($conexion);
	
	//FIN / --> +
    }//FIN DEL ELSE
 
			}
			//DIVISION POR MENOS

			for ($contadorMutantes = 1; $contadorMutantes <= $numDivision; $contadorMutantes++){  
 
				if($contadorMutantes === 1){
     
      
					$encuentraDivision = '/';
					$posicionDivision = strpos($function, $encuentraDivision);
     
      
					$trozo = substr ( $copia , 0 , $posicionDivision + 1  );
					$resto = substr ( $copia , $posicionDivision + 1  );
	  
					$cambiado = str_replace("/", "-", $trozo);
 
					$mutanteOper8 = $cambiado .= $resto; 
	
					$contador = $contador + 1;
	  
					//INICIO INSERT MUTANTE
	  
					$conexion = pg_connect($_SESSION['conexion']);

					//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
						
						$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
						
						$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
					   
						$auxiliar = explode(" ",strtolower( $restoo));  
						
						$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
						
						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
								
					//FIN TRIGGER

					//FUNCION           
					//CAMBIO OR REPLACE	
					$restoFunction = "";
					$encuentra = 'OR REPLACE FUNCTION';
					$pos = strpos($copia, $encuentra);

					// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
					if ($pos === false) {
						$encuentraFunction = 'OR REPLACE FUNCTION';
						
						$posicionFunction = strpos($copia, $encuentraFunction);
							$restoFunction = substr ( $copia , $posicionFunction + 19  );
					} else {
						$encuentraFunction = 'FUNCTION';
						
						$posicionFunction = strpos($copia, $encuentraFunction);
						 $restoFunction = substr ( $copia , $posicionFunction + 8  );
					}
					//FIN CAMBIO OR REPLACE
          
            $nombreFunction = explode(" ", strtolower($restoFunction));  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);
			
			//FIN FUNCION

			//INICIO
					$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
			//FIN NOMBRE
					
	
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace / BY -', 'FUNCTION');"; 
		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
		
		pg_close($conexion);
	  
		//FIN INSERT MUTANTE
		}
		else{     
			//INICIO * --> -
			$encuentraDivision = '/';
			$posicionDivision = strpos($mutanteOper8, $encuentraDivision, $posicionDivision);
			$function = substr ( $copia , 0 , $posicionDivision);
			  
			  
			$resto = substr ( $mutanteOper8 , $posicionDivision );    
			$menos = '-';
			$division = '/';
			$cambio1 = preg_replace('/\//', '-', $resto, 1);
      
			$mutanteOper8 = $function.$cambio1; 
			if($contador == 0){
				$contador = 1;
			}
			$contador = $contador + 1;

			// Create connection

			$conexion = pg_connect($_SESSION['conexion']);

			//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
						$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
           

            $restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
            $aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
		//FIN TRIGGER

		//FUNCION
		//CAMBIO OR REPLACE

		$restoFunction = "";
		$encuentra = 'OR REPLACE FUNCTION';
		$pos = strpos($copia, $encuentra);

		// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
		if ($pos === false) {
			$encuentraFunction = 'OR REPLACE FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
				$restoFunction = substr ( $copia , $posicionFunction + 19  );
		} else {
			$encuentraFunction = 'FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
			 $restoFunction = substr ( $copia , $posicionFunction + 8  );
		}
		//FIN CAMBIO OR REPLACE
		
            $nombreFunction = explode(" ", strtolower($restoFunction));  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);

		//FIN FUNCION

		//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
		//FIN NOMBRE

	
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace / BY -', 'FUNCTION');";

		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
	

		pg_close($conexion);
	
		//FIN / --> -  
		}//FIN DEL ELSE OPER1
 
	}
	//FIN MAS POR MULTIPLICACION

	//INICIO DIVISION POR MULTIPLICACION 

	for ($contadorMutantes = 1; $contadorMutantes <= $numDivision; $contadorMutantes++)
	{  
		if($contadorMutantes === 1){
	      
			$encuentraDivision = '/';
			$posicionDivision = strpos($copia, $encuentraDivision);
		 
		  
			$trozo = substr ( strtolower($copia) , 0 , $posicionDivision + 1  );
			$resto = substr ( strtolower($copia) , $posicionDivision + 1  );
		 
			$cambiado = str_replace("/", "*", $trozo);
  

			$mutanteOper8 = $cambiado .= $resto; 
	
			$contador = $contador + 1;

	  
			//INICIO INSERT MUTANTE
			$conexion = pg_connect($_SESSION['conexion']);

			//Trigger
				$encuentraCreateTrigger = 'CREATE TRIGGER';            
				$posCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
           
				$restoo = substr ( $trigger , $posCreateTrigger+14  );
            
				$auxiliar = explode(" ", $restoo);  
            
				$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
			
				$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
			//FIN TRIGGER

			//FUNCION           
           //CAMBIO OR REPLACE

			$restoFunction = "";
			$encuentra = 'OR REPLACE FUNCTION';
			$pos = strpos($copia, $encuentra);

			// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
			if ($pos === false) {
				$encuentraFunction = 'OR REPLACE FUNCTION';
				
				$posicionFunction = strpos($copia, $encuentraFunction);
					$restoFunction = substr ( $copia , $posicionFunction + 19  );
			} else {
				$encuentraFunction = 'FUNCTION';
				
				$posicionFunction = strpos($copia, $encuentraFunction);
				 $restoFunction = substr ( $copia , $posicionFunction + 8  );
				
			}
			//FIN CAMBIO OR REPLACE

            
            $nombreFunction = explode(" ", strtolower($restoFunction));  
            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);
			

			//FIN FUNCION

			//INICIO
					$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
			//FIN NOMBRE
			
	
		
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace / BY *','FUNCTION');"; 
				
		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}

		pg_close($conexion);
	}
	else
	{
      
	//INICIO * --> /
      $encuentraDivision = '/';
      $posicionDivision = strpos($mutanteOper8, $encuentraDivision, $posicionDivision);
      $function = substr ( strtolower($copia) , 0 , $posicionDivision);
      
      
      $resto = substr ( $mutanteOper8 , $posicionDivision );    
      $division = '/';
      $multiplicacion = '/';
	  $cambio1 = preg_replace('/\//', '*', $resto, 1);
      

      $mutanteOper8 = $function.$cambio1; 
      if($contador == 0){
		$contador = 1;
	  }
	  $contador = $contador + 1;

		// Create connection

			$conexion = pg_connect($_SESSION['conexion']);

		//Trigger
			$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
            $posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
	
            $restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
           
            $aux3 = explode(" ", $restoCreateTrigger);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
			
		//FIN TRIGGER

		//FUNCION
		//CAMBIO OR REPLACE

		$restoFunction = "";
		$encuentra = 'OR REPLACE FUNCTION';
		$pos = strpos($copia, $encuentra);

		// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
		if ($pos === false) {
			$encuentraFunction = 'OR REPLACE FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
				$restoFunction = substr ( $copia , $posicionFunction + 19  );
		} else {
			$encuentraFunction = 'FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
			 $restoFunction = substr ( $copia , $posicionFunction + 8  );
			
		}
		//FIN CAMBIO OR REPLACE
			
            
            $nombreFunction = explode(" ", strtolower($restoFunction));  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
		
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper8);

		//FIN FUNCION


		//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
		//FIN NOMBRE

	
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper8','$nombreFuncionOper8', '$trigger', '$mutanteOper8','$login','$triggerid','$oper','false', 'Replace / BY *', 'FUNCTION');";
		
		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}

		pg_close($conexion);
	
		//FIN / --> *
	}//FIN DEL ELSE OPER1
 
	}

		//FIN division POR multiplicacion
		}//fin si hay algun DIVISION



		//FIN OPERADOR DIVISION


		}//FIN OPERADOR8
			
			
		//INICIO OPERADOR9
		if($oper == 9  )
		{

			$existe = false;
			$existeOperador9 = true;

			

			//INICIO ALGORITMO
		
		
			$mutantesAND = preg_match_all( "/[\s)\n]and[\s(\n]/",strtolower($copia));
		
			$mutanteOper9 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesAND; $cont++){  
		
				$encuentraAND = strtolower("/[\s)\n]and[\s(\n]/");
		
				preg_match($encuentraAND, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion+1);
				$resto = substr ( strtolower($mutaciones) , $posicion+4 );    
				
		
				$cambio1 = 'OR '.$resto;
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion+1);
				
		
				$mutaciones = $inicioMutations.$cambio1;
				
				
				$mutanteOper9 = $contenidoarchivo.$cambio1; 
				
			

       		// Create connection
			$conexion = pg_connect($_SESSION['conexion']);
			//Trigger
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				$posicionCreateTrigger = strpos(strtolower($mutanteOper9), $encuentraCreateTrigger);

				$restoCreateTrigger = substr ( strtolower($mutanteOper9) , $posicionCreateTrigger+14  );
				$aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
				$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
				$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;	

				$restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
				$aux3 = explode(" ", $restoCreateTrigger);  
            
            
				$nombreTriggerOriginalOper9 = str_replace('$', '' ,$aux3[1]);
			
			//FIN TRIGGER

			//FUNCION
		
			
            $encuentraFunction = strtolower('FUNCTION');
            $posicionFunction = strpos(strtolower($copia), $encuentraFunction);

            $restoFunction = substr (strtolower($copia) , $posicionFunction + 8  );

            
            $nombreFunction = explode(" ", strtolower($restoFunction));  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			$search = $nombreTrigger;
			
			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper9);
			
			//FIN FUNCION
			
			$nFunction = explode(" ", $restoFunction);  
				$nombreFuncionOper9 = str_replace('$', '' ,$nFunction[1]);

			//INICIO
					$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
			//FIN NOMBRE
	
			
	      $mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper9','$nombreFuncionOper9', '$trigger', '$mutanteOper9','$login','$triggerid','$oper','false', 'Replace AND BY OR', 'FUNCTION');";
		  
		  
	   
			$result = pg_query($conexion, $mutante);
			if (!$result) {
			  echo "Ocurrió un error.\n";
			  exit;
			}
		
			pg_close($conexion);
			//fin conexion
		
	}//FIN ALGORITMO

			$mutantesOR = preg_match_all( "/[\s)\n]or[\s(\n]/",strtolower($copia));

			$mutanteOper9 = "";
			$mutaciones = $function;
			

	for ($cont = 1; $cont <= $mutantesOR; $cont++){  
		
				//INICIO
				$encuentraOR = strtolower("/[\s)\n]or[\s(\n]/");
				preg_match($encuentraOR, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion+1);
				  
				$resto = substr ( strtolower($mutaciones) , $posicion+3 );    
				
				
				$cambio1 = 'AND'.$resto;
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				
				$mutaciones = $inicioMutations.$cambio1;
				
				
				$mutanteOper9 = $contenidoarchivo.$cambio1; 
				
				//FIN
			  
				// Create connection

				$conexion = pg_connect($_SESSION['conexion']);

				//Trigger
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				$posicionCreateTrigger = strpos(strtolower($mutanteOper9), $encuentraCreateTrigger);

				$restoCreateTrigger = substr ( strtolower($mutanteOper9) , $posicionCreateTrigger+14  );
            
           
				$aux3 = explode(" ", $restoCreateTrigger);  
            				
				$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
				
				$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
				
				$restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
				$aux3 = explode(" ", $restoCreateTrigger);  
            
            
				$nombreTriggerOriginalOper9 = str_replace('$', '' ,$aux3[1]);
				
			
				//FIN TRIGGER

				//FUNCION
				//CAMBIO OR REPLACE

				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					 $restoFunction = substr ( $copia , $posicionFunction + 8  );
					
				}
				//FIN CAMBIO OR REPLACE

            
				$nombreFunction = explode(" ", strtolower($restoFunction));  
			
				$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);

				
				$search = $nombreTrigger;
				$tamNombre = strlen($search);
				$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
				$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
				
				

				$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper9);
			
				//FIN FUNCION
				
				$nFunction = explode(" ", $restoFunction);  
				$nombreFuncionOper9 = str_replace('$', '' ,$nFunction[1]);

				//INICIO
					$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
				//FIN NOMBRE
							
				
					$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper9','$nombreFuncionOper9', '$trigger', '$mutanteOper9','$login','$triggerid','$oper','false', 'Replace OR BY AND', 'FUNCTION');";
						 
						  
	   
				$result = pg_query($conexion, $mutante);
				if (!$result) {
				  echo "Ocurrió un error.\n";
				  exit;
				}
		
				pg_close($conexion);
				//fin conexion
		   

      

			
		}//FIN ALGORITMO


}//FIN OPERADOR 9
			
			
			//FIN OPERADOR9
			
			//INICIO OPERADOR10
			
			if($oper == 10  )
			{


				$existeOper10 = false;
				$existeOperador10 = true;
				$mutantesAFTER = substr_count(strtolower($trigger), strtolower('AFTER'));
				$mutantesBEFORE = substr_count(strtolower($trigger), strtolower('BEFORE'));
  
				$mutantesConjunto = $mutantesAFTER + $mutantesBEFORE;
				//Trigger

			
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

				$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
           
				$aux3 = explode(" ", $restoCreateTrigger);  

                $nombreTriggerOriginalOper10 = str_replace('$', '' ,$aux3[1]);
					
				//FIN TRIGGER

				//FUNCION
				//CAMBIO OR REPLACE

				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					 $restoFunction = substr ( $copia , $posicionFunction + 8  );
					
				}
				//FIN CAMBIO OR REPLACE

				$nFunction = explode(" ", strtolower($restoFunction));  
			
				$nombreFuncionOper10 = str_replace('$', '' ,$nFunction[1]);

				//fin funcion
  
				//fin nombres triggers y funciones
		
				$reemplazos = substr_count($trigger, strtolower('AFTER'));

				$original=$function;	
		
				//INICIO ALGORITMO
	
	
				$mutantes = substr_count(strtolower($trigger),strtolower('AFTER'));

				
				for ($contadorMutantes = 1; $contadorMutantes <= $mutantes; $contadorMutantes++){  
	
				if($contadorMutantes === 1){
	  
				  $encuentraAfter = strtolower('AFTER');
				  $posicionAfter = strpos(strtolower($trigger), $encuentraAfter);
				 
      
				  $trozo = substr ( strtolower($trigger) , 0 , $posicionAfter + 4  );
				  $resto = substr ( strtolower($trigger) , $posicionAfter + 4  );
				  
				  $mutanteOper10 = str_ireplace(strtolower("AFTER"), strtolower("BEFORE"), strtolower($trigger));
		 
				  // echo 'CAMBIADO: ', $mutanteOper10;
				if($contador == 0){
					$contador = 1;
				}
				else{
					$contador = $contador + 1;
				}
	  
				//INICIO INSERT MUTANTE	  
				$conexion = pg_connect($_SESSION['conexion']);
				//Trigger
				$encuentraCreateTrigger = 'CREATE TRIGGER';
				$posCreateTrigger = strpos($trigger, $encuentraCreateTrigger);

				$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
				
				$auxiliar = explode(" ",strtolower($restoo));  
				
				$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
				
				$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
				
				$restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
				$aux3 = explode(" ", $restoCreateTrigger);  
            
            
				$nombreTriggerOriginalOper10 = str_replace('$', '' ,$aux3[1]);
			
				//FIN TRIGGER

				//FUNCION
				//CAMBIO OR REPLACE

				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
			
				$encuentraFunction = 'OR REPLACE FUNCTION';
				
				$posicionFunction = strpos($copia, $encuentraFunction);
					$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
			
				$encuentraFunction = 'FUNCTION';
				
				$posicionFunction = strpos($copia, $encuentraFunction);
				 $restoFunction = substr ( $copia , $posicionFunction + 8  );
				}
				//FIN CAMBIO OR REPLACE

            
				$nombreFunction = explode(" ", strtolower($restoFunction));  

			
				$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			
				$search = $nombreTrigger;

				$tamNombre = strlen($search);
				$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
				$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
		

				$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper10);
		

				//FIN FUNCION

				//INICIO
						$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
						$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
				//FIN NOMBRE
			

				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper10','$nombreFuncionOper10', '$mutanteOper10', '$function','$login','$triggerid','$oper','false','Replace AFTER by BEFORE', 'TRIGGER');"; 

				
					$result = pg_query($conexion, $mutante);
				if (!$result) {
				  echo "Ocurrió un error.\n";
				  exit;
				}
				
				pg_close($conexion);

				 }
				else{
      
      
					$encuentraAfter = strtolower('AFTER');
					$posicionAfter = strpos(strtolower($mutanteOper10), $encuentraAfter, $posicionAfter);
					$function = substr ( strtolower($copia) , 0 , $posicionAfter);
					  
					  
					$resto = substr ( strtolower($mutanteOper10) , $posicionAfter );    
					$after = strtolower('AFTER');
					$before = strtolower('BEFORE');
					$mutanteOper10 = str_ireplace(strtolower("AFTER"), strtolower("BEFORE"), $trigger);
      
					if($contador == 0){
						$contador = 1;
					}
					else{
						$contador = $contador + 1;
					}

					// Create connection

					$conexion = pg_connect($_SESSION['conexion']);

					//Trigger
					$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
					$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
		

					$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
					
				   
					$aux3 = explode(" ", strtolower($restoCreateTrigger));  
					
					
					$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
					$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
			
					//FIN TRIGGER

					//FUNCION
					//CAMBIO OR REPLACE

					$restoFunction = "";
					$encuentra = 'OR REPLACE FUNCTION';
					$pos = strpos($copia, $encuentra);

					// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
					if ($pos === false) {
						$encuentraFunction = 'OR REPLACE FUNCTION';
						$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
					} else {
						$encuentraFunction = 'FUNCTION';
						$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 8  );
					}	
					//FIN CAMBIO OR REPLACE
			
            
					$nombreFunction = explode(" ", strtolower($restoFunction));  

					$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
					$search = $nombreTrigger;

					$tamNombre = strlen($search);
					$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
					$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
					$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper10);

					//FIN FUNCION


					//INICIO
						$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
						$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
					//FIN NOMBRE

	
					$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper10','$nombreFuncionOper10','$mutanteOper10', '$function','$login','$triggerid','$oper','false','Replace AFTER by BEFORE', 'TRIGGER');";

		
					$result = pg_query($conexion, $mutante);
					if (!$result) {
					  echo "Ocurrió un error.\n";
					  exit;
					}
					
					pg_close($conexion);
	
					}//FIN DEL ELSE
				}



	$reemplazos = substr_count(strtolower($copia), strtolower('BEFORE'));

	//INICIO ALGORITMO
	$mutantes = substr_count(strtolower($trigger), strtolower('BEFORE'));

	for ($contadorMutantes = 1; $contadorMutantes <= $mutantes; $contadorMutantes++)
	{  
		if($contadorMutantes === 1){
      
			$encuentraBefore = strtolower('BEFORE');
			$posicion = strpos(strtolower($trigger), $encuentraBefore);
       
			$trozo = substr ( strtolower($trigger) , 0 , $posicion + 6  );
			$resto = substr ( strtolower($trigger) , $posicion + 6  );
    
			$cambiado = str_replace(strtolower("BEFORE"), strtolower("AFTER"), strtolower($trozo));
			$mutanteOper10 = $cambiado .= $resto; 
 	
			if($contador == 0){
				$contador = 1;
			}
			else
			{
				$contador = $contador + 1;
			}		
	  
			//INICIO INSERT MUTANTE
      		// Create connection
			$conexion = pg_connect($_SESSION['conexion']);
			// Check connection
			//Trigger
			$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
            $posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

            $restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );

           
            $auxiliar = explode(" ", strtolower($restoo));  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
	
	
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
			
			//FIN TRIGGER
			//FUNCION
           //CAMBIO OR REPLACE

			$restoFunction = "";
			$encuentra = 'OR REPLACE FUNCTION';
			$pos = strpos($copia, $encuentra);

			// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
			if ($pos === false) {
				$encuentraFunction = 'OR REPLACE FUNCTION';
				
				$posicionFunction = strpos($copia, $encuentraFunction);
					$restoFunction = substr ( $copia , $posicionFunction + 19  );
			} else {
				$encuentraFunction = 'FUNCTION';
				
				$posicionFunction = strpos($copia, $encuentraFunction);
				 $restoFunction = substr ( $copia , $posicionFunction + 8  );
				
			}
			//FIN CAMBIO OR REPLACE
			                    
            
            $nombreFunction = explode(" ", strtolower($restoFunction));  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			$search = $nombreTrigger;
			
			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper10);
			
			//FIN FUNCION

			//FIN CUERPOS

	//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
	//FIN NOMBRE
	
	
	   $mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper10','$nombreFuncionOper10', '$mutanteOper10', '$function','$login','$triggerid','$oper','false','Replace BEFORE by AFTER','TRIGGER');";

	   $result = pg_query($conexion, $mutante);
	   if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}


		pg_close($conexion);
		
	}
	else{
    
      
		$encuentraBefore = strtolower('BEFORE');
		$posicion = strpos(strtolower($mutanteOper10), $encuentraBefore, $posicion);
        $contenidoarchivo = substr ( strtolower($trigger) , 0 , $posicion);
      
		$resto = substr ( strtolower($mutanteOper10) , $posicion );    
		$before = strtolower('BEFORE');
		$after = strtolower('AFTER');
		$cambio1 = preg_replace(strtolower('BEFORE'), $after, $resto, 1);
      
		$mutanteOper10 = $contenidoarchivo.$cambio1; 
	 
	 
		if($contador == 0){
			$contador = 1;
		}
		else{
			   $contador = $contador + 1;
		}
	  
   		// Create connection

		$conexion = pg_connect($_SESSION['conexion']);

		//Trigger
			$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
            $posicionCreateTrigger = strpos(strtolower($mutanteOper10), $encuentraCreateTrigger);
		
            
            $restoCreateTrigger = substr ( strtolower($mutanteOper10) , $posicionCreateTrigger+14  );
            
            $aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
		//FIN TRIGGER

		//FUNCION
		//CAMBIO OR REPLACE

		$restoFunction = "";
		$encuentra = 'OR REPLACE FUNCTION';
		$pos = strpos($copia, $encuentra);

		// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
		if ($pos === false) {
			$encuentraFunction = 'OR REPLACE FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
				$restoFunction = substr ( $copia , $posicionFunction + 19  );
		} else {			
			$encuentraFunction = 'FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
			 $restoFunction = substr ( $copia , $posicionFunction + 8  );
		}
		//FIN CAMBIO OR REPLACE
			

            $nombreFunction = explode(" ", strtolower($restoFunction));  
		
            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			$search = $nombreTrigger;
			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper10);
			

		//FIN FUNCION

		//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
		//FIN NOMBRE
		
		
        $mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper10','$nombreFuncionOper10', '$mutanteOper10', '$function','$login','$triggerid','$oper','false','Replace BEFORE by AFTER', 'TRIGGER');";
		 
		  	   	$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
	
		pg_close($conexion);
		//fin conexion
      
		}

	}//FIN ALGORITMO
	



	}//FIN OPERADOR10

		//INICIO OPERADOR11
		if($oper == 11  )
		{
	
	
			$existeOper11 = false;
			$existeOperador11 = true;
			$mutantesFOREACHROW = substr_count(strtolower($trigger), strtolower('FOR EACH ROW'));
			$mutantesFOREACHSTATEMENT = substr_count(strtolower($trigger), strtolower('FOR EACH STATEMENT'));
  
			$mutantesConjunto = $mutantesFOREACHROW + $mutantesFOREACHSTATEMENT;	

		$reemplazos = substr_count($trigger, 'FOR EACH ROW');

		
	//INICIO ALGORITMO
	
	
	$mutantes = substr_count(strtolower($trigger), strtolower('FOR EACH ROW'));

	$reemplazos = substr_count(strtolower($trigger), strtolower('FOR EACH STATEMENT'));

	//INICIO ALGORITMO
	
	$mutantes = substr_count(strtolower($trigger), strtolower('FOR EACH STATEMENT'));

	for ($contadorMutantes = 1; $contadorMutantes <= $mutantes; $contadorMutantes++){  
		if($contadorMutantes === 1){

        
		$encuentraStatement = strtolower('FOR EACH STATEMENT');
		$posicion = strpos(strtolower($trigger), $encuentraStatement);
     
		$trozo = substr ( strtolower($trigger) , 0 , $posicion + 18  );
		$resto = substr ( strtolower($trigger) , $posicion + 18  );
      
      
		$mutanteOper11 = str_replace(strtolower("FOR EACH STATEMENT"), strtolower("FOR EACH ROW"), strtolower($trigger));
  
		if($contador == 0){
			$contador = 1;
		}
		
	  //INICIO INSERT MUTANTE

      
      
      		// Create connection

			$conexion = pg_connect($_SESSION['conexion']);
			// Check connection

			//Trigger
			$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
            $posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
            
            $restoo = substr ( strtolower($trigger), $posCreateTrigger+14  );
            
            $auxiliar = explode(" ", strtolower($restoo));  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
	
	
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
			//FIN TRIGGER

			//FUNCION
			//CAMBIO OR REPLACE
			$restoFunction = "";
			$encuentra = 'OR REPLACE FUNCTION';
			$pos = strpos($copia, $encuentra);

			// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
			if ($pos === false) {
				$encuentraFunction = 'OR REPLACE FUNCTION';
				
				$posicionFunction = strpos($copia, $encuentraFunction);
					$restoFunction = substr ( $copia , $posicionFunction + 19  );
			} else {
				$encuentraFunction = 'FUNCTION';
				
				$posicionFunction = strpos($copia, $encuentraFunction);
				 $restoFunction = substr ( $copia , $posicionFunction + 8  );
				
			}
			//FIN CAMBIO OR REPLACE
			
            
            $nFunction = explode(" ", strtolower($restoFunction));  

            $nombreFuncion = str_replace('$', '' ,$nFunction[1]);
			
			
			$search = $nombreFuncion;
			
			$tamNombre = strlen($search);
			$nomFuncion = substr ( $nombreFuncion , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomFuncion . '_' .$contador . '()';
			
			$functionMutante = str_ireplace($nombreFuncion , $nomFunctionActualizado, $copia);
			
			//FIN FUNCION


			$triggerMutante = str_ireplace($nombreFuncion , $nomFunctionActualizado, $mutanteOper11);

			//FIN CUERPOS

			//INICIO
					$triggerActualizado = str_ireplace($nombreFuncion , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
			//FIN NOMBRE
	
	
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper11', '$function','$login','$triggerid','$oper','false','Replace FOR EACH STATEMENT BY EACH ROW', 'TRIGGER');";
	   
	   $result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}

		pg_close($conexion);
		
		//FIN INSERT MUTANTE

		}
		else{
     
			$encuentraStatement = strtolower('FOR EACH STATEMENT');
			$posicion = strpos(strtolower($mutanteOper11), $encuentraStatement, $posicion);
			$trigger1 = substr ( strtolower($trigger) , 0 , $posicion);
      
			$resto = substr ( strtolower($mutanteOper11) , $posicion );    
			$row = strtolower('FOR EACH ROW');
			$statement = strtolower('FOR EACH STATEMENT');
			$cambio1 = preg_replace(strtolower('FOR EACH STATEMENT'), $row, $resto, 1);
      

			$mutanteOper11 = $trigger1.$cambio1; 
			if($contador == 0){
				$contador = 1;
			}
			else{
				$contador = $contador + 1;
			}
	  
      		// Create connection

			$conexion = pg_connect($_SESSION['conexion']);

			//Trigger
			$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
            $posicionCreateTrigger = strpos(strtolower($mutanteOper11), $encuentraCreateTrigger);
       
            $restoCreateTrigger = substr ( strtolower($mutanteOper11) , $posicionCreateTrigger+14  );
            
           
            $aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
						
			//FIN TRIGGER

			//FUNCION
			//CAMBIO OR REPLACE

			$restoFunction = "";
			$encuentra = 'OR REPLACE FUNCTION';
			$pos = strpos($copia, $encuentra);

			// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
			if ($pos === false) {
				$encuentraFunction = 'OR REPLACE FUNCTION';			
				$posicionFunction = strpos($copia, $encuentraFunction);
				$restoFunction = substr ( $copia , $posicionFunction + 19  );
			} else {
				$encuentraFunction = 'FUNCTION';
				$posicionFunction = strpos($copia, $encuentraFunction);
				$restoFunction = substr ( $copia , $posicionFunction + 8  );			
			}
			//FIN CAMBIO OR REPLACE
            
            $nFunction = explode(" ", $restoFunction);  
		
            $nombreFuncion = str_replace('$', '' ,$nFunction[1]);
			
			$search = $nombreFuncion;
			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreFuncion , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			

			$functionMutante = str_ireplace($nombreFuncion , $nomFunctionActualizado, $mutanteOper11);
			
			//FIN FUNCION

			//INICIO
					$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
			//FIN NOMBRE
			
			
	
			$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper11', '$function','$login','$triggerid','$oper','false','Replace FOR EACH STATEMENT BY EACH ROW','TRIGGER');";
					  
			$result = pg_query($conexion, $mutante);
			if (!$result) {
			  echo "Ocurrió un error.\n";
			  exit;
			}
			pg_close($conexion);
			//fin conexion
      
			}
		}//FIN ALGORITMO



		}//FIN OPERADOR 11
			

		//INICIO 12 
		
		//INICIO OPERADOR 12

		if($oper == 12  )
		{
	

			$conexion = pg_connect($_SESSION['conexion']);
			$existeOper12 = false;
			$existeOperador12 = true;
			$mutantesWHEN = substr_count(strtolower($trigger), strtolower('WHEN'));
 
			$original=$function;	
		
		
			//INICIO ALGORITMO
	
	
			$mutantes = substr_count(strtolower($trigger), strtolower('WHEN'));


			for ($contadorMutantes = 1; $contadorMutantes <= $mutantes; $contadorMutantes++){  
 
				if($contadorMutantes === 1){
	
     
      
					$encuentraWhen = strtolower('WHEN');
					$posicionWhen = strpos(strtolower($trigger), $encuentraWhen);
					
					$encuentraExecute = strtolower('EXECUTE');
					$posicionExecute = strpos(strtolower($trigger), $encuentraExecute);
					
				  
					$parte1= substr(strtolower($trigger),0, $posicionWhen);
					$parte2 = substr(strtolower($trigger),$posicionExecute);
				  
					$mutanteOper12 = $parte1.$parte2;

	 
					//Trigger
					$encuentraCreateTrigger = 'CREATE TRIGGER';
					$posicionCreateTrigger = strpos($mutanteOper12, $encuentraCreateTrigger);
		 

					$restoCreateTrigger = substr ( $mutanteOper12 , $posicionCreateTrigger+14  );
					
				   
					$aux3 = explode(" ", $restoCreateTrigger);  
					
					
					$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
					
					$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
					//FIN TRIGGER

					//FUNCION
					//CAMBIO OR REPLACE

					$restoFunction = "";
					$encuentra = 'OR REPLACE FUNCTION';
					$pos = strpos($copia, $encuentra);

					// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
					if ($pos === false) {
						$encuentraFunction = 'OR REPLACE FUNCTION';
						
						$posicionFunction = strpos($copia, $encuentraFunction);
							$restoFunction = substr ( $copia , $posicionFunction + 19  );
					} else {
						$encuentraFunction = 'FUNCTION';
						
						$posicionFunction = strpos($copia, $encuentraFunction);
						 $restoFunction = substr ( $copia , $posicionFunction + 8  );
						
					}
					//FIN CAMBIO OR REPLACE
			
            
					$nFunction = explode(" ", strtolower($restoFunction));  
		
					$nombreFuncion = str_replace('$', '' ,$nFunction[1]);
				
					$search = $nombreFuncion;
					$tamNombre = strlen($search);
					$nomF = substr ( $nombreFuncion , 0, $tamNombre - 2);
					$nomFunctionActualizado = $nomF . '_' .$contador . '()';
			
					$functionMutante = str_ireplace($nombreFuncion , $nomFunctionActualizado, $mutanteOper12);
			
					//FIN FUNCION
	  
					$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion', '$mutanteOper12', '$function','$login','$triggerid','$oper','false','Remove clause WHEN from the statement', 'TRIGGER');"; 	
					

						$conexion = pg_connect($_SESSION['conexion']);
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
						pg_close($conexion);
					
				  }
 
			}

			//FIN ALGORITMO
	
			}  //FIN OPERADOR12
		
			//INICIO OPERADOR13
			if($oper == 13)
			{

				$existeOper13 = false;
				$existeOperador13 = true; 
	
				$reemplazos = substr_count(strtolower($copia), strtolower('NOT AND'));
	
	
				//nombres de triggers y funciones 
				//Trigger

			
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

				$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
           
				$aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
            
				$nombreTriggerOriginalOper13 = str_replace('$', '' ,$aux3[1]);
			
				//FIN TRIGGER

				//FUNCION
				//CAMBIO OR REPLACE
	
				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					 $restoFunction = substr ( $copia , $posicionFunction + 8  );
					
				}
				//FIN CAMBIO OR REPLACE
													
			
					$nFunction = explode(" ",strtolower($restoFunction));  
						
					$nombreFuncionOper13 = str_replace('$', '' ,$nFunction[1]);
							
				//fin funcion
  
  
				//fin nombres triggers y funciones
				
				//INICIO OPER NOT
					$mutantesNOT = preg_match_all( "/[\s(\n]not[\s(\n]/",strtolower($copia));

			$mutanteOper13 = "";
			$mutaciones = $function;
			

	for ($cont = 1; $cont <= $mutantesNOT; $cont++){  
		
				//INICIO
				$encuentraNOT = strtolower("/[\s(\n]not[\s(\n]/");
				preg_match($encuentraNOT, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion+1);
				  
				$resto = substr ( strtolower($mutaciones) , $posicion+4 );    
				
				
				$cambio1 = $resto;
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion+1);
				
				$mutaciones = $inicioMutations.'@@@'.$cambio1;
				
				
				$mutanteOper13 = $contenidoarchivo.$cambio1; 
				
		
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper13','$nombreFuncionOper13', '$trigger', '$mutanteOper13','$login','$triggerid','$oper','false', 'Remove logical operator NOT', 'FUNCTION');";
			
				$result = pg_query($conexion, $mutante);
				if (!$result) {
				  echo "Ocurrió un error.\n";
				  exit;
				}
		
				pg_close($conexion);
	
	}//FIN ALGORITMO


	}
	//FIN OPERADOR13
	if($oper == 14) 
	{
		
		//INICIOOOOOOOO
		// Create connection

					$conexion = pg_connect($_SESSION['conexion']);

					//Trigger
					$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
					$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
            

					$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
           
					$aux3 = explode(" ", $restoCreateTrigger);  
            
            
					$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			
					$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
					
					$aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
					$nombreTriggerOriginalOper14 = str_replace('$', '' ,$aux3[1]);
					
					//FIN TRIGGER

					//FUNCION
	
					//CAMBIO OR REPLACE
	
					$restoFunction = "";
					$encuentra = 'OR REPLACE FUNCTION';
					$pos = strpos($copia, $encuentra);

					// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
					if ($pos === false) {
						$encuentraFunction = 'OR REPLACE FUNCTION';
						
						$posicionFunction = strpos($copia, $encuentraFunction);
							$restoFunction = substr ( $copia , $posicionFunction + 19  );
					} else {
						$encuentraFunction = 'FUNCTION';
						
						$posicionFunction = strpos($copia, $encuentraFunction);
						 $restoFunction = substr ( $copia , $posicionFunction + 8  );
						
					}
					//FIN CAMBIO OR REPLACE
		
		
					$nFunction = explode(" ",strtolower($restoFunction));  
						
					$nombreFuncionOper14 = str_replace('$', '' ,$nFunction[1]);
            
					$nombreFunction = explode(" ", strtolower($restoFunction));  

					$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
					
					
					$search = $nombreTrigger;
					
					$tamNombre = strlen($search);
					$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
					$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
					$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			
					//FIN FUNCION
		//FINNNNNNNNNNN
		//INICIO ALGORITMO
			$mutantesRELMayorIgual = preg_match_all( "/>=/",strtolower($copia));
		
			$mutanteOper14 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesRELMayorIgual; $cont++){  
		
				$encuentraRELMayorIgual = strtolower("/>=/");
		
				preg_match($encuentraRELMayorIgual, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				//$posicion = strpos(strtolower($mutaciones), $encuentraRELMayorIgual);
				$posicion = $matches[0][1];
				
				
				
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+2 );    
				
		
				$cambio1 = '<='.$resto;
				$cambio2 = '<>'.$resto;
				$cambio3 = '='.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper14 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace >= by <=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace >= by <>', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace >= by =', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace >= by >', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace >= by <', 'FUNCTION');";
				pg_query($conexion, $mutante);
		
			}
			
			//operador2
			$mutantesRELMenorIgual = preg_match_all( "/<=/",strtolower($copia));
		
			$mutanteOper14 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesRELMenorIgual; $cont++){  
		
				$encuentraRELMenorIgual = strtolower("/<=/");
		
				preg_match($encuentraRELMenorIgual, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				//$posicion = strpos(strtolower($mutaciones), $encuentraRELMenorIgual);
				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion +2);    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<>'.$resto;
				$cambio3 = '='.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper14 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <= by >=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <= by <>', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <= by =', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <= by >', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <= by <', 'FUNCTION');";
				pg_query($conexion, $mutante);
				
		
		
		
			}
			//Operador2
			
			//OPERADOR3
			$mutantesRELDistinto = preg_match_all( "/<>/",strtolower($copia));
		
			$mutanteOper14 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesRELDistinto; $cont++){  
		
				$encuentraRELDistinto = strtolower("/<>/");
		
				preg_match($encuentraRELDistinto, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				//$posicion = strpos(strtolower($mutaciones), $encuentraRELDistinto);
				$posicion = $matches[0][1];
				
				
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+2 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '='.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper14 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <> by >=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <> by <=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <> by =', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <> by >', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace <> by <', 'FUNCTION');";
				pg_query($conexion, $mutante);
				
			}
			//fin operador3
			
			//operador4
			$mutantesRELIgualIgual = preg_match_all( "/[^><]=/",strtolower($copia));
			
			
		
			$mutanteOper14 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesRELIgualIgual; $cont++){  
		
				$encuentraRELIgualIgual = strtolower("/[^><]=/");
		
				preg_match($encuentraRELIgualIgual, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				//$posicion = strpos(strtolower($mutaciones), $encuentraRELIgualIgual);
				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion+1);
				$resto = substr ( strtolower($mutaciones) , $posicion+1 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '<>'.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion+1);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper14 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace = by >=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace = by <=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace = by <>', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace = by >', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace = by <', 'FUNCTION');";
				pg_query($conexion, $mutante);
			}
			
			//fin operador4
			
			//operador Mayor
			$mutantesRELMayor = preg_match_all( "/[^<]>[^=]/",strtolower($copia));
		
			$mutanteOper14 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesRELMayor; $cont++){  
		
				$encuentraRELMayor = strtolower("/[^<]>[^=]/");
		
				preg_match($encuentraRELMayor, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion+1);
				$resto = substr ( strtolower($mutaciones) , $posicion+1 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '<>'.$resto;
				$cambio4 = '<'.$resto;
				$cambio5 = '='.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion+1);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper14 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace > by >=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace > by <=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace > by <>', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace > by <', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace > by =', 'FUNCTION');";
				pg_query($conexion, $mutante);
			}
			//Fin operador Mayor
			
			//operador Menor
												
			$mutantesRELMenor = preg_match_all( '/<[^>=]/',strtolower($copia));
			
		
			$mutanteOper14 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesRELMenor; $cont++){  
		
				$encuentraRELMenor = strtolower('/<[^>=]/');
			
		
				preg_match($encuentraRELMenor, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];

				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+1 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '<>'.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '='.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper14 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace < by >=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace < by <=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace < by <>', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace < by >', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace < by =', 'FUNCTION');";
				pg_query($conexion, $mutante);
			}
			//Fin operador Menor
			
			//OPERADOR3
			$mutantesRELDistinto2 = preg_match_all( "/!=/",strtolower($copia));
		
			$mutanteOper14 = "";
			$mutaciones = $function;
			
			for ($cont = 1; $cont <= $mutantesRELDistinto2; $cont++){  
		
				$encuentraRELDistinto2 = strtolower("/!=/");
		
				preg_match($encuentraRELDistinto2, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				//$posicion = strpos(strtolower($mutaciones), $encuentraRELDistinto);
				$posicion = $matches[0][1];
				
				
				$contenidoarchivo = substr (strtolower($copia) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+2 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '='.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper14 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace != by >=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace != by <=', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace != by =', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace != by >', 'FUNCTION');";
				pg_query($conexion, $mutante);
				$mutanteOper14 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper14','$nombreFuncionOper14', '$trigger', '$mutanteOper14','$login','$triggerid','$oper','false', 'Replace != by <', 'FUNCTION');";
				pg_query($conexion, $mutante);
				
			}
			//fin operador3
			
			
			
			
	
	}
	//INICIO OPER15 ARREPH
	if($oper == 15)
	{
		
		//INICIO OPER15 CABECERA
		
				$contadorOper15 = $contador;
				
				$existeOper15 = false;
				$existeOperador15 = true; //Variable que indica si es posible aplicar dicho operador
				$mutantesSuma = substr_count(strtolower($trigger), '+');
				$mutantesResta = substr_count(strtolower($trigger), '-');
				$mutantesMultiplicacion = 0;
				if(substr_count(strtolower($trigger), '*')>0){
				if(substr_count(strtolower($trigger), '*.')>0){
				
				}
				else{
					$mutantesMultiplicacion = substr_count(strtolower($trigger), '*');
				}
				}
				$mutantesDivision = substr_count(strtolower($trigger), '/');
			  
				$mutantesConjunto = ($mutantesSuma*3) + ($mutantesResta*3) + ($mutantesMultiplicacion*3) + ($mutantesDivision*3);
			
				if($mutantesConjunto == 0)
				{		
					$_SESSION['errorOper'] = 'RLREP';
					$operator15 = false;
					$existeOperador15 = false;
		
				}
				$reemplazos = substr_count($trigger, '+');
		
				$original=$function;	
	
				//nombres de triggers y funciones 
				//Trigger
			
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

           
				$restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
				$aux3 = explode(" ", $restoCreateTrigger);  
            
            
				$nombreTriggerOriginalOper15 = str_replace('$', '' ,$aux3[1]);
			
				//FIN TRIGGER

				//FUNCION
				//CAMBIO OR REPLACE

				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					$restoFunction = substr ( $copia , $posicionFunction + 8  );
					
				}
				//FIN CAMBIO OR REPLACE
			
				$nFunction = explode(" ", $restoFunction);  
				$nombreFuncionOper15 = str_replace('$', '' ,$nFunction[1]);
				
				//fin funcion
  
  
				//fin nombres triggers y funciones
				//INICIO ALGORITMO
	
	
				$numSuma = substr_count($trigger, '+');

				if($numSuma > 0)
				{

					for ($contadorMutantes = 1; $contadorMutantes <= $numSuma; $contadorMutantes++)
					{  
					 
						if($contadorMutantes === 1)
						{

							   
							$encuentraMas = '+';
							$posicionMas = strpos($trigger, $encuentraMas);
							 
							  
							$trozo = substr ( $trigger , 0 , $posicionMas + 1  );
							$resto = substr ( $trigger , $posicionMas + 1  );
							  
							$cambiado = str_replace("+", "-", $trozo);
						  

							$mutanteOper15 = $cambiado .= $resto; 
							if($contador == 0){
								$contador = 1;
							  }
							  
							//INICIO INSERT MUTANTE
							  
							$conexion = pg_connect($_SESSION['conexion']);


							//Trigger
							$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				
							$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
				
							$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
						   
							$auxiliar = explode(" ", $restoo);  
							
							$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
							
							$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
					
							//FIN TRIGGER

							//FUNCION
							//CAMBIO OR REPLACE

							$restoFunction = "";
							$encuentra = 'OR REPLACE FUNCTION';
							$pos = strpos($copia, $encuentra);

							// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
							if ($pos === false) {
								$encuentraFunction = 'OR REPLACE FUNCTION';
								
								$posicionFunction = strpos($copia, $encuentraFunction);
									$restoFunction = substr ( $copia , $posicionFunction + 19  );
							} else {
								$encuentraFunction = 'FUNCTION';
								
								$posicionFunction = strpos($copia, $encuentraFunction);
								 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							}
							//FIN CAMBIO OR REPLACE			

					
							$nombreFunction = explode(" ", $restoFunction);  
							
							$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
							
							$search = $nombreTrigger;

							$tamNombre = strlen($search);
							$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
							$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';			

							$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);			
							//FIN FUNCION

							//INICIO
									$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
									$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
							//FIN NOMBRE
					
						//COMPROBAMOS SI ESTA EL TRIGGER Y OPERADOR 
							//echo 'OPERADOR: ', $oper; echo '<br>';
							$consulta = "select * from mutations where idtrigger = '".$triggerid."' and idoperator = '".$oper."'";
							$filasAfectadas = pg_query($consulta);
							$rows = pg_num_rows($filasAfectadas);

							//echo $rows . " row(s) returned.\n"; echo '<br>';
							
							
							
								if($rows == $mutantesConjunto)
								{
									////echo 'ESTE OPERADOR Y ESTE TRIGGER YA SE HA UTILIZADO';
									$existeOper15 = true ;
								}
								else{

									$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false','Replace + BY -', 'TRIGGER');"; 
								
									$result = pg_query($conexion, $mutante);
									if (!$result) {
									  echo "Ocurrió un error.\n";
									  exit;
									}

								}
								pg_close($conexion);
							  //FIN INSERT MUTANTE
			  
						}
						else
						{
		  
						//INICIO + --> -
							$encuentraMas = '+';
							$posicionMas = strpos($mutanteOper15, $encuentraMas, $posicionMas);
							$function = substr ( $trigger , 0 , $posicionMas);
							  
							  
							$resto = substr ( $mutanteOper15 , $posicionMas );    
							$mas = '+';
							$multiplicacion = '-';
							$cambio1 = preg_replace('/\+/', '-', $resto, 1);
							  
						
							$mutanteOper15 = $function.$cambio1; 
							  

							if($contador == 0){
								$contador = 1;
							}
							$contador = $contador + 1;
						

							// Create connection

							$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
							$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
							$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
							
							

							$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
							
						   
							$aux3 = explode(" ", $restoCreateTrigger);  
							
							
							$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
							$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
				

						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							
						}
						//FIN CAMBIO OR REPLACE
						
						$nombreFunction = explode(" ", $restoFunction);  
						
						$nombreTrigger = str_replace('$', '' ,isset($nombreFunction[1]) ? $nombreFunction[1] : null);
				
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
							
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);

						//FIN FUNCION


						//INICIO
							$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
							$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE
						
							$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace + BY -', 'TRIGGER');";
							
							$result = pg_query($conexion, $mutante);
							if (!$result) {
							  echo "Ocurrió un error.\n";
							  exit;
							}
			

							pg_close($conexion);
		
						//FIN + --> -

	  
						}//FIN DEL ELSE OPER1
	 
					}

					//MAS POR MULTIPLICACION 
					for ($contadorMutantes = 1; $contadorMutantes <= $numSuma; $contadorMutantes++)
					{  
					  if($contadorMutantes === 1)
					  {
					
						$encuentraMas = '+';
						$posicionMas = strpos($trigger, $encuentraMas);
						 
						  
						$trozo = substr ( $trigger , 0 , $posicionMas + 1  );
						$resto = substr ( $trigger , $posicionMas + 1  );
						  
						$cambiado = str_replace("+", "*", $trozo);
					  

						$mutanteOper15 = $cambiado .= $resto; 
						
						$contador = $contador + 1;
						  
						//INICIO INSERT MUTANTE
						  
						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
							$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
							$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
						
							$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
				
							$auxiliar = explode(" ", $restoo);  
							$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
							$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
				
						//FIN TRIGGER
		
						//FUNCION           
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
						}
						//FIN CAMBIO OR REPLACE
				
						$nombreFunction = explode(" ", $restoFunction);  

						
						$nombreTrigger = str_replace('$', '' ,isset($nombreFunction[1]) ? $nombreFunction[1] : null);
						
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
				
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);
				
						//FIN FUNCION

						//INICIO
								$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
								$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE
								
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace + BY *', 'TRIGGER');"; 
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
						pg_close($conexion);	
		  
						//FIN INSERT MUTANTE
					}
					else
					{
						//INICIO + --> -
						$encuentraMas = '+';
						$posicionMas = strpos($mutanteOper15, $encuentraMas, $posicionMas);
						$function = substr ( $trigger , 0 , $posicionMas);
						  
						  
						$resto = substr ( $mutanteOper15 , $posicionMas );    
						$mas = '+';
						$multiplicacion = '*';
						 
						$cambio1 = preg_replace('/\+/', '*', $resto, 1);
						  
						$mutanteOper15 = $function.$cambio1; 
						if($contador == 0){
							$contador = 1;
						}
						$contador = $contador + 1;

						// Create connection

						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
						$encuentraCreateTrigger = 'CREATE TRIGGER';
						$posicionCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
			
						$restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
				
						$aux3 = explode(" ", $restoCreateTrigger);  
				
						$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
				
						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							
						}
						//FIN CAMBIO OR REPLACE
				
						$nombreFunction = explode(" ", $restoFunction);  
						$nombreTrigger = str_replace('$', '' ,isset($nombreFunction[1]) ? $nombreFunction[1] : null);
				
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';

						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);

						//FIN FUNCION

						//INICIO
							$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
							$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE

						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false','Replace + BY *', 'TRIGGER');";
											
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}

						pg_close($conexion);
		
						//FIN + --> -

					}//FIN DEL ELSE 
 
					}
//FIN MAS POR MULTIPLICACION

//INICIO MAS POR DIVISION 

				for ($contadorMutantes = 1; $contadorMutantes <= $numSuma; $contadorMutantes++)
				{   
					if($contadorMutantes === 1){
					 
						$encuentraMas = '+';
						$posicionMas = strpos($trigger, $encuentraMas);
					 
						$trozo = substr ( $trigger , 0 , $posicionMas + 1  );
						$resto = substr ( $trigger , $posicionMas + 1  );
					  
						$cambiado = str_replace("+", "/", $trozo);
				  
						$mutanteOper15 = $cambiado .= $resto; 
					
						$contador = $contador + 1;
	  
						//INICIO INSERT MUTANTE
	  
						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
							$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
							$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
							
							$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
						   
							$auxiliar = explode(" ", $restoo);  
							
							$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
							
							$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
														
						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($trigger, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							
						}
						//FIN CAMBIO OR REPLACE
			            
						$nombreFunction = explode(" ", $restoFunction);  

						$nombreTrigger = str_replace('$', '' ,isset($nombreFunction[1]) ? $nombreFunction[1] : null);
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);
			

						//FIN FUNCION

						//INICIO
								$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
								$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE
			

						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false','Replace + BY /', 'TRIGGER');"; 
		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}

						pg_close($conexion);
		 	 
						//FIN INSERT MUTANTE
	 
					}
					else{
      
						//INICIO + --> -
						$encuentraMas = '+';
						$posicionMas = strpos($mutanteOper15, $encuentraMas, $posicionMas);
						$function = substr ( $trigger , 0 , $posicionMas);
						  
						  
						$resto = substr ( $mutanteOper15 , $posicionMas );    
						$mas = '+';
						$multiplicacion = '/';
						
						$cambio1 = preg_replace('/\+/', '/', $resto, 1);
						  
						$mutanteOper15 = $function.$cambio1; 
						if($contador == 0){
							$contador = 1;
						}
						else{
						$contador = $contador + 1;
						}

						// Create connection

						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
						$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

						$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
						$aux3 = explode(" ", $restoCreateTrigger);  
            
						$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							
						}
						//FIN CAMBIO OR REPLACE
            
						$nombreFunction = explode(" ", strtolower($restoFunction));  

						$nombreTrigger = str_replace('$', '' ,isset($nombreFunction[1]) ? $nombreFunction[1] : null);
						
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);

						//FIN FUNCION

						//INICIO
							$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
							$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE
	
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false','Replace + BY /', 'TRIGGER');";
		
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}

						pg_close($conexion);
	
						//FIN + --> -
						}//FIN DEL ELSE
				}
				//FIN MAS POR DIVISION
				}//fin si hay algun MAS


				//OPERADOR MENOS 

				$numMenos = substr_count($function, '-');
				if($numMenos > 0){

				for ($contadorMutantes = 1; $contadorMutantes <= $numMenos; $contadorMutantes++)
				{  
					if($contadorMutantes === 1)
					{
					 					  
						$encuentraMenos = '-';
						$posicionMenos = strpos($trigger, $encuentraMenos);
					 
						$trozo = substr ( $trigger , 0 , $posicionMenos + 1  );
						$resto = substr ( $trigger , $posicionMenos + 1  );
					 					  
						$cambiado = str_replace("-", "+", $trozo);
				  
						$mutanteOper15 = $cambiado .= $resto; 
						if($contador == 0){
							$contador = 1;
						  }

	  
						//INICIO INSERT MUTANTE
	  
						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');

						$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

						$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );							
					   
						$auxiliar = explode(" ", strtolower($restoo));  
						
						$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
							
						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							
						}
						//FIN CAMBIO OR REPLACE
								
						$nombreFunction = explode(" ", strtolower($restoFunction));  
						
						$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
						
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
						
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);

						//FIN FUNCION

						//INICIO
							$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
							$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE
					
				
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace - BY +', 'TRIGGER');"; 
				
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
				
						pg_close($conexion);
			
						//FIN INSERT MUTANTE
					}
					else{
      
					//INICIO - --> +
						$encuentraMenos = '-';
						$posicionMenos = strpos($mutanteOper15, $encuentraMenos, $posicionMenos);
						$function = substr ( $trigger , 0 , $posicionMenos);
						  
						  
						$resto = substr ( $mutanteOper15 , $posicionMenos );    
						$mas = '+';
						$menos = '-';
						$cambio1 = preg_replace('/-/', '+', $resto, 1);
      
						$mutanteOper15 = $function.$cambio1; 
  					    if($contador == 0){
							$contador = 1;
						}
						$contador = $contador + 1;

						// Create connection

						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
						$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
        
						$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
						$aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
						$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							
						}
						//FIN CAMBIO OR REPLACE
			            
						$nombreFunction = explode(" ", strtolower($restoFunction));  

						$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
						
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);

						//FIN FUNCION

						//INICIO
							$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
							$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE

						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15', '$mutanteOper15','$copia', '$login','$triggerid','$oper','false','Replace - BY +', 'TRIGGER');";
						
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
		 	
						pg_close($conexion);
	
						//FIN + --> -
						}//FIN DEL ELSE
				}
				//MENOS POR MULTIPLICACION
				for ($contadorMutantes = 1; $contadorMutantes <= $numMenos; $contadorMutantes++)
				{  
				 
					if($contadorMutantes === 1)
					{
				
						$encuentraMenos = '-';
						$posicionMenos = strpos($trigger, $encuentraMenos);
					 
						$trozo = substr ( $trigger , 0 , $posicionMenos + 1  );
						$resto = substr ( $trigger , $posicionMenos + 1  );
					  
						$cambiado = str_replace("-", "*", $trozo);
				  
						$mutanteOper15 = $cambiado .= $resto; 
					
						$contador = $contador + 1;
				
					  //INICIO INSERT MUTANTE
					  
						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
						$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
						
						$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );

						$auxiliar = explode(" ", strtolower($restoo));  

						$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);

						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;

						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							
						}
						//FIN CAMBIO OR REPLACE
			
						$nombreFunction = explode(" ", $restoFunction);  
						$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);
			
						//FIN FUNCION

						//INICIO
								$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
								$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE
			
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false','Replace - BY *', 'TRIGGER');"; 
						
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						
						pg_close($conexion);
						  
						//FIN INSERT MUTANTE
	 
					}
					else
					{
      
						//INICIO + --> -
						$encuentraMenos = '-';
						$posicionMenos = strpos($mutanteOper15, $encuentraMenos, $posicionMenos);
						$function = substr ( $trigger , 0 , $posicionMenos);
					  
					  
						$resto = substr ( $mutanteOper15 , $posicionMenos );    
						$menos = '-';
						$multiplicacion = '*';
					  
						$cambio1 = preg_replace('/-/', '*', $resto, 1);
					  
						$mutanteOper15 = $function.$cambio1; 
						if($contador == 0){
							$contador = 1;
						}
						$contador = $contador + 1;
			
						// Create connection

						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
						$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

						$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
						   
						$aux3 = explode(" ", strtolower($restoCreateTrigger));  
							
						$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
						
						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE

						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
						}
						//FIN CAMBIO OR REPLACE
									
				
						$nombreFunction = explode(" ", $restoFunction);  

						$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
				
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
						
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);

						//FIN FUNCION

						//INICIO
						$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
						$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE
		
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15', '$mutanteOper15','$copia','$login','$triggerid','$oper','false','Replace - BY *', 'TRIGGER');";
						
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
						pg_close($conexion);
		
						//FIN + --> -
					}//FIN DEL ELSE
 
				}
				//FIN MAS POR MULTIPLICACION

				//INICIO MENOS POR DIVISION
				for ($contadorMutantes = 1; $contadorMutantes <= $numMenos; $contadorMutantes++)
				{  
					if($contadorMutantes === 1)
					{
					 
						$encuentraMenos = '-';
						$posicionMenos = strpos($trigger, $encuentraMenos);
		 
		  
						$trozo = substr ( strtolower($trigger) , 0 , $posicionMenos + 1  );
						$resto = substr ( strtolower($trigger) , $posicionMenos + 1  );
		  
						$cambiado = str_replace("-", "/", $trozo);
	  
						$mutanteOper15 = $cambiado .= $resto; 
		
						$contador = $contador + 1;
			  
						//INICIO INSERT MUTANTE
		  
						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');            
						$posCreateTrigger = strpos($trigger, $encuentraCreateTrigger);

						$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
				
						$auxiliar = explode(" ", $restoo);  
					
						$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
				
						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
				
						//FIN TRIGGER

						//FUNCION           
						//CAMBIO OR REPLACE
						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
						}
						//FIN CAMBIO OR REPLACE

						$nombreFunction = explode(" ",strtolower($restoFunction));  
						
						$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';

						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);
									
						//FIN FUNCION

						//INICIO
								$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
								$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE
				
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false','Replace - BY /', 'TRIGGER');"; 
					
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}
			
						pg_close($conexion);
						//FIN INSERT MUTANTE
	  
					}
					else{
      
						//INICIO + --> -
						$encuentraMenos = '-';
						$posicionMenos = strpos($mutanteOper15, $encuentraMenos, $posicionMenos);
						$function = substr ( $trigger , 0 , $posicionMenos);
						  
						  
						$resto = substr ( $mutanteOper15 , $posicionMenos );    
						$menos = '-';
						$multiplicacion = '/';
						$cambio1 = preg_replace('/-/', '/', $resto, 1);
						  
					
						$mutanteOper15 = $function.$cambio1; 
						if($contador == 0){
							$contador = 1;
						}
						$contador = $contador + 1;
				

						// Create connection

						$conexion = pg_connect($_SESSION['conexion']);

						//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
						$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

						$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
						
					   
						$aux3 = explode(" ", $restoCreateTrigger);  
						
						$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
							
						//FIN TRIGGER

						//FUNCION
						//CAMBIO OR REPLACE
						$restoFunction = "";
						$encuentra = 'OR REPLACE FUNCTION';
						$pos = strpos($copia, $encuentra);

						// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
						if ($pos === false) {
							$encuentraFunction = 'OR REPLACE FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
								$restoFunction = substr ( $copia , $posicionFunction + 19  );
						} else {
							$encuentraFunction = 'FUNCTION';
							
							$posicionFunction = strpos($copia, $encuentraFunction);
							 $restoFunction = substr ( $copia , $posicionFunction + 8  );
							
						}
						//FIN CAMBIO OR REPLACE
						
						$nombreFunction = explode(" ", strtolower($restoFunction));  

						$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
						

						$search = $nombreTrigger;

						$tamNombre = strlen($search);
						$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
						$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
						
						$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);

						//FIN FUNCION

						//INICIO
							$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
							$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
						//FIN NOMBRE

	
						$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15', '$mutanteOper15','$copia', '$login','$triggerid','$oper','false','Replace - BY /', 'TRIGGER');";
						
						$result = pg_query($conexion, $mutante);
						if (!$result) {
						  echo "Ocurrió un error.\n";
						  exit;
						}

						pg_close($conexion);
	
						//FIN + --> -
						}//FIN DEL ELSE
				}
				//FIN MENOS POR DIVISION
				}//fin si hay algun MENOS
		//FIN OPERADOR MENOS 

		//INICIO OPERADOR MULTIPLICACION 

		$numMultiplicacion = substr_count($trigger, '*');
		if($numMultiplicacion > 0)
		{

		for ($contadorMutantes = 1; $contadorMutantes <= $numMultiplicacion; $contadorMutantes++)
		{  
			if($contadorMutantes === 1)
			{
			 
			  $encuentraMultiplicacion = '*';
			  $posicionMultiplicacion = strpos($trigger, $encuentraMultiplicacion);
			 
			  
			  $trozo = substr ( $trigger , 0 , $posicionMultiplicacion + 1  );
			  $resto = substr ( $trigger , $posicionMultiplicacion + 1  );
			  
			  $cambiado = str_replace("*", "+", $trozo);
		  

			$mutanteOper15 = $cambiado .= $resto; 
			if($contador == 0){
				$contador = 1;
			}
		
		    //INICIO INSERT MUTANTE
			  
			$conexion = pg_connect($_SESSION['conexion']);

			//Trigger
			$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
			$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
            
            $restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
            
            $auxiliar = explode(" ", strtolower($restoo));  
            
            $nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
			
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
			//FIN TRIGGER

			//FUNCION
            //CAMBIO OR REPLACE
			$restoFunction = "";
			$encuentra = 'OR REPLACE FUNCTION';
			$pos = strpos($copia, $encuentra);

			// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
			if ($pos === false) {
				$encuentraFunction = 'OR REPLACE FUNCTION';
				
				$posicionFunction = strpos($copia, $encuentraFunction);
					$restoFunction = substr ( $copia , $posicionFunction + 19  );
			} else {
				$encuentraFunction = 'FUNCTION';
				
				$posicionFunction = strpos($copia, $encuentraFunction);
				 $restoFunction = substr ( $copia , $posicionFunction + 8  );
			}
			//FIN CAMBIO OR REPLACE


            $nombreFunction = explode(" ", strtolower($restoFunction));  
			
            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);
			
			//FIN FUNCION
			
			//INICIO	
				$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
				$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
			//FIN NOMBRE
			
			$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15', '$mutanteOper15','$copia', '$login','$triggerid','$oper','false','Replace * BY +', 'TRIGGER');"; 
				
			$result = pg_query($conexion, $mutante);
			if (!$result) {
			  echo "Ocurrió un error.\n";
			  exit;
			}
		
			pg_close($conexion);
	
			//FIN INSERT MUTANTE
			}
			else
			{
      
			//INICIO * --> +
				$encuentraMultiplicacion = '*';
				$posicionMultiplicacion = strpos($mutanteOper15, $encuentraMultiplicacion, $posicionMultiplicacion);
				$function = substr ( $trigger , 0 , $posicionMultiplicacion);
				  
				  
				$resto = substr ( $mutanteOper15 , $posicionMultiplicacion );    
				$multiplicacion = '*';
				$menos = '-';
				$cambio1 = preg_replace('/\*/', '+', $resto, 1);
				  
				$mutanteOper15 = $function.$cambio1; 
				if($contador == 0){
					$contador = 1;
				}
				$contador = $contador + 1;
			
				// Create connection

					$conexion = pg_connect($_SESSION['conexion']);

				//Trigger
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
	
				$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
				$aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
				$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
				$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
				
				//FIN TRIGGER

				//FUNCION

				//CAMBIO OR REPLACE
				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					 $restoFunction = substr ( $copia , $posicionFunction + 8  );
					
				}
				//FIN CAMBIO OR REPLACE
			
            
				$nombreFunction = explode(" ", strtolower($restoFunction));  

				$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
				$search = $nombreTrigger;

				$tamNombre = strlen($search);
				$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
				$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
				
				

				$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);

				//FIN FUNCION

				//INICIO
					$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
				//FIN NOMBRE
	
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent,change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false','Replace * BY +', 'TRIGGER');";
	
				$result = pg_query($conexion, $mutante);
				if (!$result) {
					echo "Ocurrió un error.\n";
					exit;
				}

				pg_close($conexion);
	
				//FIN + --> -
			}//FIN DEL ELSE
		}

		//MULTIPLICACION POR MENOS
		for ($contadorMutantes = 1; $contadorMutantes <= $numMultiplicacion; $contadorMutantes++)
		{  
			if($contadorMutantes === 1)
			{  
				$encuentraMultiplicacion = '*';
				$posicionMultiplicacion = strpos($trigger, $encuentraMultiplicacion);
			 			  
				$trozo = substr ( $trigger , 0 , $posicionMultiplicacion + 1  );
				$resto = substr ( $trigger , $posicionMultiplicacion + 1  );
			  
				$cambiado = str_replace("*", "-", $trozo);
		  
				$mutanteOper15 = $cambiado .= $resto; 
			
				$contador = $contador + 1;
	
	  
				//INICIO INSERT MUTANTE
	  
				$conexion = pg_connect($_SESSION['conexion']);


				//Trigger
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');

				$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

				$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
				
				$auxiliar = explode(" ", strtolower($restoo));  
				
				$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
				
				$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
				
				//FIN TRIGGER
			
				//FUNCION           
				//CAMBIO OR REPLACE
				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
					$encuentraFunction = 'OR REPLACE FUNCTION';
	
					$posicionFunction = strpos($copia, $encuentraFunction);
					$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
    
					$encuentraFunction = 'FUNCTION';
					$posicionFunction = strpos($copia, $encuentraFunction);
					$restoFunction = substr ( $copia , $posicionFunction + 8  );    
				}			
				//FIN CAMBIO OR REPLACE

				$nombreFunction = explode(" ", strtolower($restoFunction));  

			
				$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
				$search = $nombreTrigger;

				$tamNombre = strlen($search);
				$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
				$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
				$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);
			
				//FIN FUNCION

				//INICIO
						$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
						$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
				//FIN NOMBRE
						
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15', '$mutanteOper15','$copia', '$login','$triggerid','$oper','false', 'Replace * BY -','TRIGGER');"; 

				$result = pg_query($conexion, $mutante);
				if (!$result) {
				  echo "Ocurrió un error.\n";
				  exit;
				}

				pg_close($conexion);
				//FIN INSERT MUTANTE	 
			}
		else{
      
				//INICIO * --> -
				$encuentraMultiplicacion = '*';
				$posicionMultiplicacion = strpos($mutanteOper15, $encuentraMultiplicacion, $posicionMultiplicacion);
				$function = substr ( $trigger , 0 , $posicionMultiplicacion);
				  
				  
				$resto = substr ( $mutanteOper15 , $posicionMultiplicacion );    
				$menos = '-';
				$multiplicacion = '*';
				$cambio1 = preg_replace('/\*/', '-', $resto, 1);
				  
				$mutanteOper15 = $function.$cambio1; 
				if($contador == 0){
					$contador = 1;
				}
				  $contador = $contador + 1;

				// Create connection
				$conexion = pg_connect($_SESSION['conexion']);

				//Trigger
				$encuentraCreateTrigger = 'CREATE TRIGGER';
				$posicionCreateTrigger = strpos($trigger, $encuentraCreateTrigger);

				$restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
            
				$aux3 = explode(" ", $restoCreateTrigger);  
            
				$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
				$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
				//FIN TRIGGER

				//FUNCION
				//CAMBIO OR REPLACE
				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {					
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					 $restoFunction = substr ( $copia , $posicionFunction + 8  );
					
				}
				//FIN CAMBIO OR REPLACE
			
            
				$nombreFunction = explode(" ", strtolower($restoFunction));  

				$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
				
				
				$search = $nombreTrigger;

				$tamNombre = strlen($search);
				$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
				$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
				
				$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);

				//FIN FUNCION
				
				//INICIO
					$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
				//FIN NOMBRE

				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false','Replace * BY -','TRIGGER');";
			
				$result = pg_query($conexion, $mutante);
				if (!$result) {
				  echo "Ocurrió un error.\n";
				  exit;
				}
				pg_close($conexion);
				//FIN + --> -
			}//FIN DEL ELSE
		}
		//FIN MAS POR MULTIPLICACION

		//INICIO MULTIPLICACION POR DIVISION
		for ($contadorMutantes = 1; $contadorMutantes <= $numMultiplicacion; $contadorMutantes++)
		{  
			if($contadorMutantes === 1)
			{
			 
				$encuentraMultiplicacion = '*';
				$posicionMultiplicacion = strpos(strtolower($trigger), $encuentraMultiplicacion);
			  
				$trozo = substr ( strtolower($trigger) , 0 , $posicionMultiplicacion + 1  );
				$resto = substr ( strtolower($trigger) , $posicionMultiplicacion + 1  );
			  
				$cambiado = str_replace("*", "/", $trozo);
		  
				$mutanteOper15 = $cambiado .= $resto; 
			
				$contador = $contador + 1;
			  
				//INICIO INSERT MUTANTE
			  
				$conexion = pg_connect($_SESSION['conexion']);

				//Trigger
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

				$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
            
				$auxiliar = explode(" ", strtolower($restoo));  
                        
				$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
			
				$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
				//FIN TRIGGER

				//FUNCION
				//CAMBIO OR REPLACE
				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					 $restoFunction = substr ( $copia , $posicionFunction + 8  );
				}
				//FIN CAMBIO OR REPLACE

				$nombreFunction = explode(" ", strtolower($restoFunction));  

				
				$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
				
				$search = $nombreTrigger;

				$tamNombre = strlen($search);
				$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
				$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
				$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);
			

				//FIN FUNCION

				//INICIO
					$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
				//FIN NOMBRE
				
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace * BY /','TRIGGER');"; 
				
				$result = pg_query($conexion, $mutante);
				if (!$result) {
				  echo "Ocurrió un error.\n";
				  exit;
				}
				
				pg_close($conexion);
			}
			else{
      
					//INICIO * --> /
					$encuentraMultiplicacion = '*';
					$posicionMultiplicacion = strpos($mutanteOper15, $encuentraMultiplicacion, $posicionMultiplicacion);
					$function = substr ( $trigger , 0 , $posicionMultiplicacion);
					  
					  
					$resto = substr ( $mutanteOper15 , $posicionMultiplicacion );    
					$menos = '-';
					$multiplicacion = '/';
					$cambio1 = preg_replace('/\*/', '/', $resto, 1);
					  
					$mutanteOper15 = $function.$cambio1; 
					if($contador == 0){
						$contador = 1;
					}
					$contador = $contador + 1;

					// Create connection

					$conexion = pg_connect($_SESSION['conexion']);
					//Trigger
					$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
					$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

					$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
					$aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
					$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
					$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
					
			
					//FIN TRIGGER

					//FUNCION
					//CAMBIO OR REPLACE	
					$restoFunction = "";
					$encuentra = 'OR REPLACE FUNCTION';
					$pos = strpos($copia, $encuentra);

					// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
					if ($pos === false) {
						$encuentraFunction = 'OR REPLACE FUNCTION';
						
						$posicionFunction = strpos($copia, $encuentraFunction);
							$restoFunction = substr ( $copia , $posicionFunction + 19  );
					} else {
						$encuentraFunction = 'FUNCTION';
						
						$posicionFunction = strpos($copia, $encuentraFunction);
						 $restoFunction = substr ( $copia , $posicionFunction + 8  );
						
					}
					//FIN CAMBIO OR REPLACE           
            
					$nombreFunction = explode(" ", strtolower($restoFunction));  

					$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
		
					$search = $nombreTrigger;
		
					$tamNombre = strlen($search);
					$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
					$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
					$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);

					//FIN FUNCION

					//INICIO
						$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
						$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
					//FIN NOMBRE


					$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace * BY /', 'TRIGGER');";
		
					$result = pg_query($conexion, $mutante);
					if (!$result) {
					  echo "Ocurrió un error.\n";
					  exit;
					}
					
					pg_close($conexion);
	
					//FIN + --> -
				}//FIN DEL ELSE 
		}
		//FIN MULTIPLICACION POR DIVISION
		}//fin si hay algun MULTIPLICACION

		//FIN OPERADOR MULTIPLICACION

		//INICIO OPERADOR DIVISION
		$numDivision = substr_count($trigger, '/');
		if($numDivision > 0)
		{

			for ($contadorMutantes = 1; $contadorMutantes <= $numDivision; $contadorMutantes++)
			{  
 
				if($contadorMutantes === 1){

					$encuentraDivision = '/';
					$posicionDivision = strpos($trigger, $encuentraDivision);
     
					$trozo = substr ( $trigger , 0 , $posicionDivision + 1  );
					$resto = substr ( $trigger , $posicionDivision + 1  );
      
					$cambiado = str_replace("/", "+", $trozo);
 
					$mutanteOper15 = $cambiado .= $resto; 
	
					if($contador == 0){
						$contador = 1;
					}
	  
		$conexion = pg_connect($_SESSION['conexion']);

		//Trigger
		$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
		$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

        $restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
            
        $auxiliar = explode(" ", strtolower($restoo));  
            
        $nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
			
		$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			

		//FIN TRIGGER

		//FUNCION
        //CAMBIO OR REPLACE

		$restoFunction = "";
		$encuentra = 'OR REPLACE FUNCTION';
		$pos = strpos($copia, $encuentra);

		// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
		if ($pos === false) {
			$encuentraFunction = 'OR REPLACE FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
				$restoFunction = substr ( $copia , $posicionFunction + 19  );
		} else {
			$encuentraFunction = 'FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
			 $restoFunction = substr ( $copia , $posicionFunction + 8  );
			
		}
		//FIN CAMBIO OR REPLACE
			
            
            $nombreFunction = explode(" ", strtolower($restoFunction));  
			
            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);
			
		//FIN FUNCION

		//INICIO
				$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
				$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
		//FIN NOMBRE
			



		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15', '$mutanteOper15', '$copia','$login','$triggerid','$oper','false', 'Replace / BY +', 'TRIGGER');"; 

		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
		pg_close($conexion);
	  //FIN INSERT MUTANTE
	}
	else
	{
      
		//INICIO / --> +
		$encuentraDivision = '/';
		$posicionDivision = strpos($mutanteOper15, $encuentraDivision, $posicionDivision);
		$function = substr ( $trigger , 0 , $posicionDivision);
      
      
		$resto = substr ( $mutanteOper15 , $posicionDivision );    
		$division = '/';
		$mas = '+';
		$cambio1 = preg_replace('/\//', '+', $resto, 1);
      
		$mutanteOper15 = $function.$cambio1; 
		if($contador == 0){
			$contador = 1;
		}
		$contador = $contador + 1;

		// Create connection

			$conexion = pg_connect($_SESSION['conexion']);

		//Trigger
			$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
            $posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

            $restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
           
            $aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
		
		//FIN TRIGGER

		//FUNCION
		//CAMBIO OR REPLACE

		$restoFunction = "";
		$encuentra = 'OR REPLACE FUNCTION';
		$pos = strpos($copia, $encuentra);

		// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
		if ($pos === false) {
			$encuentraFunction = 'OR REPLACE FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
				$restoFunction = substr ( $copia , $posicionFunction + 19  );
		} else {
			$encuentraFunction = 'FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
			 $restoFunction = substr ( $copia , $posicionFunction + 8  );
			
		}
		//FIN CAMBIO OR REPLACE
			
            
            $nombreFunction = explode(" ", strtolower($restoFunction));  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
		
			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);

		//FIN FUNCION

		//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
		//FIN NOMBRE

	
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace / BY +', 'TRIGGER');";

		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
	
		pg_close($conexion);
	
	//FIN / --> +
    }//FIN DEL ELSE
 
			}
			//DIVISION POR MENOS

			for ($contadorMutantes = 1; $contadorMutantes <= $numDivision; $contadorMutantes++){  
 
				if($contadorMutantes === 1){
     
      
					$encuentraDivision = '/';
					$posicionDivision = strpos($trigger, $encuentraDivision);
     
      
					$trozo = substr ( $trigger , 0 , $posicionDivision + 1  );
					$resto = substr ( $trigger , $posicionDivision + 1  );
	  
					$cambiado = str_replace("/", "-", $trozo);
 
					$mutanteOper15 = $cambiado .= $resto; 
	
					$contador = $contador + 1;
	  
					//INICIO INSERT MUTANTE
	  
					$conexion = pg_connect($_SESSION['conexion']);

					//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
						
						$posCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
						
						$restoo = substr ( strtolower($trigger) , $posCreateTrigger+14  );
					   
						$auxiliar = explode(" ",strtolower( $restoo));  
						
						$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
						
						$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
								
					//FIN TRIGGER

					//FUNCION           
					//CAMBIO OR REPLACE	
					$restoFunction = "";
					$encuentra = 'OR REPLACE FUNCTION';
					$pos = strpos($copia, $encuentra);

					// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
					if ($pos === false) {
						$encuentraFunction = 'OR REPLACE FUNCTION';
						
						$posicionFunction = strpos($copia, $encuentraFunction);
							$restoFunction = substr ( $copia , $posicionFunction + 19  );
					} else {
						$encuentraFunction = 'FUNCTION';
						
						$posicionFunction = strpos($copia, $encuentraFunction);
						 $restoFunction = substr ( $copia , $posicionFunction + 8  );
					}
					//FIN CAMBIO OR REPLACE
          
            $nombreFunction = explode(" ", strtolower($restoFunction));  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);
			
			//FIN FUNCION

			//INICIO
					$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
			//FIN NOMBRE
					
	
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace / BY -', 'TRIGGER');"; 
		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
		
		pg_close($conexion);
	  
		//FIN INSERT MUTANTE
		}
		else{     
			//INICIO * --> -
			$encuentraDivision = '/';
			$posicionDivision = strpos($mutanteOper15, $encuentraDivision, $posicionDivision);
			$function = substr ( $trigger , 0 , $posicionDivision);
			  
			  
			$resto = substr ( $mutanteOper15 , $posicionDivision );    
			$menos = '-';
			$division = '/';
			$cambio1 = preg_replace('/\//', '-', $resto, 1);
      
			$mutanteOper15 = $function.$cambio1; 
			if($contador == 0){
				$contador = 1;
			}
			$contador = $contador + 1;

			// Create connection

			$conexion = pg_connect($_SESSION['conexion']);

			//Trigger
						$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
						$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
           

            $restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
            $aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
		//FIN TRIGGER

		//FUNCION
		//CAMBIO OR REPLACE

		$restoFunction = "";
		$encuentra = 'OR REPLACE FUNCTION';
		$pos = strpos($copia, $encuentra);

		// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
		if ($pos === false) {
			$encuentraFunction = 'OR REPLACE FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
				$restoFunction = substr ( $copia , $posicionFunction + 19  );
		} else {
			$encuentraFunction = 'FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
			 $restoFunction = substr ( $copia , $posicionFunction + 8  );
		}
		//FIN CAMBIO OR REPLACE
		
            $nombreFunction = explode(" ", strtolower($restoFunction));  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);

		//FIN FUNCION

		//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
		//FIN NOMBRE

	
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace / BY -', 'TRIGGER');";

		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}
	

		pg_close($conexion);
	
		//FIN / --> -  
		}//FIN DEL ELSE OPER1
 
	}
	//FIN MAS POR MULTIPLICACION

	//INICIO DIVISION POR MULTIPLICACION 

	for ($contadorMutantes = 1; $contadorMutantes <= $numDivision; $contadorMutantes++)
	{  
		if($contadorMutantes === 1){
	      
			$encuentraDivision = '/';
			$posicionDivision = strpos($trigger, $encuentraDivision);
		 
		  
			$trozo = substr ( strtolower($trigger) , 0 , $posicionDivision + 1  );
			$resto = substr ( strtolower($trigger) , $posicionDivision + 1  );
		 
			$cambiado = str_replace("/", "*", $trozo);
  

			$mutanteOper15 = $cambiado .= $resto; 
	
			$contador = $contador + 1;

	  
			//INICIO INSERT MUTANTE
			$conexion = pg_connect($_SESSION['conexion']);

			//Trigger
				$encuentraCreateTrigger = 'CREATE TRIGGER';            
				$posCreateTrigger = strpos($trigger, $encuentraCreateTrigger);
           
				$restoo = substr ( $trigger , $posCreateTrigger+14  );
            
				$auxiliar = explode(" ", $restoo);  
            
				$nombreTriggerOriginal = str_replace('$', '' ,$auxiliar[1]);
			
				$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
			//FIN TRIGGER

			//FUNCION           
           //CAMBIO OR REPLACE

			$restoFunction = "";
			$encuentra = 'OR REPLACE FUNCTION';
			$pos = strpos($copia, $encuentra);

			// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
			if ($pos === false) {
				$encuentraFunction = 'OR REPLACE FUNCTION';
				
				$posicionFunction = strpos($copia, $encuentraFunction);
					$restoFunction = substr ( $copia , $posicionFunction + 19  );
			} else {
				$encuentraFunction = 'FUNCTION';
				
				$posicionFunction = strpos($copia, $encuentraFunction);
				 $restoFunction = substr ( $copia , $posicionFunction + 8  );
				
			}
			//FIN CAMBIO OR REPLACE

            
            $nombreFunction = explode(" ", strtolower($restoFunction));  
            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);
			

			//FIN FUNCION

			//INICIO
					$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
			//FIN NOMBRE
			
	
		
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15', '$mutanteOper15', '$copia','$login','$triggerid','$oper','false', 'Replace / BY *','TRIGGER');"; 
				
		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}

		pg_close($conexion);
	}
	else
	{
      
	//INICIO * --> /
      $encuentraDivision = '/';
      $posicionDivision = strpos($mutanteOper15, $encuentraDivision, $posicionDivision);
      $function = substr ( strtolower($trigger) , 0 , $posicionDivision);
      
      
      $resto = substr ( $mutanteOper15 , $posicionDivision );    
      $division = '/';
      $multiplicacion = '/';
	  $cambio1 = preg_replace('/\//', '*', $resto, 1);
      

      $mutanteOper15 = $function.$cambio1; 
      if($contador == 0){
		$contador = 1;
	  }
	  $contador = $contador + 1;

		// Create connection

			$conexion = pg_connect($_SESSION['conexion']);

		//Trigger
			$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
            $posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
	
            $restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
           
            $aux3 = explode(" ", $restoCreateTrigger);  
            
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
			
		//FIN TRIGGER

		//FUNCION
		//CAMBIO OR REPLACE

		$restoFunction = "";
		$encuentra = 'OR REPLACE FUNCTION';
		$pos = strpos($copia, $encuentra);

		// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
		if ($pos === false) {
			$encuentraFunction = 'OR REPLACE FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
				$restoFunction = substr ( $copia , $posicionFunction + 19  );
		} else {
			$encuentraFunction = 'FUNCTION';
			
			$posicionFunction = strpos($copia, $encuentraFunction);
			 $restoFunction = substr ( $copia , $posicionFunction + 8  );
			
		}
		//FIN CAMBIO OR REPLACE
			
            
            $nombreFunction = explode(" ", strtolower($restoFunction));  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
		
			$search = $nombreTrigger;

			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper15);

		//FIN FUNCION


		//INICIO
			$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
		//FIN NOMBRE

	
		$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper15','$nombreFuncionOper15',  '$mutanteOper15','$copia','$login','$triggerid','$oper','false', 'Replace / BY *', 'TRIGGER');";
		
		
		$result = pg_query($conexion, $mutante);
		if (!$result) {
		  echo "Ocurrió un error.\n";
		  exit;
		}

		pg_close($conexion);
	
		//FIN / --> *
	}//FIN DEL ELSE OPER1
 
	}

		//FIN division POR multiplicacion
		}//fin si hay algun DIVISION



		//FIN OPERADOR DIVISION


		//FIN OPER15 CABECERA
		
		
	}
	if($oper == 16)
	{
		//INICIO OPER16
		
		
		//INICIOOOOOOOO
		// Create connection

					$conexion = pg_connect($_SESSION['conexion']);

					//Trigger
					$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
					$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);
            

					$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
           
					$aux3 = explode(" ", $restoCreateTrigger);  
            
            
					$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			
					$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
					
					$aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
					$nombreTriggerOriginalOper16 = str_replace('$', '' ,$aux3[1]);
					
					//FIN TRIGGER

					//FUNCION
	
					//CAMBIO OR REPLACE
	
					$restoFunction = "";
					$encuentra = 'OR REPLACE FUNCTION';
					$pos = strpos($copia, $encuentra);

					// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
					if ($pos === false) {
						$encuentraFunction = 'OR REPLACE FUNCTION';
						
						$posicionFunction = strpos($copia, $encuentraFunction);
							$restoFunction = substr ( $copia , $posicionFunction + 19  );
					} else {
						$encuentraFunction = 'FUNCTION';
						
						$posicionFunction = strpos($copia, $encuentraFunction);
						 $restoFunction = substr ( $copia , $posicionFunction + 8  );
						
					}
					//FIN CAMBIO OR REPLACE
		
		
					$nFunction = explode(" ",strtolower($restoFunction));  
						
					$nombreFuncionOper16 = str_replace('$', '' ,$nFunction[1]);
            
					$nombreFunction = explode(" ", strtolower($restoFunction));  

					$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
					
					
					$search = $nombreTrigger;
					
					$tamNombre = strlen($search);
					$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
					$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
					$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
			
					//FIN FUNCION
		//FINNNNNNNNNNN
		//INICIO ALGORITMO
			$mutantesRELMayorIgual = preg_match_all( "/>=/",strtolower($trigger));
		
			$mutanteOper16 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesRELMayorIgual; $cont++){  
		
				$encuentraRELMayorIgual = strtolower("/>=/");
		
				preg_match($encuentraRELMayorIgual, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = strpos(strtolower($mutaciones), $encuentraRELMayorIgual);
				
				
				
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+2 );    
				
		
				$cambio1 = '<='.$resto;
				$cambio2 = '<>'.$resto;
				$cambio3 = '=='.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper16 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace >= by <=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace >= by <>', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace >= by ==', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace >= by >', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace >= by <', 'TRIGGER');";
				pg_query($conexion, $mutante);
		
			}
			
			//operador2
			$mutantesRELMenorIgual = preg_match_all( "/<=/",strtolower($trigger));
		
			$mutanteOper16 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesRELMenorIgual; $cont++){  
		
				$encuentraRELMenorIgual = strtolower("/<=/");
		
				preg_match($encuentraRELMenorIgual, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = strpos(strtolower($mutaciones), $encuentraRELMenorIgual);
				
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion +2);    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<>'.$resto;
				$cambio3 = '=='.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper16 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <= by >=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <= by <>', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <= by ==', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <= by >', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <= by <', 'TRIGGER');";
				pg_query($conexion, $mutante);
				
		
		
		
			}
			//Operador2
			
			//OPERADOR3
			$mutantesRELDistinto = preg_match_all( "/<>/",strtolower($trigger));
		
			$mutanteOper16 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesRELDistinto; $cont++){  
		
				$encuentraRELDistinto = strtolower("<>");
		
				//preg_match($encuentraRELDistinto, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = strpos(strtolower($mutaciones), $encuentraRELDistinto);
				
				
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+2 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '=='.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper16 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <>', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <>', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <>', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <>', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace <>', 'TRIGGER');";
				pg_query($conexion, $mutante);
				
			}
			//fin operador3
			
			//operador4
			$mutantesRELIgualIgual = preg_match_all( "/==/",strtolower($trigger));
		
			$mutanteOper16 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesRELIgualIgual; $cont++){  
		
				$encuentraRELIgualIgual = strtolower("/==/");
		
				preg_match($encuentraRELIgualIgual, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = strpos(strtolower($mutaciones), $encuentraRELIgualIgual);
				
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+2 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '<>'.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '<'.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@@'.$resto;
				
				$mutanteOper16 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace == by >=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace == by <=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace == by <>', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace == by >', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace == by <', 'TRIGGER');";
				pg_query($conexion, $mutante);
			}
			
			//fin operador4
			
			//operador Mayor
			$mutantesRELMayor = preg_match_all( "/[^<]>[^=]/",strtolower($trigger));
		    
			$mutanteOper16 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesRELMayor; $cont++){  
		
				$encuentraRELMayor = strtolower("/[^<]>[^=]/");
		
				preg_match($encuentraRELMayor, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion);
			
				$resto = substr ( strtolower($mutaciones) , $posicion+2 );    
			
			
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '<>'.$resto;
				$cambio4 = '<'.$resto;
				$cambio5 = '=='.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper16 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace > by >=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace > by <=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace > by <>', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace > by <', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace > by ==', 'TRIGGER');";
				pg_query($conexion, $mutante);
			}
			//Fin operador Mayor
			
			//operador Menor
												
			$mutantesRELMenor = preg_match_all( '/<[^>=]/',strtolower($trigger));
			
		
			$mutanteOper16 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesRELMenor; $cont++){  
		
				$encuentraRELMenor = strtolower('/<[^>=]/');
			
		
				preg_match($encuentraRELMenor, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];

				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion);
				$resto = substr ( strtolower($mutaciones) , $posicion+2 );    
				
		
				$cambio1 = '>='.$resto;
				$cambio2 = '<='.$resto;
				$cambio3 = '<>'.$resto;
				$cambio4 = '>'.$resto;
				$cambio5 = '=='.$resto;
				
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				$mutaciones = $inicioMutations.'@'.$resto;
				
				$mutanteOper16 = $contenidoarchivo.$cambio1; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace < by >=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio2; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace < by <=', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio3; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace < by <>', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio4; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace < by >', 'TRIGGER');";
				pg_query($conexion, $mutante);
				$mutanteOper16 = $contenidoarchivo.$cambio5; 
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper16','$nombreFuncionOper16',  '$mutanteOper16','$copia','$login','$triggerid','$oper','false', 'Replace < by ==', 'TRIGGER');";
				pg_query($conexion, $mutante);
			}
			//Fin operador Menor

		//FIN OPER16
	}
	if($oper == 17)
	{
		//INICIO OPER17
		

			$existe = false;
			$existeOperador17 = true;

			$posicionWhen = strpos(strtolower($trigger), strtolower('WHEN'));
			
			if($posicionWhen == false){//si no hay condicion when no se puede aplicar este operador
			
			}else{//si hay condicion when procesar
			//INICIO ALGORITMO
			$mutantesAND = preg_match_all( "/[\s)\n]and[\s(\n]/",strtolower($trigger));
		
			$mutanteOper17 = "";
			$mutaciones = $trigger;
			
			for ($cont = 1; $cont <= $mutantesAND; $cont++){  
		
				$encuentraAND = strtolower("/[\s)\n]and[\s(\n]/");
		
				preg_match($encuentraAND, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion+1);
				$resto = substr ( strtolower($mutaciones) , $posicion+4 );    
				
		
				$cambio1 = 'OR '.$resto;
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion+1);
				
		
				$mutaciones = $inicioMutations.$cambio1;
				
				
				$mutanteOper17 = $contenidoarchivo.$cambio1; 
				
			

       		// Create connection
			$conexion = pg_connect($_SESSION['conexion']);
			//Trigger
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				$posicionCreateTrigger = strpos(strtolower($mutanteOper17), $encuentraCreateTrigger);

				$restoCreateTrigger = substr ( strtolower($mutanteOper17) , $posicionCreateTrigger+14  );
				$aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
				$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
				$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;	

				$restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
				$aux3 = explode(" ", $restoCreateTrigger);  
            
            
				$nombreTriggerOriginalOper17 = str_replace('$', '' ,$aux3[1]);
			
			//FIN TRIGGER

			//FUNCION
		
			
            $encuentraFunction = strtolower('FUNCTION');
            $posicionFunction = strpos(strtolower($copia), $encuentraFunction);

            $restoFunction = substr (strtolower($copia) , $posicionFunction + 8  );

            
            $nombreFunction = explode(" ", strtolower($restoFunction));  

            $nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);
			
			
			$search = $nombreTrigger;
			
			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';

			$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper17);
			
			//FIN FUNCION
			
			$nFunction = explode(" ", $restoFunction);  
				$nombreFuncionOper17 = str_replace('$', '' ,$nFunction[1]);

			//INICIO
					$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
			//FIN NOMBRE
	
			
	      $mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper17','$nombreFuncionOper17',  '$mutanteOper17','$copia','$login','$triggerid','$oper','false', 'Replace AND BY OR', 'TRIGGER');";
		  
		  
	   
			$result = pg_query($conexion, $mutante);
			if (!$result) {
			  echo "Ocurrió un error.\n";
			  exit;
			}
		
			pg_close($conexion);
			//fin conexion
		
	}//FIN ALGORITMO

			$mutantesOR = preg_match_all( "/[\s)\n]or[\s(\n]/",strtolower($trigger));

			$mutanteOper17 = "";
			$mutaciones = $trigger;
			

	for ($cont = 1; $cont <= $mutantesOR; $cont++){  
		
				//INICIO
				$encuentraOR = strtolower("/[\s)\n]or[\s(\n]/");
				preg_match($encuentraOR, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion+1);
				  
				$resto = substr ( strtolower($mutaciones) , $posicion+3 );    
				
				
				$cambio1 = 'AND'.$resto;
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion);
				
				$mutaciones = $inicioMutations.$cambio1;
				
				
				$mutanteOper17 = $contenidoarchivo.$cambio1; 
				
				//FIN
			  
				// Create connection

				$conexion = pg_connect($_SESSION['conexion']);

				//Trigger
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				$posicionCreateTrigger = strpos(strtolower($mutanteOper17), $encuentraCreateTrigger);

				$restoCreateTrigger = substr ( strtolower($mutanteOper17) , $posicionCreateTrigger+14  );
            
           
				$aux3 = explode(" ", $restoCreateTrigger);  
            				
				$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
				
				$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
				
				$restoCreateTrigger = substr ( $trigger , $posicionCreateTrigger+14  );
				$aux3 = explode(" ", $restoCreateTrigger);  
            
            
				$nombreTriggerOriginalOper17 = str_replace('$', '' ,$aux3[1]);
				
			
				//FIN TRIGGER

				//FUNCION
				//CAMBIO OR REPLACE

				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					 $restoFunction = substr ( $copia , $posicionFunction + 8  );
					
				}
				//FIN CAMBIO OR REPLACE

            
				$nombreFunction = explode(" ", strtolower($restoFunction));  
			
				$nombreTrigger = str_replace('$', '' ,$nombreFunction[1]);

				
				$search = $nombreTrigger;
				$tamNombre = strlen($search);
				$nomTrigger = substr ( $nombreTrigger , 0, $tamNombre - 2);
				$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
				
				

				$functionMutante = str_ireplace($nombreTrigger , $nomFunctionActualizado, $mutanteOper9);
			
				//FIN FUNCION
				
				$nFunction = explode(" ", $restoFunction);  
				$nombreFuncionOper17 = str_replace('$', '' ,$nFunction[1]);

				//INICIO
					$triggerActualizado = str_ireplace($nombreTrigger , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
				//FIN NOMBRE
							
				
					$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper17','$nombreFuncionOper17',  '$mutanteOper17','$copia','$login','$triggerid','$oper','false', 'Replace OR BY AND', 'TRIGGER');";
						 
						  
	   
				$result = pg_query($conexion, $mutante);
				if (!$result) {
				  echo "Ocurrió un error.\n";
				  exit;
				}
		
				pg_close($conexion);
				//fin conexion
		   

      

			
		}//FIN ALGORITMO
		//FIN OPER17
			}
	}
	if($oper == 18)
	{
		//INICIO OPER18
		
	
			
			$hayInsert = substr_count(strtolower($trigger), strtolower('INSERT'));
			$hayUpdate = substr_count(strtolower($trigger), strtolower('UPDATE'));
			$hayDelete = substr_count(strtolower($trigger), strtolower('DELETE'));
			//SI HAY UPDATE Y NO INSERT Y UPDATE NO SE APLICA
			if($hayUpdate > 0 && $hayInsert == 0 && $hayDelete == 0 )
			{

				
					//INICIO ALGORITMO
					
				$mutantesNEW = substr_count(strtolower($trigger), strtolower('NEW.'));

				$mutanteOper18 = "";
				$mutaciones = $trigger;
				

				for ($cont = 1; $cont <= $mutantesNEW; $cont++){  
				  
				  
				 
					  $encuentraNew = strtolower('NEW.');
					  $posicion = strpos(strtolower($mutaciones), $encuentraNew);
					
					  $contenidoarchivo = substr ( strtolower($trigger) , 0 , $posicion);
					  
					
					 
					  $resto = substr ( $mutaciones , $posicion );    
			

					  $old = strtolower('OLD.');
					  $cambio1 = preg_replace(strtolower('/NEW./'), $old, strtolower($resto), 1);
					  $mutaciones = preg_replace(strtolower('/NEW./'), $old, strtolower($mutaciones), 1);
					  

					  $mutanteOper18 = $contenidoarchivo.$cambio1; 
					

        		// Create connection

					$conexion = pg_connect($_SESSION['conexion']);

	

				//Trigger

					$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
					$posicionCreateTrigger = strpos(strtolower($trigger), strtolower($encuentraCreateTrigger));

					$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
           
					$aux3 = explode(" ", $restoCreateTrigger);  
            
					$nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);	
					$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
			
				//FIN TRIGGER

				//FUNCION
				 //CAMBIO OR REPLACE

				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos(strtolower($copia), strtolower($encuentra));

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
				 
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos(strtolower($copia), strtolower($encuentraFunction));
						$restoFunction = substr (strtolower($copia) , $posicionFunction + 19  );
				} else {
				 
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos(strtolower($copia), strtolower($encuentraFunction));
					 $restoFunction = substr ( strtolower($copia) , $posicionFunction + 8  );
					
				}
				//FIN CAMBIO OR REPLACE
			
					
					$nFunction = explode(" ", $restoFunction);  

					$nombreFuncion = str_replace('$', '' ,$nFunction[1]);
					
					
					$search = $nombreFuncion;
					
					$tamNombre = strlen($search);
					$nomFuncion = substr ( $nombreFuncion , 0, $tamNombre - 2);
					$nomFunctionActualizado = $nomFuncion . '_' .$contador . '()';
					
					$functionMutante = str_ireplace($nombreFuncion , $nomFunctionActualizado, $mutanteOper18);
			
			//FIN FUNCION

			//INICIO
					$triggerActualizado = str_ireplace($nombreFuncion , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
			//FIN NOMBRE
 		
				
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change,type ) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper18','$copia','$login','$triggerid','$oper','false', 'Replace NEW BY OLD', 'TRIGGER');";
		  
		  
	   
					$result = pg_query($conexion, $mutante);
					if (!$result) {
					  echo "Ocurrió un error.\n";
					  exit;
					}
							

					pg_close($conexion);
					//fin conexion
				
				  //}
				  //fin else del new__
				  
				  
				}
				
				
				
			//inicio old
			$mutanteOper18 = "";
			$mutaciones = $trigger;

			//INICIO ALGORITMO
			$mutantesOLD = substr_count(strtolower($trigger), strtolower('OLD.'));
			

			for ($cont = 1; $cont <= $mutantesOLD; $cont++){  
			 
	
		  $encuentraOld = strtolower('OLD.');
		  $posicion = strpos(strtolower($mutaciones), $encuentraOld);
		  
		  
		  $contenidoarchivo = substr ( strtolower($trigger) , 0 , $posicion);
		
      
		  $resto = substr ( strtolower($mutaciones) , $posicion );    
		  $new = strtolower('NEW.');
		  $old = strtolower('OLD.');
		  $cambio1 = preg_replace(strtolower('/OLD./'), $new, strtolower($resto), 1);
		  $mutaciones = preg_replace(strtolower('/OLD./'), $new, strtolower($mutaciones), 1);
		  
			$mutanteOper18 = $contenidoarchivo.$cambio1; 
			

       		// Create connection

			$conexion = pg_connect($_SESSION['conexion']);

			//Trigger
		
			$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
            $posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

            $restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
           
            $aux3 = explode(" ", $restoCreateTrigger);  
            
            $nombreTriggerOriginal = str_replace('$', '' ,$aux3[1]);
			
			//FIN TRIGGER

			//FUNCION
			 //CAMBIO OR REPLACE

			$restoFunction = "";
			$encuentra = 'OR REPLACE FUNCTION';
			$pos = strpos(strtolower($copia), strtolower($encuentra));

			// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
			if ($pos === false) {
				$encuentraFunction = 'OR REPLACE FUNCTION';
				
				$posicionFunction = strpos(strtolower($copia), strtolower($encuentraFunction));
					$restoFunction = substr ( strtolower($copia) , $posicionFunction + 19  );
			} else {
				$encuentraFunction = 'FUNCTION';
				
				$posicionFunction = strpos(strtolower($copia), strtolower($encuentraFunction));
				 $restoFunction = substr ( strtolower($copia) , $posicionFunction + 8  );
				
			}
			//FIN CAMBIO OR REPLACE
		
            $nFunction = explode(" ", $restoFunction);  
            $nombreFuncion = str_replace('$', '' ,$nFunction[1]);

			
			$search = $nombreFuncion;
			$tamNombre = strlen($search);
			$nomTrigger = substr ( $nombreFuncion , 0, $tamNombre - 2);
			$nomFunctionActualizado = $nomTrigger . '_' .$contador . '()';
			
			$functionMutante = str_ireplace($nombreFuncion , $nomFunctionActualizado, $mutanteOper18);
			
		 

			//FIN FUNCION

			//INICIO
					$nombreTriggerMutante = $nombreTriggerOriginal . '_' . $contador;
					$triggerActualizado = str_ireplace($nombreFuncion , $nomFunctionActualizado, $trigger);
					$triggerMutanteActualizado = str_ireplace($nombreTriggerMutante , $nombreTriggerOriginal, $triggerActualizado);
			//FIN NOMBRE
					

	      $mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginal','$nombreFuncion',  '$mutanteOper18','$copia','$login','$triggerid','$oper','false', 'Replace OLD BY NEW', 'TRIGGER');";
		  
	   
			$result = pg_query($conexion, $mutante);
			if (!$result) {
			  echo "Ocurrió un error.\n";
			  exit;
			}
		


			pg_close($conexion);
			//fin conexion
			//}
		}//fin bucle reemplazo old
				}//FIN UPDATE Y NO INSERT Y UPDATE NO SE APLICA
				
		//FIN OPER18
	}
	
	if($oper == 19)
	{
		$existeOper19 = false;
				$existeOperador19 = true; 
	
				$reemplazos = substr_count(strtolower($copia), strtolower('NOT AND'));
	
	
				//nombres de triggers y funciones 
				//Trigger

			
				$encuentraCreateTrigger = strtolower('CREATE TRIGGER');
				$posicionCreateTrigger = strpos(strtolower($trigger), $encuentraCreateTrigger);

				$restoCreateTrigger = substr ( strtolower($trigger) , $posicionCreateTrigger+14  );
            
           
				$aux3 = explode(" ", strtolower($restoCreateTrigger));  
            
            
				$nombreTriggerOriginalOper19 = str_replace('$', '' ,$aux3[1]);
			
				//FIN TRIGGER

				//FUNCION
				//CAMBIO OR REPLACE
	
				$restoFunction = "";
				$encuentra = 'OR REPLACE FUNCTION';
				$pos = strpos($copia, $encuentra);

				// Nótese el uso de ===. Puesto que == simple no funcionará como se espera
				if ($pos === false) {
					$encuentraFunction = 'OR REPLACE FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
						$restoFunction = substr ( $copia , $posicionFunction + 19  );
				} else {
					$encuentraFunction = 'FUNCTION';
					
					$posicionFunction = strpos($copia, $encuentraFunction);
					 $restoFunction = substr ( $copia , $posicionFunction + 8  );
					
				}
				//FIN CAMBIO OR REPLACE
													
			
					$nFunction = explode(" ",strtolower($restoFunction));  
						
					$nombreFuncionOper19 = str_replace('$', '' ,$nFunction[1]);
							
				//fin funcion
  
  
				//fin nombres triggers y funciones
				//INICIO ALGORITMO
	
				
				
				//INICIO OPER NOT
					$mutantesNOT = preg_match_all( "/[\s(\n]not[\s(\n]/",strtolower($copia));

			$mutanteOper19 = "";
			$mutaciones = $trigger;
			

	for ($cont = 1; $cont <= $mutantesNOT; $cont++){  
		
				//INICIO
				$encuentraNOT = strtolower("/[\s(\n]not[\s(\n]/");
				preg_match($encuentraNOT, strtolower($mutaciones), $matches, PREG_OFFSET_CAPTURE);
				$posicion = $matches[0][1];
				
				$contenidoarchivo = substr (strtolower($trigger) , 0 , $posicion+1);
				  
				$resto = substr ( strtolower($mutaciones) , $posicion+4 );    
				
				
				$cambio1 = $resto;
				$inicioMutations = substr (strtolower($mutaciones) , 0 , $posicion+1);
				
				
				$mutaciones = $inicioMutations.'@@@'.$cambio1;
				
				
				$mutanteOper19 = $contenidoarchivo.$cambio1; 
				
		
				$mutante    =   "INSERT INTO mutations( triggername,functionname, triggerbody,functionbody,login, idtrigger,idoperator, equivalent, change, type) VALUES ('$nombreTriggerOriginalOper19','$nombreFuncionOper19',  '$mutanteOper19','$copia','$login','$triggerid','$oper','false', 'Remove logical operator NOT in HEADER', 'TRIGGER');";
				
				  
				$result = pg_query($conexion, $mutante);
				if (!$result) {
				  echo "Ocurrió un error.\n";
				  exit;
				}
		
				pg_close($conexion);
	
	}//FIN ALGORITMO

		
	}

			

			//INCLUIR AQUI RESTO DE OPERADORES
			
		}//ROWS = 0
		
	}//FIN FOREACH DE OPERADORES 
	

		$conexion = pg_connect($_SESSION['conexion']);
		$reg = pg_query("select * from public.\"mutationsView\" where idtrigger = '".$triggerid."' and idoperator in (".$sqlOperadores.") ORDER BY name, change ");	
		
		$numFilasResultado = pg_num_rows($reg);	
		
		if($numFilasResultado > 0){
			$mutantesCreados = 0;
			while ($res = pg_fetch_array($reg, null, PGSQL_ASSOC)) {
			
			
			//instalar y desinstalar triggers, capturar el error, y se produce, coger el id mutation,y se borra de la tabla
			
			
			//solo pinta si no hay error 
			
					?>
					<TR>
					<TD style="text-align: center"><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"] ?>')"><?php echo $res["idmutation"]  ?></a></TD>
					<TD style="text-align: center"><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"]  ?>')"><?php echo $res["type"] ?></a></TD>
					<TD style="text-align: center"><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"]  ?>')"><?php echo $res["name"] ?></a></TD>
					<TD><a href="javascript:Abrir_ventana('showMutant.php?id=<?php echo $res["idmutation"]  ?>')"><?php echo $res["change"] ?></a></TD>
					</TR>
					<?php
					$mutantesCreados = $mutantesCreados + 1;
			}
			
			if($mutantesCreados == 0)
			{
				//header("Location: index_error");
				//no se ha generado ningun mutante
				//die();
			}

		}
		else{
			//MOSTRAR MENSAJE DE NO HAY OPERADORES A APLICAR 
			//header("Location: index_error.php");
			//die();
		}
		//}
  
			pg_close($conexion);
			//fin conexion
		
	
  
    

?>
</TABLE>