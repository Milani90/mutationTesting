<?php

pg_connect("host=127.0.0.1 port=5432 dbname=pruebas user=postgres password=root");

pg_query('CREATE FUNCTION public.price_audit() RETURNS trigger LANGUAGE "plpgsql" AS $BODY$ BEGIN INSERT INTO Price_Audits(film_id, entry_date) VALUES (new.ID, current_timestamp); RETURN new; END; $BODY$;');

pg_query("CREATE TRIGGER price_trigger AFTER UPDATE ON public.employees FOR EACH statement EXECUTE PROCEDURE public.price_audit();");

pg_close();


?>