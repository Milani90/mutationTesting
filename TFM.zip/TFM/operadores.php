<?php
if (isset($_SESSION['login'])){ 
//echo "La sesión existe ..."; 
} 
else
{
//echo "La sesión existe ..."; 
//header('location: login.php');	
	
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Muttation Triggers</title>
  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:500,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,800,800i" rel="stylesheet">
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/resume.min.css" rel="stylesheet">

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
    <a class="navbar-brand js-scroll-trigger" href="#page-top">
      <span class="d-block d-lg-none">Clarence Taylor</span>
        
    </a>
	<!--
	<br><br><br><br>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>-->
	
	<span class="d-none d-lg-block">
        <img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="img/PL_PgSQL.png" alt="">
      </span>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav">

        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="./triggers.php">Triggers</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="./suites.php">Test Suites</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="./lista_operadores.php">Mutation operators</a>
        </li>
		<li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="./listbox/demo/index.php">Mutation Process</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="./perfil.php">Profile</a>
        </li>
		<li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="./logout.php">Logout</a>
        </li>
      </ul>
    </div>
  </nav>



<div class="container" id="content" style=" margin-top: 80px;">
	<!--
	<div id="right">
        <div id="right_top">
		-->
	
 
 <!--FIN CABECERA-->

 
 <div id="content" style="margin-left: 90px; margin-top: 80px;">
 <h1  style="text-align:center"> OPERADORES DE MUTACIÓN </h1>
 
<li style="align: center">Aritméticos</li>
<li style="align: center">Relacionales</li>
<li style="align: center">Lógicos</li>
<li style="align: center">Genéricos</li>
<li style="align: center">Fila</li>
<li style="align: center">Temporales</li>

<br>
<br>

<!--
<div>

 
<h4>ADD NEW OPERATOR</h4>
<form action="add_operador.php" method="POST">
	
	<br>
    <span>Operator name: </span><input type="text" name="nombre_operador">
	<br><br>
	<span>Operator body: </span><textarea name="cuerpo_operador" rows="4" cols="116"> </textarea>
	<br><br>
	<input type="submit" value="Add">
	<br><br><br><br>

</form>

</div>


 <br>
 <hr>
-->

<div> 
<h3>Operadores de mutación aritméticos</h3>
<br>
<span>Es el tipo de operadores que se utilizan a la hora de realizar las operaciones aritméticas básicas.<br>
Se utilizan en el bloque de las condiciones dentro de los triggers.<br>
Están formados por: +, -, *, /<br>
</div>





<br><br>

<h3>Operadores de mutación relacionales</h3>
<br>
<span>
Es el tipo de operadores que se utilizan a la hora de realizar comparaciones entre dos expresiones, que pueden ser variables, valores de los campos, etc.<br>
Al igual que ocurre con los operadores anteriores, este tipo se utilizan en el bloque de las condiciones dentro de los triggers.<br>
Están formados por: =, <>, >, <, <=, >=<br>
</span>



<br><br>




<h3>Operadores de mutación lógicos</h3>
<br>
<span>
Es el tipo de operadores que se utilizan a la hora de realizar las operaciones aritméticas básicas.<br>
Los operadores lógicos AND y OR son conmutativos. Esto indica que se pueden intercambiar el operador de izquierda con el de la derecha sin que se produzca ningún efecto distinto en el resultado.<br>
Se utilizan en el bloque de las condiciones dentro de los triggers.<br>
Están formados por: AND, OR Y NOT. <br>
<li> AND, permite evaluar dos condiciones y se obtiene TRUE solo si ambas son verdad. </li>
<li> OR, permite evaluar dos condiciones y devuelve TRUE si alguna de las dos es verdad. </li>
<li> NOT, modifica el valor devolviendo el valor contrario de la expresión sobre la que esté aplicada. </li>
</span>


<br><br>




<h3>Operadores de mutación genérico </h3>
<br>
<span>
Es el tipo de operadores que se utilizan a la hora de realizar las operaciones básicas de crear, actualizar o borrado de triggers o funciones.<br>
Tenemos la opción de añadir y eliminar una o mas operaciones a un trigger o función y modificar su funcionalidad.<br>
Si no se indica nada, por defecto es a nivel de sentencia (statement).<br>
Están formados por: INSERT, UPDATE, DELETE.<br>
<li> ADD: Añadimos un operador a los ya existentes. </li>
<li> DEL: Eliminamos un operador de los ya existentes. </li>
<li> CHA: Sustituimos un operador por uno existente. </li>



<br>
<br>

<h3>Operadores de mutación de fila y sentencia</h3>
<br>
<span>
Es el tipo de operadores que se utilizan a la hora de realizar las operaciones a nivel de fila o a nivel de sentencia.<br>
A nivel de fila se activa una vez por cada uno de los registros afectados por la operación sobre la tabla, cuando hay una operación que afecta a varios registros.<br>
A nivel de sentencia se activa una sola vez, antes o después de ejecutar la operación sobre la tabla.<br>
Si no se indica nada, por defecto es a nivel de sentencia (statement). <br>
Están formados por: FOR EACH ROW, FOR EACH STATEMENT <br>
</span>



<br>
<br>

<h3>Operadores de mutación temporales </h3>
<br><br>
<span>

Es el tipo de operadores indican el momento en el que se ejecuta el Trigger, bien sea antes o después de la evento que lo lance.<br>
Están formados por: BEFORE y AFTER. <br>
El operador Before, se debe ejecutar cuando se quiera comprobar ciertos valores de columnas a la hora de lanzar un INSERT o UPDATE.<br>
El operador After, se debe utilizar cuando se desea completar la sentencia antes de ejecutar la acción del Trigger. <br>
</span>
<!--
< ?php

$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
	    //$mutante    =   "INSERT INTO mutacion(nombre_funcion,nombre_trigger,cuerpo_funcion,cuerpo_trigger,idoper,equivalente) VALUES ('$final4','$final3', '$cuerpofuncion2', '$cuerpotrigger2','$oper','');";
		$operadores = "SELECT CUERPO_TRIGGER FROM MUTACION";
$result = pg_query($conexion, $operadores);

echo "<table STYLE=' border: blue 2px solid;'>";
 echo "<tr><td align='center' width='25%' style='font-weight: bold;'>OPERADORES</td>";
 while($row=pg_fetch_assoc($result)){
echo "<tr>";
echo "<td align='center' width='25%' STYLE=' border: blue 2px solid;'>" . $row['nombre'] . "</td>";
echo "</tr>";
echo "</table>";
}



?>
-->

<br><br><br><br>
</div>
</div>
</body>

</html>
