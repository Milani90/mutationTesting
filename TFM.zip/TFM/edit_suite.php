<?php
session_start();
	$conexion = pg_connect($_SESSION['conexion']);
	
	
$desc = $_POST['editDescription'];

$editIdSuite = $_POST['editIdSuite'];
$idsuite = $_SESSION['idsuite'];

$conexion = pg_connect($_SESSION['conexion']);
$sql = "UPDATE suites set description = '$desc' where idsuite = '$idsuite'";

pg_query($conexion,$sql);


header('Location: suites.php');
?>