<?php

$host = "host=127.0.0.1 ";
	$port = "port=5432 ";
	$dbname = "dbname=tfm ";
	$user = " user=postgres ";
	$password = "password=root";
	$confConexion = $host . $port . $dbname .$user . $password;
	//echo $confConexion;

	$con = pg_connect($confConexion);

$triggerName = "pruebas2";
$triggerFunctionEsc = 'CREATE FUNCTION stock_insert_trigger() RETURNS TRIGGER AS $$ BEGIN IF extract(year FROM NEW.day) = 2018 THEN EXECUTE "INSERT INTO stock_2018_t" || date_part("quarter", NEW.day) || "VALUES ($1.*)" USING NEW; END IF; RETURN NULL; END; $$ LANGUAGE plpgsql;';

$triggerHeaderEsc = "CREATE TRIGGER trigg_stock_insert BEFORE INSERT ON employees FOR EACH ROW EXECUTE PROCEDURE stock_insert_trigger();";
$usuario = "cristian";
$databaseName = "pruebasInsert";
$description = "Descripcion de insert";

$sql = "insert into triggers(name,headertrigger,bodytrigger,login,databasename,description) values ('$triggerName', '$triggerHeaderEsc', '$triggerFunctionEsc' ,'$usuario', '$databaseName', '$description')";

pg_query($sql);

?>