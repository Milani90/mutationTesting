<?php
session_start();
	//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
	$conexion = pg_connect($_SESSION['conexion']);
	
	
$desc = $_POST['editDescription'];
echo 'DESCRIPCION: ', $desc;
echo '<br>';
$editIdSuite = $_POST['editIdSuite'];
$idsuite = $_SESSION['idsuite'];
echo "ID: ", $_SESSION['idsuite'];
$conexion = pg_connect($_SESSION['conexion']);
$sql = "UPDATE suites set description = '$desc' where idsuite = '$idsuite'";
echo 'SQL: ', $sql;
pg_query($conexion,$sql);


header('Location: suites.php');
?>