	<?php
session_start(); //Iniciamos o Continuamos la sesion
if (isset($_POST['login'])) //Si llego un Nickname via el formulario lo grabamos en la Sesion
{
	$_SESSION['login'] = $_POST['login']; 
}
if ($_SESSION['login']) //Si hay un nickname en la sesion actual, creamos una variable que será mostrada
{
	
	
}

//$conexion = pg_connect("host=127.0.0.1 port=5432 dbname=tfm user=postgres password=root");
$conexion = pg_connect($_SESSION['conexion']);



$nombre = $_POST['nombre_operador']; 
$cuerpo_operador = $_POST['cuerpo_operador']; 

									//nombre,descripcion,cuerpo_trigger,funcion_trigger,idtrigger,usuario
//$sql = "insert into operadores(nombre,descripcion,cuerpo_trigger,funcion_trigger,usuario) values ('$triggerName', '$description','$triggerHeader', '$triggerFunction' ,'$usuario')";
$sql = "insert into operadores(nombre,cuerpo) values ('$nombre', '$cuerpo_operador')";

 
//Ejecutamos la consulta
$res = pg_query($sql) or die('La consulta fallo: ' . pg_last_error());
 
echo "Operador insertado correctamente";
 
//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
pg_free_result($res);
 
//Cerramos la conexión
pg_close($conexion);
header('location: index.php');
?>