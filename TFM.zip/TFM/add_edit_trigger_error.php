<?php
session_start(); //Iniciamos o Continuamos la sesion
if (isset($_SESSION['login'])) //Si llego un Nickname via el formulario lo grabamos en la Sesion
{
 
}
else{
	 header('location: login.php');
}

  //Activamos todas las notificaciones de error posibles
  error_reporting (E_ALL);

  //Definimos el tratamiento de errores no controlados
  set_error_handler(function () 
  {
    throw new Exception("Error");
  });
  
  function LogDeErrores($numeroDeError, $descripcion, $fichero, $linea, $contexto){
	  
	error_log("Error: [".$numeroDeError."] ".$descripcion." ".$fichero." ".$linea." ".json_encode($contexto)." \n\r", 3, "log_errores.txt");
	$error = explode ("ERROR:", $descripcion);
	$_SESSION['descripcionErrorTrigger'] = isset($error[1]) ? $error[1] : null ;	
	throw new Exception("Error");
  }
  set_error_handler("LogDeErrores");
//INICIO

	$host = $_SESSION['host'];
	$port = $_SESSION['port'];
	$dbname = "dbname=" . $_SESSION['databasenameTrigger'];
	$user = $_SESSION['user'];
	$password = $_SESSION['passConf'];
	$confConexion = $host ." ". $port ." ". $dbname ." " .$user ." ". $password;
	echo $confConexion;

	$con = pg_connect($confConexion);

//FIN

$usuario= $_SESSION['login'];
	
$triggerHeader = $_POST['triggerHeader']; 
$_SESSION["triggerHeader"] = $triggerHeader;

$triggerHeaderEsc = pg_escape_string($triggerHeader);


$triggerFunction = $_POST['triggerFunction']; 
$_SESSION["triggerFunction"] = $triggerFunction; //VARIABLE SESION
$triggerFunctionEsc = pg_escape_string($triggerFunction);
$funcion = explode(" ", $triggerFunctionEsc);
$nombreFuncion = $funcion[2];
$deleteFuncion ="DROP FUNCTION IF EXISTS $nombreFuncion CASCADE";
pg_query($con,$deleteFuncion);

$triggerName = $_POST['triggerName']; 
$_SESSION["triggerName"] = $triggerName;
$description = $_POST['description']; 
$_SESSION["descriptionTrigger"] = $description;
$databaseName = $_POST['databaseName'];
$_SESSION["databaseNameTrigger"] = $databaseName; 

$triggerFunctionValido = false;

$triggerFunctionEsc = str_replace('"','\'', $triggerFunctionEsc);

  try 
  {

		$triggerFunctionIns = pg_query($triggerFunctionEsc);

		 
		if($triggerFunctionIns){

			$triggerHeaderEsc = str_replace('"','\'',$triggerHeaderEsc);
			$triggerHeaderIns = pg_query($triggerHeaderEsc);
			if($triggerHeaderIns){
				$conexion =  pg_connect($_SESSION['conexion']);
				$sql = "update triggers set name = '$triggerName',headertrigger = '$triggerHeader',bodytrigger = '$triggerFunction' ,login = '$usuario',databasename = '$databaseName',description = '{$description}' where idtrigger = '".$_SESSION['idTrigger']."'";
				$res = pg_query($conexion,$sql);
				if($res)
				  {			  
					$deleteFuncion ="DROP FUNCTION IF EXISTS $nombreFuncion CASCADE";
					pg_query($con,$deleteFuncion);
				  }
				pg_close($conexion);  
			}	
			else{
				$deleteFuncion ="DROP FUNCTION IF EXISTS $nombreFuncion CASCADE";
				pg_query($con,$deleteFuncion);
			}
		}

		//Liberamos la memoria (no creo que sea necesario con consultas tan simples)
		pg_free_result($res);

		header('location: triggers.php');

}//fin del try
   catch(Exception $e) //capturamos un posible error
  {
    //mostramos el texto del error al usuario	  
    echo "Error al insertar el trigger." . PHP_EOL;
	echo "Revise el código." . PHP_EOL;
	
	
	header('location: error_add_edit_trigger.php'); 
  }
  
  //Restablecemos el tratamiento de errores
  restore_error_handler();
?>