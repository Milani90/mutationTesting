<?php
$(document).ready(function(){
	$(document).on('click', '.update', function(){
		var id=$(this).val();		
		
		$nombre= $('#enombre'+id).text();
		
		$descripcion=$('#edescripcion'+id).text();
		$cuerpo_trigger=$('#ecuerpo_trigger'+id).text();
		$funcion_trigger=$('#efuncion_trigger'+id).text();
		$idtrigger = $('#eidtrigger'+id).text();
		
	

	$conexion = pg_connect($_SESSION['conexion']);
	

	$sql = "DELETE FROM triggers WHERE idtrigger='".$_REQUEST['triggerid']."'";
	$resultset = pg_query($conexion, $sql) or die("database error:". pg_last_error($conn));	
	if($resultset) {
		echo "Record Updated";
		}
	}
	)});
	
		
?>